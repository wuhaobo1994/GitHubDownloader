// GitRelease Watcher - 前端交互逻辑
let tasks = [];
let pollingTimer = null;
let selectedTaskIds = new Set();
let currentLogsList = [];
let activeLogLevel = "all";
let logsPollingTimer = null;

// 全局 API Key 拦截器 (当开启 API Key 鉴权时，自动为所有 /api/ 请求添加 Header)
const _originalFetch = window.fetch;
window.fetch = function(input, init) {
  const apiKey = localStorage.getItem("gitrelease_api_key");
  if (apiKey) {
    init = init || {};
    init.headers = init.headers || {};
    if (init.headers instanceof Headers) {
      if (!init.headers.has("X-API-Key")) {
        init.headers.set("X-API-Key", apiKey);
      }
    } else if (Array.isArray(init.headers)) {
      init.headers.push(["X-API-Key", apiKey]);
    } else {
      if (!init.headers["X-API-Key"]) {
        init.headers["X-API-Key"] = apiKey;
      }
    }
  }
  return _originalFetch.call(this, input, init).then(async response => {
    if (response.status === 401 && typeof input === "string" && input.startsWith("/api/")) {
      const keyPrompt = prompt("该系统已开启 API Key 鉴权保护，请输入访问密钥：");
      if (keyPrompt) {
        localStorage.setItem("gitrelease_api_key", keyPrompt.trim());
        init = init || {};
        init.headers = init.headers || {};
        if (init.headers instanceof Headers) {
          init.headers.set("X-API-Key", keyPrompt.trim());
        } else if (!Array.isArray(init.headers)) {
          init.headers["X-API-Key"] = keyPrompt.trim();
        }
        return _originalFetch.call(this, input, init);
      }
    }
    return response;
  });
};

// ----------------- 仓库与规则标准化工具 -----------------

function normalizeRepo(repo) {
  if (!repo) return "";
  let r = repo.trim().replace(/^\/+|\/+$/g, "");
  if (r.includes("github.com/")) {
    r = r.split("github.com/").pop().replace(/^\/+|\/+$/g, "");
  }
  return r.toLowerCase();
}

function normalizeFilterRule(mode, includeRule) {
  const m = (mode || "keywords").trim().toLowerCase();
  const rule = (includeRule || "").trim();
  if (m === "keywords") {
    const parts = rule.split(",").map(p => p.trim().toLowerCase()).filter(Boolean).sort();
    return `keywords:${parts.join(",")}`;
  }
  return `regex:${rule.toLowerCase()}`;
}

// ----------------- 平台识别与别名智能自动生成系统 -----------------

function detectPlatformFromRule(text) {
  const s = (text || "").toLowerCase();
  if (!s.trim()) return "通用版";

  // 1. 操作系统判断
  let os = "";
  if (s.includes("apk") || s.includes("android")) {
    os = "Android";
  } else if (s.includes("dmg") || s.includes("darwin") || s.includes("macos") || s.includes("osx") || s.includes("mac")) {
    os = "macOS";
  } else if (s.includes("exe") || s.includes("msi") || s.includes("win") || s.includes("windows")) {
    os = "Windows";
  } else if (s.includes("deb") || s.includes("rpm") || s.includes("linux") || s.includes("appimage") || s.includes(".tar.gz") || s.includes(".tgz")) {
    os = "Linux";
  }

  // 2. CPU架构判断
  let arch = "";
  if (s.includes("arm64") || s.includes("aarch64") || s.includes("armv8") || s.includes("m1") || s.includes("apple silicon")) {
    arch = "ARM64";
  } else if (s.includes("x86_64") || s.includes("amd64")) {
    arch = (os === "Linux") ? "AMD64" : "x64";
  } else if (s.includes("x64") || s.includes("win64")) {
    arch = "x64";
  } else if (s.includes("armv7") || s.includes("armhf") || s.includes("armeabi") || s.includes("arm")) {
    arch = "ARM";
  } else if (s.includes("x86") || s.includes("i386") || s.includes("i686") || s.includes("win32")) {
    arch = "x86";
  } else if (s.includes("universal")) {
    arch = "通用版";
  }

  // 3. 发布形态判断
  let form = "";
  if (s.includes("portable") || s.includes("standalone") || s.includes("便携")) {
    form = "便携版";
  } else if (s.includes("setup") || s.includes("installer") || s.includes("install") || s.includes("安装") || s.includes("msi")) {
    form = "安装版";
  } else if (s.includes("appimage")) {
    form = "AppImage";
  } else if (s.includes("deb")) {
    form = "Deb";
  } else if (s.includes("rpm")) {
    form = "RPM";
  } else if (os === "Windows" && (s.includes(".zip") || s.includes("zip") || s.includes(".7z") || s.includes("7z"))) {
    form = "便携版";
  }

  // 4. 组合最终标准专属标识别名
  if (os === "Android") {
    if (arch === "通用版" || s.includes("universal")) return "Android 通用版";
    if (arch && arch !== "通用版") return `Android ${arch}`;
    return "Android";
  }

  if (os === "Windows") {
    let parts = ["Windows"];
    if (arch) parts.push(arch);
    if (form) parts.push(form);
    return parts.join(" ");
  }

  if (os === "Linux") {
    let parts = ["Linux"];
    if (arch) parts.push(arch);
    if (form && form !== "Deb" && form !== "RPM") parts.push(form);
    else if (form) parts.push(`(${form})`);
    return parts.join(" ");
  }

  if (os === "macOS") {
    if (arch === "ARM64") return "macOS ARM64";
    if (arch === "x64") return "macOS Intel (x64)";
    return "macOS";
  }

  if (arch && form) return `${arch} ${form}`;
  if (arch) return arch;
  if (form) return form;

  return "通用版";
}

let isSubNameManuallyEdited = false;

function autoUpdateSubName(force = false) {
  if (!force && isSubNameManuallyEdited) return;
  const nameInput = document.getElementById("taskName");
  const ruleInput = document.getElementById("assetInclude");
  const subInput = document.getElementById("taskSubName");
  const repoInput = document.getElementById("taskRepo");
  if (!subInput) return;

  // 若软件名称为空，但仓库已输入，自动从仓库地址提取软件名
  if (nameInput && !nameInput.value.trim() && repoInput && repoInput.value.trim()) {
    const rawRepo = repoInput.value.trim().replace(/\/+$/, '');
    const parts = rawRepo.split('/');
    if (parts.length > 0) {
      let candidate = parts[parts.length - 1];
      if (candidate.endsWith(".git")) candidate = candidate.slice(0, -4);
      if (candidate && !candidate.includes("github.com")) {
        nameInput.value = candidate;
      }
    }
  }

  const name = nameInput ? nameInput.value.trim() : "";
  const rule = ruleInput ? ruleInput.value.trim() : "";
  const plat = detectPlatformFromRule(rule);

  if (plat && plat !== "通用版") {
    subInput.value = plat;
  } else if (name) {
    subInput.value = `${name}-${plat}`;
  } else {
    subInput.value = plat;
  }
}

function forceReDetectSubName() {
  isSubNameManuallyEdited = false;
  autoUpdateSubName(true);
  showToast(`已智能识别并更新任务专属标识别名: 「${document.getElementById("taskSubName").value}」`, "info");
}

function applySubNamePreset(presetName) {
  const subInput = document.getElementById("taskSubName");
  if (subInput) {
    subInput.value = presetName;
    isSubNameManuallyEdited = true;
    showToast(`已套用专属标识别名: 「${presetName}」`, "info");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initEventListeners();
  updateViewModeButtons();
  loadSystemInfo();
  loadTasks();
  startPolling();
});

// ----------------- 白天 / 黑夜主题切换系统 -----------------

function initTheme() {
  const saved = localStorage.getItem("gitrelease_theme") || "dark";
  applyTheme(saved, false);
}

function toggleTheme() {
  const isDark = document.body.classList.contains("dark-theme");
  const nextTheme = isDark ? "light" : "dark";
  applyTheme(nextTheme, true);
}

function applyTheme(theme, showNotice = false) {
  if (theme === "light") {
    document.body.classList.remove("dark-theme");
    document.body.classList.add("light-theme");
    localStorage.setItem("gitrelease_theme", "light");
    if (showNotice) showToast("已切换至白天亮色主题", "info");
  } else {
    document.body.classList.remove("light-theme");
    document.body.classList.add("dark-theme");
    localStorage.setItem("gitrelease_theme", "dark");
    if (showNotice) showToast("已切换至夜间深色主题", "info");
  }
  updateThemeIcon();
}

function updateThemeIcon() {
  const iconEl = document.getElementById("themeIcon");
  const btnEl = document.getElementById("btnThemeToggle");
  if (!iconEl && !btnEl) return;
  const isDark = document.body.classList.contains("dark-theme");
  if (btnEl) {
    btnEl.title = isDark ? "当前为夜间模式，点击切换至白天亮色模式" : "当前为白天模式，点击切换至夜间深色模式";
    btnEl.innerHTML = `<i data-lucide="${isDark ? 'sun' : 'moon'}" id="themeIcon"></i>`;
  }
  if (window.lucide) window.lucide.createIcons();
}

function initEventListeners() {
  document.getElementById("btnAddTask").addEventListener("click", () => openTaskModal());
  document.getElementById("btnCheckAll").addEventListener("click", checkAllTasks);
  document.getElementById("btnSettings").addEventListener("click", openSettingsModal);
  document.getElementById("btnHistory").addEventListener("click", openHistoryModal);
  const btnLogs = document.getElementById("btnLogs");
  if (btnLogs) btnLogs.addEventListener("click", openLogsModal);

  // 批量操作浮动栏按钮事件监听
  const batchCheck = document.getElementById("batchBtnCheckAll");
  if (batchCheck) batchCheck.addEventListener("click", () => executeBatchAction("check"));
  const batchStart = document.getElementById("batchBtnStartAll");
  if (batchStart) batchStart.addEventListener("click", () => executeBatchAction("enable"));
  const batchPause = document.getElementById("batchBtnPauseAll");
  if (batchPause) batchPause.addEventListener("click", () => executeBatchAction("disable"));
  const batchDl = document.getElementById("batchBtnDownloadAll");
  if (batchDl) batchDl.addEventListener("click", () => executeBatchAction("download"));
  const batchDir = document.getElementById("batchBtnSetDir");
  if (batchDir) batchDir.addEventListener("click", openBatchDirModal);
  const batchDel = document.getElementById("batchBtnDeleteAll");
  if (batchDel) batchDel.addEventListener("click", () => executeBatchAction("delete"));

  // 防误触机制：阻止在添加/编辑任务和系统设置表单的输入框中按回车键导致意外保存提交
  ["taskForm", "settingsForm"].forEach(formId => {
    const form = document.getElementById(formId);
    if (form) {
      form.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && e.target.tagName !== "TEXTAREA") {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      });
    }
  });

  document.getElementById("taskSearch").addEventListener("input", (e) => {
    filterTasks(e.target.value);
  });

  // 监听软件名称与包含规则，自动计算更新任务专属标识别名 (软件名称+{platform})
  const taskRepoInput = document.getElementById("taskRepo");
  if (taskRepoInput) {
    taskRepoInput.addEventListener("input", () => autoUpdateSubName());
    taskRepoInput.addEventListener("change", () => autoUpdateSubName());
  }

  const taskNameInput = document.getElementById("taskName");
  if (taskNameInput) {
    taskNameInput.addEventListener("input", () => autoUpdateSubName());
  }
  const taskSubInput = document.getElementById("taskSubName");
  if (taskSubInput) {
    taskSubInput.addEventListener("input", (e) => {
      isSubNameManuallyEdited = e.target.value.trim().length > 0;
    });
  }

  const assetInc = document.getElementById("assetInclude");
  if (assetInc) {
    assetInc.addEventListener("input", () => {
      renderMemoryTags("include");
      autoUpdateSubName();
    });
  }
  const assetExc = document.getElementById("assetExclude");
  if (assetExc) assetExc.addEventListener("input", () => renderMemoryTags("exclude"));

  const dlDirInput = document.getElementById("downloadDir");
  if (dlDirInput) {
    dlDirInput.addEventListener("input", (e) => {
      const val = e.target.value.trim();
      if (val) localStorage.setItem("gitrelease_saved_dir", val);
      const sel = document.getElementById("downloadDirSelect");
      if (sel) {
        sel.value = Array.from(sel.options).some(o => o.value === val) ? val : "";
      }
    });
  }
}

// ----------------- 数据加载与轮询 -----------------

async function loadTasks() {
  try {
    const res = await fetch("/api/tasks");
    const json = await res.json();
    if (json.status === "ok") {
      tasks = json.data || [];
      const searchEl = document.getElementById("taskSearch");
      if (searchEl && searchEl.value.trim()) {
        filterTasks(searchEl.value);
      } else {
        renderTasks(tasks);
      }
      updateMetrics();
    }
  } catch (err) {
    console.error("加载任务列表失败:", err);
  }
}

async function loadSystemInfo() {
  const diskEl = document.getElementById("navDiskSpace");
  const deviceEl = document.getElementById("navDeviceName");
  const diskBadge = document.getElementById("diskBadge");

  try {
    const res = await fetch("/api/system_info");
    const json = await res.json();
    if (json.status === "ok") {
      // 动态同步自定义面板主标题与副标题
      if (json.panel_title) {
        document.title = `${json.panel_title} - ${json.panel_subtitle || 'GitHub 升级自动监测与多设备下载'}`;
        const titleEl = document.querySelector(".brand-text .title");
        if (titleEl) titleEl.textContent = json.panel_title;
      }
      if (json.panel_subtitle) {
        const subEl = document.querySelector(".brand-text .subtitle");
        if (subEl) subEl.textContent = json.panel_subtitle;
      }
      if (json.custom_download_dirs !== undefined) {
        localStorage.setItem("gitrelease_custom_dirs", json.custom_download_dirs);
      }
      if (json.custom_include_tags !== undefined) {
        localStorage.setItem("gitrelease_custom_include_tags", json.custom_include_tags);
      }
      if (json.custom_exclude_tags !== undefined) {
        localStorage.setItem("gitrelease_custom_exclude_tags", json.custom_exclude_tags);
      }

      if (deviceEl) deviceEl.textContent = json.device_name || "Linux-01";
      if (json.disk && typeof json.disk.free_gb === "number") {
        const freeGb = json.disk.free_gb;
        const freeText = freeGb >= 1024 ? `${(freeGb / 1024).toFixed(2)} TB` : `${freeGb} GB`;
        const pctText = json.disk.percent !== undefined ? ` (${json.disk.percent}%已用)` : "";
        if (diskEl) diskEl.textContent = `余 ${freeText}${pctText}`;
        if (diskBadge) {
          const totalText = (json.disk.total_gb >= 1024) ? `${(json.disk.total_gb / 1024).toFixed(2)} TB` : `${json.disk.total_gb} GB`;
          const usedText = (json.disk.used_gb >= 1024) ? `${(json.disk.used_gb / 1024).toFixed(2)} TB` : `${json.disk.used_gb} GB`;
          diskBadge.title = `存储路径: ${json.disk.path || json.default_dir || '本地磁盘'}\n总容量: ${totalText} | 已用: ${usedText} (${json.disk.percent || 0}%)\n剩余可用: ${freeText}`;
        }
      } else {
        if (diskEl) diskEl.textContent = "空间正常";
      }
    } else {
      if (diskEl) diskEl.textContent = "获取失败";
    }
  } catch (err) {
    console.error("加载系统信息异常:", err);
    if (diskEl && diskEl.textContent === "计算中...") {
      diskEl.textContent = "连接中...";
    }
  }
}

let sysInfoPollCounter = 0;
function startPolling() {
  if (pollingTimer) clearInterval(pollingTimer);
  pollingTimer = setInterval(async () => {
    sysInfoPollCounter++;
    await loadTasks();
    // 每 3 次轮询（约 9 秒）自动刷新一次磁盘与系统状态
    if (sysInfoPollCounter % 3 === 0) {
      await loadSystemInfo();
    }
  }, 3000);
}

// ----------------- 统计与渲染 -----------------

function updateMetrics() {
  const total = tasks.length;
  const active = tasks.filter(t => t.enabled).length;
  const downloading = tasks.filter(t => t.active_download && t.active_download.status === "downloading").length;

  document.getElementById("metricTotal").textContent = total;
  document.getElementById("metricActive").textContent = active;
  document.getElementById("metricDownloading").textContent = downloading;

  fetch("/api/history")
    .then(r => r.json())
    .then(data => {
      if (data.status === "ok") {
        document.getElementById("metricHistoryCount").textContent = data.data.length;
      }
    }).catch(() => {});
}

let currentViewMode = localStorage.getItem("gitrelease_view_mode") || "grouped";
if (currentViewMode === "kanban") currentViewMode = "grouped";
let currentStatusFilter = "all";
let currentSortMode = "time_desc";

function setViewMode(mode) {
  if (mode === "kanban") mode = "grouped";
  currentViewMode = mode;
  localStorage.setItem("gitrelease_view_mode", mode);
  updateViewModeButtons();
  renderTasks(tasks);
}

function updateViewModeButtons() {
  const modes = ["flat", "list", "timeline", "grouped"];
  modes.forEach(m => {
    const id = "viewBtn" + m.charAt(0).toUpperCase() + m.slice(1);
    const btn = document.getElementById(id);
    if (btn) btn.classList.toggle("active", currentViewMode === m);
  });
  const container = document.getElementById("taskListContainer");
  if (container) {
    container.className = `task-views-container view-${currentViewMode}`;
  }
}

function setStatusFilter(status) {
  currentStatusFilter = status;
  const tabs = document.querySelectorAll("#statusFilterTabs .filter-tab");
  tabs.forEach(tab => {
    tab.classList.toggle("active", tab.dataset.status === status);
  });
  renderTasks(tasks);
}

function setSortMode(mode) {
  currentSortMode = mode;
  renderTasks(tasks);
}

function filterTasks(query) {
  renderTasks(tasks);
}

function applyFilterAndSort(taskList) {
  if (!taskList || !taskList.length) return [];

  // 1. 搜索框文本匹配 (软件名、专属标识、GitHub仓库)
  const searchEl = document.getElementById("taskSearch");
  const q = searchEl ? searchEl.value.toLowerCase().trim() : "";
  let list = taskList;
  if (q) {
    list = list.filter(t => 
      (t.name || "").toLowerCase().includes(q) || 
      (t.sub_name || "").toLowerCase().includes(q) || 
      (t.repo || "").toLowerCase().includes(q)
    );
  }

  // 2. 状态标签筛选 (全部 / 有新版本 / 下载中 / 已是最新 / 失败异常)
  if (currentStatusFilter !== "all") {
    list = list.filter(t => {
      const isDownloading = Boolean(t.active_download && t.active_download.status === "downloading");
      const hasUpdate = Boolean(t.remote_version && t.local_version && t.remote_version !== t.local_version);
      const isLatest = Boolean(t.remote_version && t.local_version && t.remote_version === t.local_version && !isDownloading);
      const isError = Boolean(t.status === "error" || (t.status_message && (t.status_message.includes("失败") || t.status_message.includes("异常"))));

      if (currentStatusFilter === "update") return hasUpdate;
      if (currentStatusFilter === "downloading") return isDownloading;
      if (currentStatusFilter === "success") return isLatest;
      if (currentStatusFilter === "error") return isError;
      return true;
    });
  }

  // 3. 排序管道
  const sorted = [...list];
  if (currentSortMode === "time_desc") {
    sorted.sort((a, b) => {
      const ta = a.last_checked_at || a.last_downloaded_at || a.created_at || "";
      const tb = b.last_checked_at || b.last_downloaded_at || b.created_at || "";
      return tb.localeCompare(ta);
    });
  } else if (currentSortMode === "name_asc") {
    sorted.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
  } else if (currentSortMode === "status") {
    sorted.sort((a, b) => {
      const getScore = (t) => {
        if (t.active_download && t.active_download.status === "downloading") return 10;
        if (t.remote_version && t.local_version && t.remote_version !== t.local_version) return 8;
        if (t.status === "error") return 6;
        if (t.enabled) return 4;
        return 1;
      };
      return getScore(b) - getScore(a);
    });
  } else if (currentSortMode === "remote_ver") {
    sorted.sort((a, b) => (b.remote_version || "").localeCompare(a.remote_version || ""));
  }

  return sorted;
}


function renderTaskCardHtml(task) {
  const isDownloading = task.active_download && task.active_download.status === "downloading";
  const progress = isDownloading ? (task.active_download.progress || 0) : 0;
  const speed = isDownloading ? (task.active_download.speed || "") : "";
  const fileName = isDownloading ? (task.active_download.file_name || "") : "";

  const hasNewVersion = task.remote_version && task.local_version && task.remote_version !== task.local_version;

  const includeTokens = (task.asset_filter_include || "").split(",").map(s => s.trim()).filter(Boolean);
  const excludeTokens = (task.asset_filter_exclude || "").split(",").map(s => s.trim()).filter(Boolean);

  let statusDotClass = "idle";
  if (task.status === "checking") statusDotClass = "checking";
  else if (isDownloading) statusDotClass = "downloading";
  else if (task.status === "warning") statusDotClass = "warning";
  else if (task.status === "error") statusDotClass = "error";

  const customDirText = task.download_dir ? task.download_dir : "全局默认目录";
  const subNameText = task.sub_name ? task.sub_name : task.name;

  return `
    <div class="task-card ${!task.enabled ? 'is-disabled' : ''} ${selectedTaskIds.has(task.id) ? 'is-selected' : ''}" id="card-${task.id}">
      <div class="card-top">
        <div style="display:flex; align-items:flex-start; gap:10px;">
          <input type="checkbox" class="task-batch-checkbox" style="margin-top:4px;" ${selectedTaskIds.has(task.id) ? 'checked' : ''} onchange="toggleTaskSelection('${task.id}', this.checked)" title="勾选任务进行批量操作">
          <div class="app-meta">
            <div class="app-name">
              <span onclick="openRepoDetailModal('${task.id}')" style="cursor:pointer;" title="点击查看该仓库详细资产与版本信息">${escapeHtml(task.name)}</span>
              ${task.sub_name ? `<span class="subname-badge" title="专属标识别名">${escapeHtml(task.sub_name)}</span>` : ''}
              ${task.include_prerelease ? '<span class="tag-badge">Beta/Pre</span>' : ''}
            </div>
            <a href="https://github.com/${escapeHtml(task.repo)}" target="_blank" class="app-repo">
              <i data-lucide="github"></i>
              <span>${escapeHtml(task.repo)}</span>
            </a>
          </div>
        </div>
        <label class="switch" title="${task.enabled ? '点击暂停监控' : '点击启用监控'}">
          <input type="checkbox" ${task.enabled ? "checked" : ""} onchange="toggleTask('${task.id}')">
          <span class="slider"></span>
        </label>
      </div>

      <div class="version-badge-group">
        <div class="ver-box">
          <span class="ver-label">本地已存版本</span>
          <span class="ver-val">${escapeHtml(task.local_version || "无")}</span>
        </div>
        <div class="ver-arrow"><i data-lucide="arrow-right"></i></div>
        <div class="ver-box">
          <span class="ver-label">线上最新版本</span>
          <span class="ver-val ${hasNewVersion ? 'has-update' : ''}">
            ${escapeHtml(task.remote_version || "等待检测")}
            ${hasNewVersion ? '<i data-lucide="sparkle"></i>' : ''}
          </span>
        </div>
      </div>

      <!-- 关键词筛选与保存路径复合展示 (精致单行/自适应) -->
      <div class="task-card-meta-row">
        <div class="filter-tags" title="资产过滤规则">
          <span class="tag-badge">${task.filter_mode === 'regex' ? '正则' : '包含'}</span>
          ${includeTokens.slice(0, 2).map(t => `<span class="tag-badge include">+ ${escapeHtml(t)}</span>`).join('')}
          ${excludeTokens.slice(0, 2).map(t => `<span class="tag-badge exclude">- ${escapeHtml(t)}</span>`).join('')}
        </div>
        <div class="target-path-info" title="下载目标路径: ${escapeHtml(customDirText)}">
          <i data-lucide="folder"></i>
          <code>${escapeHtml(customDirText)}</code>
        </div>
      </div>

      ${isDownloading ? `
        <div class="download-progress-wrap">
          <div class="progress-header">
            <span class="progress-file" title="${escapeHtml(fileName)}">${escapeHtml(fileName)}</span>
            <span class="progress-speed">${speed} (${progress}%)</span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill" style="width: ${progress}%"></div>
          </div>
        </div>
      ` : ''}

      <!-- 独立行 1: 状态展示条 (全宽立体状态胶囊) -->
      <div class="task-status-bar">
        <div class="status-indicator">
          <div class="status-dot ${statusDotClass}"></div>
          <span class="status-text" title="${escapeHtml(task.status_message || '')}">${escapeHtml(task.status_message || '就绪')}</span>
        </div>
        ${task.last_downloaded_at ? `<span class="status-time" title="最近下载同步时间"><i data-lucide="clock"></i> ${escapeHtml(task.last_downloaded_at.slice(5, 16))}</span>` : (task.last_checked_at ? `<span class="status-time" title="最近检测时间"><i data-lucide="activity"></i> ${escapeHtml(task.last_checked_at.slice(5, 16))}</span>` : '')}
      </div>

      <!-- 独立行 2: 操作工具栏 (全宽等高按钮网格，彻底避免按钮挤压遮挡) -->
      <div class="task-actions-toolbar">
        <button type="button" class="action-btn" onclick="openRepoDetailModal('${task.id}')" title="查看仓库多资产与版本详情">
          <i data-lucide="package"></i>
          <span>详情</span>
        </button>
        <button type="button" class="action-btn" onclick="viewReleaseNotes('${task.id}')" title="查看软件更新日志 (Release Notes)">
          <i data-lucide="file-text"></i>
          <span>日志</span>
        </button>
        <button type="button" class="action-btn" onclick="checkSingleTask('${task.id}')" title="立即联网检测新Release">
          <i data-lucide="refresh-cw"></i>
          <span>检测</span>
        </button>
        <button type="button" class="action-btn action-btn-download" onclick="forceDownloadTask('${task.id}')" title="强制重新拉取下载最新版本">
          <i data-lucide="download"></i>
          <span>下载</span>
        </button>
        <button type="button" class="action-btn" onclick="copyTask('${task.id}')" title="一键复制配置新建任务">
          <i data-lucide="copy"></i>
          <span>复制</span>
        </button>
        <button type="button" class="action-btn" onclick="editTask('${task.id}')" title="编辑任务配置">
          <i data-lucide="edit-3"></i>
          <span>编辑</span>
        </button>
        <button type="button" class="action-btn action-btn-danger" onclick="deleteTask('${task.id}')" title="删除该监控任务">
          <i data-lucide="trash-2"></i>
          <span>删除</span>
        </button>
      </div>
    </div>
  `;
}

function renderTasks(taskList) {
  const container = document.getElementById("taskListContainer");
  const empty = document.getElementById("emptyState");

  const filteredList = applyFilterAndSort(taskList || []);

  if (!filteredList || filteredList.length === 0) {
    container.innerHTML = "";
    empty.style.display = "block";
    const emptyTitle = empty.querySelector("h3");
    const emptyP = empty.querySelector("p");
    if (emptyTitle && emptyP) {
      if ((taskList || []).length > 0) {
        emptyTitle.textContent = "未匹配到符合条件的应用";
        emptyP.textContent = "当前筛选标签或搜索关键词下暂无匹配结果，可尝试重置搜索或切换上方状态筛选标签。";
      } else {
        emptyTitle.textContent = "暂无监控任务";
        emptyP.textContent = "点击右上角“添加监控任务”按钮，配置需要自动跟踪下载的 GitHub 软件仓库。";
      }
    }
    return;
  }
  empty.style.display = "none";
  container.className = `task-views-container view-${currentViewMode}`;

  if (currentViewMode === "flat") {
    renderFlatView(filteredList);
  } else if (currentViewMode === "list") {
    renderListView(filteredList);
  } else if (currentViewMode === "timeline") {
    renderTimelineView(filteredList);
  } else {
    renderGroupedView(filteredList);
  }

  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// ----------------- 视图 1: 平铺网格视图 -----------------
function renderFlatView(taskList) {
  const container = document.getElementById("taskListContainer");
  container.innerHTML = taskList.map(task => renderTaskCardHtml(task)).join("");
}

// ----------------- 视图 2: 仓库聚合分组视图 -----------------
function renderGroupedView(taskList) {
  const container = document.getElementById("taskListContainer");
  const repoGroups = {};
  taskList.forEach(task => {
    const key = normalizeRepo(task.repo) || "unknown";
    if (!repoGroups[key]) repoGroups[key] = [];
    repoGroups[key].push(task);
  });

  let html = "";
  Object.keys(repoGroups).forEach(repoKey => {
    const groupTasks = repoGroups[repoKey];
    if (groupTasks.length === 1) {
      html += renderTaskCardHtml(groupTasks[0]);
    } else {
      const firstTask = groupTasks[0];
      const repoName = firstTask.repo;
      const softwareName = firstTask.name;
      const repoEscaped = escapeHtml(repoName);
      html += `
        <div class="repo-group-card">
          <div class="repo-group-header">
            <div class="repo-group-title-wrap">
              <div class="repo-badge-icon">
                <i data-lucide="folder-git-2"></i>
              </div>
              <div class="repo-group-info">
                <div class="repo-group-name">
                  <span onclick="openRepoDetailModal('${firstTask.id}')" style="cursor:pointer;" title="点击查看仓库多资产详情">${escapeHtml(softwareName)}</span>
                  <span class="repo-count-pill">${groupTasks.length} 个分支任务</span>
                </div>
                <a href="https://github.com/${repoEscaped}" target="_blank" class="repo-group-link">
                  <i data-lucide="github"></i> ${repoEscaped}
                </a>
              </div>
            </div>
            <div class="repo-group-actions">
              <button class="btn btn-sm btn-secondary" onclick="checkRepoAllTasks('${escapeJs(repoName)}')" title="一键检查该仓库下所有分支的最新Release">
                <i data-lucide="refresh-cw"></i> 检查全部分支
              </button>
              <button class="btn btn-sm btn-primary" onclick="openTaskModalForRepo('${escapeJs(repoName)}', '${escapeJs(softwareName)}')" title="为此仓库快捷添加新的平台或架构分支">
                <i data-lucide="plus"></i> 添加分支任务
              </button>
            </div>
          </div>
          <div class="repo-subtasks-grid">
            ${groupTasks.map(t => renderTaskCardHtml(t)).join("")}
          </div>
        </div>
      `;
    }
  });
  container.innerHTML = html;
}

// ----------------- 视图 3: 高密度列表视图 (ListView - 极简半高设计与滚动位置锁定) -----------------
// 精炼紧凑设计：行高减半，消除多层堆叠，操作栏精简为【下载/编辑/删除】3联核心按键，并锁定横向滚动位置防止轮询重置
function renderListView(taskList) {
  const container = document.getElementById("taskListContainer");
  const oldWrap = container.querySelector(".task-list-view-wrap");
  const previousScrollLeft = oldWrap ? oldWrap.scrollLeft : (window._lastListScrollLeft || 0);

  const rows = taskList.map(task => {
    const isDownloading = Boolean(task.active_download && task.active_download.status === "downloading");
    const progress = isDownloading ? (task.active_download.progress || 0) : 0;
    const speed = isDownloading ? (task.active_download.speed || "") : "";
    const fileName = isDownloading ? (task.active_download.file_name || "") : "";
    const hasNewVersion = Boolean(task.remote_version && task.local_version && task.remote_version !== task.local_version);
    const repoEscaped = escapeHtml(task.repo);
    const customDirText = task.download_dir ? task.download_dir : "全局默认目录";
    const subNameText = task.sub_name ? task.sub_name : task.name;

    const includeTokens = (task.asset_filter_include || "").split(",").map(s => s.trim()).filter(Boolean);
    const excludeTokens = (task.asset_filter_exclude || "").split(",").map(s => s.trim()).filter(Boolean);

    let statusDotClass = "idle";
    let statusText = task.status_message || "就绪";
    if (task.status === "checking") {
      statusDotClass = "checking";
      statusText = "检测中...";
    } else if (isDownloading) {
      statusDotClass = "downloading";
      statusText = "传输中";
    } else if (task.status === "error") {
      statusDotClass = "error";
      statusText = task.status_message || "失败";
    } else if (hasNewVersion) {
      statusDotClass = "warning";
      statusText = "有新版";
    }

    let downloadProgressCol = '<span style="color:var(--text-muted);font-size:0.72rem;">空闲</span>';
    if (isDownloading) {
      downloadProgressCol = `
        <div style="min-width:85px;">
          <div style="display:flex; justify-content:space-between; font-size:0.68rem; margin-bottom:1px; line-height:1;">
            <span style="font-family:var(--font-mono); color:#93c5fd; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:55px;" title="${escapeHtml(fileName)}">${escapeHtml(fileName)}</span>
            <span style="font-family:var(--font-mono); color:#60a5fa; font-weight:600;">${progress}%</span>
          </div>
          <div class="progress-bar-bg" style="height:3px;">
            <div class="progress-bar-fill" style="width:${progress}%;"></div>
          </div>
        </div>
      `;
    } else if (task.last_downloaded_at) {
      downloadProgressCol = `<span style="color:#10b981;font-size:0.72rem;display:inline-flex;align-items:center;gap:3px;" title="最近下载完成: ${escapeHtml(task.last_downloaded_at)}"><i data-lucide="check" style="width:12px;height:12px;"></i> 已同步</span>`;
    }

    const checkTimeRaw = task.last_checked_at || task.created_at || "";
    const checkTimeStr = checkTimeRaw.length >= 16 ? checkTimeRaw.slice(5, 16) : (checkTimeRaw || "待检测");

    return `
      <tr class="list-row ${!task.enabled ? 'is-disabled' : ''} ${selectedTaskIds.has(task.id) ? 'is-selected' : ''}" id="list-row-${task.id}">
        <!-- 0. 批量选择复选框 -->
        <td style="width: 32px; text-align: center;">
          <input type="checkbox" class="task-batch-checkbox" ${selectedTaskIds.has(task.id) ? 'checked' : ''} onchange="toggleTaskSelection('${task.id}', this.checked)">
        </td>

        <!-- 1. 启停监控开关 -->
        <td style="width: 48px; text-align: center;">
          <label class="switch" style="transform:scale(0.75); margin:0 auto;" title="${task.enabled ? '点击暂停监控' : '点击启用监控'}">
            <input type="checkbox" ${task.enabled ? "checked" : ""} onchange="toggleTask('${task.id}')">
            <span class="slider"></span>
          </label>
        </td>

        <!-- 2. 软件名称与仓库 (扁平单行整合，高度减半) -->
        <td>
          <div class="list-repo-cell">
            <div class="list-repo-title">
              <span onclick="openRepoDetailModal('${task.id}')" class="list-repo-name" title="点击查看仓库详细资产与说明">${escapeHtml(task.name)}</span>
              <span class="list-subname-badge" title="专属标识: ${escapeHtml(subNameText)}">${escapeHtml(subNameText)}</span>
              ${task.include_prerelease ? '<span class="tag-badge" style="font-size:0.6rem;padding:0.05rem 0.25rem;">Pre</span>' : ''}
              <a href="https://github.com/${repoEscaped}" target="_blank" class="list-repo-link" title="在 GitHub 查看: ${repoEscaped}">
                <i data-lucide="github"></i>
              </a>
              <span class="list-dir-icon-tip" title="存放目录: ${escapeHtml(customDirText)}">
                <i data-lucide="folder"></i>
              </span>
            </div>
          </div>
        </td>

        <!-- 3. 版本对比 -->
        <td style="width: 145px;">
          <div class="list-ver-group">
            <span class="list-ver-badge">${escapeHtml(task.local_version || "无")}</span>
            <i data-lucide="arrow-right" style="width:10px;height:10px;color:var(--text-muted);flex-shrink:0;"></i>
            <span class="list-ver-badge ${hasNewVersion ? 'has-update' : ''}">
              ${escapeHtml(task.remote_version || "未检")}
              ${hasNewVersion ? '<i data-lucide="sparkle" style="width:9px;height:9px;vertical-align:middle;margin-left:1px;"></i>' : ''}
            </span>
          </div>
        </td>

        <!-- 4. 包含/排除特征规则 -->
        <td style="width: 110px;">
          <div class="filter-tags" style="margin:0; gap:0.2rem;">
            <span class="tag-badge" style="font-size:0.65rem;padding:0.05rem 0.3rem;">${task.filter_mode === 'regex' ? '正则' : '包含'}</span>
            ${includeTokens.slice(0, 1).map(t => `<span class="tag-badge include" style="font-size:0.65rem;padding:0.05rem 0.3rem;">+${escapeHtml(t)}</span>`).join('')}
            ${includeTokens.length > 1 ? `<span class="tag-badge include" style="font-size:0.6rem;padding:0.05rem 0.25rem;">+${includeTokens.length - 1}</span>` : ''}
          </div>
        </td>

        <!-- 5. 更新状态与指示灯 -->
        <td style="width: 120px;">
          <div class="status-indicator" style="font-size:0.75rem;">
            <div class="status-dot ${statusDotClass}" style="width:6px;height:6px;"></div>
            <span class="status-text" style="font-size:0.72rem;" title="${escapeHtml(task.status_message || '')}">${escapeHtml(statusText)}</span>
          </div>
        </td>

        <!-- 6. 下载进度 -->
        <td style="width: 100px;">${downloadProgressCol}</td>

        <!-- 7. 检测时间 -->
        <td style="width: 90px; font-family:var(--font-mono); font-size:0.72rem; color:var(--text-muted); white-space:nowrap;">
          ${escapeHtml(checkTimeStr)}
        </td>

        <!-- 8. 操作按钮 (按产品规划精炼为高频3大黄金按键：下载 / 编辑 / 删除，大幅减小宽度) -->
        <td style="width: 80px; text-align: right;">
          <div class="list-actions">
            <button type="button" class="btn-list-action btn-download" onclick="forceDownloadTask('${task.id}')" title="强制重新拉取下载最新版本">
              <i data-lucide="download"></i>
            </button>
            <button type="button" class="btn-list-action" onclick="editTask('${task.id}')" title="编辑任务配置">
              <i data-lucide="edit-3"></i>
            </button>
            <button type="button" class="btn-list-action btn-danger" onclick="deleteTask('${task.id}')" title="删除该监控任务">
              <i data-lucide="trash-2"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  const existingTable = container.querySelector(".task-list-table");
  const existingTbody = existingTable ? existingTable.querySelector("tbody") : null;
  const selectAllBox = container.querySelector("#selectAllList");

  // 滚动条与无损局部刷新：若已存在表格，仅刷新 tbody，彻底杜绝外层重构导致的滚动条跳回最前bug！
  if (existingTbody && oldWrap) {
    existingTbody.innerHTML = rows;
    if (selectAllBox) {
      selectAllBox.checked = taskList.length > 0 && selectedTaskIds.size === taskList.length;
    }
  } else {
    container.innerHTML = `
      <div class="task-list-view-wrap">
        <table class="task-list-table">
          <thead>
            <tr>
              <th style="width: 32px; text-align: center;"><input type="checkbox" id="selectAllList" ${taskList.length > 0 && selectedTaskIds.size === taskList.length ? 'checked' : ''} onchange="toggleSelectAll(this.checked)"></th>
              <th style="width: 48px; text-align: center;">监控</th>
              <th>软件与仓库</th>
              <th style="width: 145px;">版本对比</th>
              <th style="width: 110px;">规则</th>
              <th style="width: 120px;">状态</th>
              <th style="width: 100px;">进度</th>
              <th style="width: 90px;">检测时间</th>
              <th style="width: 80px; text-align: right;">操作</th>
            </tr>
          </thead>
          <tbody>
            ${rows}
          </tbody>
        </table>
      </div>
    `;

    const newWrap = container.querySelector(".task-list-view-wrap");
    if (newWrap) {
      newWrap.addEventListener("scroll", () => {
        window._lastListScrollLeft = newWrap.scrollLeft;
      }, { passive: true });
      if (previousScrollLeft > 0) {
        newWrap.scrollLeft = previousScrollLeft;
      }
    }
  }
}

// ----------------- 视图 4: 活动时间线视图 (TimelineView) -----------------
// 彻底解决点击空白问题：深度全量聚合任务全部生命周期事件（创建、就绪、更新、下载、检测、异常），并保证 100% 容错防崩
let currentTimelineFilter = "all";

function setTimelineFilter(filterType) {
  currentTimelineFilter = filterType;
  renderTimelineView(tasks);
}

function renderTimelineView(taskList) {
  const container = document.getElementById("taskListContainer");
  const events = [];

  // 安全提取时间字符串辅助函数
  const safeTime = (str) => {
    if (!str) return "";
    const s = String(str).trim().replace("T", " ");
    return s.length >= 19 ? s.slice(0, 19) : s;
  };

  (taskList || []).forEach(task => {
    // 1. 正在传输中事件
    if (task.active_download && task.active_download.status === "downloading") {
      events.push({
        time: task.active_download.start_time ? safeTime(new Date(task.active_download.start_time * 1000).toISOString()) : "刚刚",
        type: "downloading",
        title: `正在下载传输: ${task.name}`,
        desc: `目标文件: ${task.active_download.file_name || '安装包'} (已完成 ${task.active_download.progress || 0}%, 传输速度: ${task.active_download.speed || '计算中'})`,
        task: task
      });
    }

    // 2. 发现新版本升级事件
    if (task.remote_version && task.local_version && task.remote_version !== task.local_version) {
      events.push({
        time: safeTime(task.last_checked_at) || "刚刚",
        type: "update",
        title: `发现新版本: ${task.name}`,
        desc: `检测到新版本就绪: ${task.local_version} ➔ ${task.remote_version} (仓库: ${task.repo})`,
        task: task
      });
    }

    // 3. 同步下载完成事件
    if (task.last_downloaded_at) {
      events.push({
        time: safeTime(task.last_downloaded_at),
        type: "success",
        title: `成功下载就绪: ${task.name}`,
        desc: `安装包已同步并完成校验。当前本地版本: ${task.local_version || task.remote_version}`,
        task: task
      });
    }

    // 4. 失败或异常事件
    if (task.status === "error" || (task.status_message && (task.status_message.includes("失败") || task.status_message.includes("超时")))) {
      events.push({
        time: safeTime(task.last_checked_at) || safeTime(task.created_at) || "刚刚",
        type: "error",
        title: `检测/下载异常: ${task.name}`,
        desc: task.status_message || "连接 GitHub API 或下载服务器异常，系统将自动重试",
        task: task
      });
    } else if (task.last_checked_at) {
      // 5. 联网版本对齐事件
      events.push({
        time: safeTime(task.last_checked_at),
        type: "info",
        title: `版本检查对齐: ${task.name}`,
        desc: task.status_message || `已与 GitHub Release 对齐完成，最新版本为 ${task.remote_version || '最新'}`,
        task: task
      });
    }

    // 6. 监控任务创建就绪事件（兜底保证即使刚添加未检测也有时间线节点）
    if (task.created_at) {
      events.push({
        time: safeTime(task.created_at),
        type: "ready",
        title: `建立监控任务: ${task.name}`,
        desc: `已纳入自动追踪体系 (仓库: ${task.repo}, 检查周期: ${task.cron_expr || (task.check_interval + '分钟')})`,
        task: task
      });
    }
  });

  // 安全按时间倒序排序
  events.sort((a, b) => String(b.time || "").localeCompare(String(a.time || "")));

  // 根据当前时间线分类过滤
  let displayEvents = events;
  if (currentTimelineFilter !== "all") {
    displayEvents = events.filter(ev => {
      if (currentTimelineFilter === "update") return ev.type === "update";
      if (currentTimelineFilter === "downloading") return ev.type === "downloading";
      if (currentTimelineFilter === "success") return ev.type === "success";
      if (currentTimelineFilter === "error") return ev.type === "error";
      return true;
    });
  }

  // 渲染时间线顶部控制与过滤栏
  const filterToolbarHtml = `
    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem; margin-bottom:1.5rem; padding:0.75rem 1rem; background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md);">
      <div style="display:flex; align-items:center; gap:0.5rem; font-size:0.85rem; color:var(--text-primary);">
        <i data-lucide="clock" style="width:16px;height:16px;color:var(--accent-primary);"></i>
        <span><strong>活动流转时间线</strong> (共 ${events.length} 条记录)</span>
      </div>
      <div style="display:flex; gap:0.35rem; flex-wrap:wrap;">
        <button type="button" class="btn btn-sm ${currentTimelineFilter === 'all' ? 'btn-primary' : 'btn-secondary'}" onclick="setTimelineFilter('all')" style="padding:2px 8px;font-size:0.75rem;">全部</button>
        <button type="button" class="btn btn-sm ${currentTimelineFilter === 'update' ? 'btn-primary' : 'btn-secondary'}" onclick="setTimelineFilter('update')" style="padding:2px 8px;font-size:0.75rem;">新版更新</button>
        <button type="button" class="btn btn-sm ${currentTimelineFilter === 'downloading' ? 'btn-primary' : 'btn-secondary'}" onclick="setTimelineFilter('downloading')" style="padding:2px 8px;font-size:0.75rem;">传输下载</button>
        <button type="button" class="btn btn-sm ${currentTimelineFilter === 'success' ? 'btn-primary' : 'btn-secondary'}" onclick="setTimelineFilter('success')" style="padding:2px 8px;font-size:0.75rem;">完成就绪</button>
        <button type="button" class="btn btn-sm ${currentTimelineFilter === 'error' ? 'btn-primary' : 'btn-secondary'}" onclick="setTimelineFilter('error')" style="padding:2px 8px;font-size:0.75rem;">异常失败</button>
      </div>
    </div>
  `;

  if (displayEvents.length === 0) {
    container.innerHTML = `
      <div class="timeline-container">
        ${filterToolbarHtml}
        <div style="text-align:center; padding:3rem 1rem; color:var(--text-muted); background:var(--bg-card); border:1px dashed var(--border-color); border-radius:var(--radius-lg);">
          <i data-lucide="inbox" style="width:36px;height:36px;margin-bottom:0.5rem;color:var(--text-muted);"></i>
          <div>当前筛选条件下暂无活动记录</div>
        </div>
      </div>
    `;
    if (window.lucide) window.lucide.createIcons();
    return;
  }

  const itemsHtml = displayEvents.slice(0, 40).map(ev => {
    let dotClass = ev.type;
    let iconName = "activity";
    if (ev.type === "success") iconName = "check-circle-2";
    else if (ev.type === "update") iconName = "sparkles";
    else if (ev.type === "downloading") iconName = "download-cloud";
    else if (ev.type === "error") iconName = "alert-circle";
    else if (ev.type === "ready") iconName = "plus-circle";

    const subNameText = ev.task && (ev.task.sub_name || ev.task.name);

    return `
      <div class="timeline-item">
        <div class="timeline-dot ${dotClass}"></div>
        <div class="timeline-card">
          <div class="timeline-header">
            <div class="timeline-title-row">
              <i data-lucide="${iconName}" style="width:16px;height:16px;"></i>
              <span style="font-weight:600; color:var(--text-primary);">${escapeHtml(ev.title)}</span>
              ${subNameText ? `<span class="subname-badge" style="font-size:0.68rem;">${escapeHtml(subNameText)}</span>` : ''}
            </div>
            <div class="timeline-time"><i data-lucide="clock" style="width:12px;height:12px;"></i> ${escapeHtml(ev.time)}</div>
          </div>
          <div class="timeline-desc">${escapeHtml(ev.desc)}</div>
          ${ev.task ? `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:0.6rem; padding-top:0.4rem; border-top:1px solid rgba(255,255,255,0.05); font-size:0.75rem;">
              <span style="color:var(--text-muted); font-family:var(--font-mono);">${escapeHtml(ev.task.repo)}</span>
              <div style="display:flex; gap:0.3rem;">
                <button type="button" class="btn btn-sm btn-secondary" onclick="openRepoDetailModal('${ev.task.id}')" style="padding:1px 6px; font-size:0.7rem;">详情</button>
                <button type="button" class="btn btn-sm btn-secondary" onclick="checkSingleTask('${ev.task.id}')" style="padding:1px 6px; font-size:0.7rem;">检测</button>
              </div>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }).join("");

  container.innerHTML = `
    <div class="timeline-container">
      ${filterToolbarHtml}
      ${itemsHtml}
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();
}


async function checkRepoAllTasks(repoName) {
  const cleanRepo = normalizeRepo(repoName);
  const targets = tasks.filter(t => normalizeRepo(t.repo) === cleanRepo);
  if (targets.length === 0) return;
  showToast(`正在对 ${targets.length} 个分支任务发起联网检测...`, "info");
  for (const t of targets) {
    try {
      await fetch(`/api/tasks/${t.id}/check`, { method: "POST" });
    } catch (e) {}
  }
  showToast("该仓库所有分支任务检测已派发", "success");
  loadTasks();
}

function openTaskModalForRepo(repoName, softName) {
  openTaskModal();
  document.getElementById("taskRepo").value = repoName;
  document.getElementById("taskName").value = softName;
  document.getElementById("taskSubName").focus();
}

// ----------------- 任务操作 API -----------------

async function toggleTask(taskId) {
  try {
    const res = await fetch(`/api/tasks/${taskId}/toggle`, { method: "POST" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast(json.enabled ? "已开启监控" : "已暂停监控", "info");
      loadTasks();
    }
  } catch (err) {
    showToast("操作失败: " + err, "error");
  }
}

async function checkSingleTask(taskId) {
  try {
    showToast("正在派发检测任务...", "info");
    const res = await fetch(`/api/tasks/${taskId}/check`, { method: "POST" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast("检测已启动，稍后自动呈现结果", "success");
      loadTasks();
    }
  } catch (err) {
    showToast("检测触发失败: " + err, "error");
  }
}

async function forceDownloadTask(taskId) {
  if (!confirm("确定强制重新下载该任务的最新安装包吗？")) return;
  try {
    showToast("正在请求拉取并下载...", "info");
    const res = await fetch(`/api/tasks/${taskId}/download`, { method: "POST" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast("已开始下载流程", "success");
      loadTasks();
    }
  } catch (err) {
    showToast("下载失败: " + err, "error");
  }
}

async function checkAllTasks() {
  try {
    showToast("正在全量触发所有已启用任务的检测...", "info");
    const res = await fetch("/api/tasks/check_all", { method: "POST" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast(json.message, "success");
      loadTasks();
    }
  } catch (err) {
    showToast("全量检测失败: " + err, "error");
  }
}

async function deleteTask(taskId) {
  if (!confirm("确定要删除该监控任务吗？相关下载历史也将一并移除。")) return;
  try {
    const res = await fetch(`/api/tasks/${taskId}`, { method: "DELETE" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast("任务已成功删除", "success");
      loadTasks();
    }
  } catch (err) {
    showToast("删除任务异常: " + err, "error");
  }
}

// ----------------- 包含/排除规则 智能标签记忆系统 -----------------

const DEFAULT_INCLUDE_TAGS = [
  "windows, x64, exe",
  "windows, x64, zip",
  "msi",
  "arm64, dmg",
  "x64, dmg",
  "apk",
  "linux, amd64, tar.gz",
  "amd64, deb",
  "AppImage"
];

const DEFAULT_EXCLUDE_TAGS = [
  "sha256,asc,sig,txt,sbom",
  "sha256,sig,txt",
  "debug,symbols,source",
  "msi,rpm",
  "sha512,asc"
];

// 获取在设置中配置的固定预设标签库
function getSettingsCustomTags(type) {
  const key = `gitrelease_custom_${type}_tags`;
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const lines = raw.split("\n").map(s => s.trim()).filter(Boolean);
      if (lines.length > 0) return lines;
    }
  } catch (e) {}
  return type === "include" ? [...DEFAULT_INCLUDE_TAGS] : [...DEFAULT_EXCLUDE_TAGS];
}

// 获取用户日常添加/编辑任务中沉淀的智能历史记忆标签
function getHistoryMemoryTags(type) {
  const key = `gitrelease_memory_${type}_tags`;
  try {
    const raw = localStorage.getItem(key);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return arr.map(s => String(s).trim()).filter(Boolean);
    }
  } catch (e) {}
  return [];
}

function saveHistoryMemoryTags(type, tags) {
  const key = `gitrelease_memory_${type}_tags`;
  localStorage.setItem(key, JSON.stringify(tags));
}

function recordMemoryTag(type, val) {
  if (!val || !val.trim()) return;
  const clean = val.trim();
  let history = getHistoryMemoryTags(type);
  history = history.filter(t => t.toLowerCase() !== clean.toLowerCase());
  history.unshift(clean);
  if (history.length > 20) history = history.slice(0, 20);
  saveHistoryMemoryTags(type, history);
  if (type === "include") localStorage.setItem("gitrelease_last_include", clean);
  if (type === "exclude") localStorage.setItem("gitrelease_last_exclude", clean);
}

function removeMemoryTag(type, tagVal, event) {
  if (event) event.stopPropagation();
  let history = getHistoryMemoryTags(type);
  history = history.filter(t => t.toLowerCase() !== tagVal.toLowerCase());
  saveHistoryMemoryTags(type, history);
  renderMemoryTags(type);
  showToast(`已从历史记忆中移除标签: ${tagVal}`, "info");
}

function clearMemoryTags(type) {
  saveHistoryMemoryTags(type, []);
  renderMemoryTags(type);
  showToast(`已清空个性化历史记录，恢复显示设置预设规则库标签`, "info");
}

function applyMemoryTag(type, tagVal) {
  const inputId = type === "include" ? "assetInclude" : "assetExclude";
  const input = document.getElementById(inputId);
  if (!input) return;

  // 如果已经选中该标签，再次点击保持或填入
  input.value = tagVal;
  if (type === "include") {
    if (tagVal.includes(".*") || tagVal.includes("\\.") || tagVal.includes("^") || tagVal.includes("$")) {
      document.getElementById("filterMode").value = "regex";
    } else {
      document.getElementById("filterMode").value = "keywords";
    }
    toggleFilterModeHelp();
    autoUpdateSubName();
  }
  renderMemoryTags(type);
  showToast(`已选定${type === "include" ? "包含规则" : "排除规则"}: ${tagVal}`, "info");
}

function renderMemoryTags(type) {
  const containerId = type === "include" ? "includeTagChips" : "excludeTagChips";
  const inputId = type === "include" ? "assetInclude" : "assetExclude";
  const container = document.getElementById(containerId);
  const input = document.getElementById(inputId);
  if (!container || !input) return;

  const currentVal = input.value.trim().toLowerCase();
  const presetTags = getSettingsCustomTags(type);
  const historyTags = getHistoryMemoryTags(type);

  const presetLowerSet = new Set(presetTags.map(t => t.toLowerCase()));
  const extraHistoryTags = historyTags.filter(t => !presetLowerSet.has(t.toLowerCase()));

  let html = "";

  // 1. 渲染设置中自定义的固定预设库标签 (高优先级、带星标)
  presetTags.forEach(tag => {
    const isActive = currentVal === tag.toLowerCase();
    const safeTag = escapeHtml(tag);
    html += `
      <button type="button" class="memory-chip is-preset ${isActive ? 'is-active' : ''}" onclick="applyMemoryTag('${type}', '${escapeJs(tag)}')" title="设置中自定义的固定常用规则标签">
        <span class="chip-preset-badge">★</span>
        <span>${safeTag}</span>
      </button>
    `;
  });

  // 2. 渲染日常使用中智能记录的历史标签 (带时钟标、支持一键删除)
  extraHistoryTags.forEach(tag => {
    const isActive = currentVal === tag.toLowerCase();
    const safeTag = escapeHtml(tag);
    html += `
      <button type="button" class="memory-chip ${isActive ? 'is-active' : ''}" onclick="applyMemoryTag('${type}', '${escapeJs(tag)}')" title="日常使用智能记忆标签">
        <span style="font-size:0.65rem; color:#a78bfa; margin-right:0.15rem;">🕒</span>
        <span>${safeTag}</span>
        <span class="chip-remove" onclick="removeMemoryTag('${type}', '${escapeJs(tag)}', event)" title="删除此条记忆标签">×</span>
      </button>
    `;
  });

  container.innerHTML = html;
  if (window.lucide) window.lucide.createIcons();
}

function escapeJs(str) {
  return (str || "").replace(/'/g, "\\'").replace(/"/g, '\\"');
}

// ----------------- 多存储目录管理与下拉直选系统 -----------------

const DEFAULT_STORAGE_DIRS = [
  "/www/zfile/dow/{platform}/{name}",
  "/www/zfile/dow/{name}/{platform}",
  "/www/zfile/dow/{name}",
  "/www/zfile/dow"
];

function getMultiStorageDirs() {
  let customFromSettings = [];
  try {
    const raw = localStorage.getItem("gitrelease_custom_dirs");
    if (raw) {
      customFromSettings = raw.split(/[\r\n]+/).map(d => d.trim()).filter(Boolean);
    }
  } catch (e) {}

  let historyDirs = [];
  try {
    const rawHist = localStorage.getItem("gitrelease_dir_history");
    if (rawHist) {
      historyDirs = JSON.parse(rawHist);
    }
  } catch (e) {}

  return Array.from(new Set([
    ...customFromSettings,
    ...historyDirs,
    ...DEFAULT_STORAGE_DIRS
  ])).filter(Boolean);
}

function recordDirectoryHistory(dirStr) {
  if (!dirStr || !dirStr.trim()) return;
  const clean = dirStr.trim();
  let list = [];
  try {
    const raw = localStorage.getItem("gitrelease_dir_history");
    if (raw) list = JSON.parse(raw);
  } catch (e) {}
  list = list.filter(d => d.toLowerCase() !== clean.toLowerCase());
  list.unshift(clean);
  if (list.length > 20) list = list.slice(0, 20);
  localStorage.setItem("gitrelease_dir_history", JSON.stringify(list));
  localStorage.setItem("gitrelease_saved_dir", clean);
}

function renderDownloadDirOptions(selectedVal = "") {
  const select = document.getElementById("downloadDirSelect");
  if (!select) return;

  const allDirs = getMultiStorageDirs();
  const currentVal = (selectedVal !== undefined && selectedVal !== null && selectedVal !== "") 
    ? selectedVal 
    : (document.getElementById("downloadDir") ? document.getElementById("downloadDir").value : "").trim();

  let html = `<option value="">📂 从常用 / 历史记忆多目录中快速选择 (${allDirs.length} 个可用)...</option>`;
  html += allDirs.map(dir => {
    const isSel = (currentVal && currentVal.toLowerCase() === dir.toLowerCase()) ? "selected" : "";
    return `<option value="${escapeHtml(dir)}" ${isSel}>📁 ${escapeHtml(dir)}</option>`;
  }).join("");

  select.innerHTML = html;
  if (currentVal && Array.from(select.options).some(o => o.value.toLowerCase() === currentVal.toLowerCase())) {
    select.value = currentVal;
  }
}

function onDownloadDirSelectChange(val) {
  if (!val) return;
  const input = document.getElementById("downloadDir");
  if (input) {
    input.value = val;
    localStorage.setItem("gitrelease_saved_dir", val);
    showToast(`已选定存储目录: ${val}`, "info");
  }
}

// ----------------- 任务表单与模态框 -----------------

function openTaskModal(task = null) {
  const modal = document.getElementById("taskModal");
  const title = document.getElementById("modalTaskTitle");
  const testBox = document.getElementById("testFilterResult");
  testBox.style.display = "none";
  testBox.innerHTML = "";

  if (task) {
    isSubNameManuallyEdited = true;
    title.innerHTML = '<i data-lucide="edit-3"></i> 编辑监控任务';
    document.getElementById("taskId").value = task.id;
    document.getElementById("taskName").value = task.name;
    document.getElementById("taskSubName").value = task.sub_name || "";
    document.getElementById("taskRepo").value = task.repo;
    document.getElementById("filterMode").value = task.filter_mode || "keywords";
    document.getElementById("includePrerelease").value = task.include_prerelease ? "1" : "0";
    document.getElementById("assetInclude").value = task.asset_filter_include || "";
    document.getElementById("assetExclude").value = task.asset_filter_exclude || "sha256,asc,sig,txt,sbom";
    document.getElementById("checkInterval").value = task.cron_expr || (task.check_interval || 60);
    document.getElementById("autoDownload").value = task.auto_download !== undefined ? task.auto_download : 1;
    document.getElementById("downloadDir").value = task.download_dir || "";
    document.getElementById("afterDownloadCmd").value = task.after_download_cmd || "";
    const autoExtractEl = document.getElementById("taskAutoExtract");
    if (autoExtractEl) autoExtractEl.checked = (task.auto_extract !== undefined) ? Boolean(Number(task.auto_extract)) : false;
    renderDownloadDirOptions(task.download_dir || "");
  } else {
    isSubNameManuallyEdited = false;
    title.innerHTML = '<i data-lucide="package-plus"></i> 添加软件监控任务';
    document.getElementById("taskForm").reset();
    document.getElementById("taskId").value = "";
    document.getElementById("taskSubName").value = "";
    const autoExtractEl = document.getElementById("taskAutoExtract");
    if (autoExtractEl) autoExtractEl.checked = false; // 默认不勾选，由用户按需自主选择
    // 自动回填上次使用的包含规则与排除规则（智能记忆默认填充）
    const lastInclude = localStorage.getItem("gitrelease_last_include") || "";
    const lastExclude = localStorage.getItem("gitrelease_last_exclude") || "sha256,asc,sig,txt,sbom";
    document.getElementById("assetInclude").value = lastInclude;
    document.getElementById("assetExclude").value = lastExclude;
    document.getElementById("checkInterval").value = "60";
    document.getElementById("autoDownload").value = "1";
    // 自动回填上次记住的自定义路径模板，若无则默认使用全平台自动分类模板
    const rememberedDir = localStorage.getItem("gitrelease_saved_dir") || "/www/zfile/dow/{platform}/{name}";
    document.getElementById("downloadDir").value = rememberedDir;
    renderDownloadDirOptions(rememberedDir);
    autoUpdateSubName();
  }

  toggleFilterModeHelp();
  renderMemoryTags("include");
  renderMemoryTags("exclude");
  modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
}

function applyDirPreset(dirStr) {
  document.getElementById("downloadDir").value = dirStr;
  localStorage.setItem("gitrelease_saved_dir", dirStr);
  renderDownloadDirOptions(dirStr);
  showToast(`已选定并记住保存目录: ${dirStr}`, "info");
}

function closeTaskModal() {
  document.getElementById("taskModal").classList.remove("active");
}

function editTask(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (task) openTaskModal(task);
}

function copyTask(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;

  const modal = document.getElementById("taskModal");
  const title = document.getElementById("modalTaskTitle");
  const testBox = document.getElementById("testFilterResult");
  testBox.style.display = "none";
  testBox.innerHTML = "";

  title.innerHTML = '<i data-lucide="copy"></i> 复制新建任务';
  document.getElementById("taskId").value = "";
  document.getElementById("taskName").value = task.name;
  document.getElementById("taskSubName").value = `${task.sub_name || task.name} (副本)`;
  document.getElementById("taskRepo").value = task.repo;
  document.getElementById("filterMode").value = task.filter_mode || "keywords";
  document.getElementById("includePrerelease").value = task.include_prerelease ? "1" : "0";
  document.getElementById("assetInclude").value = task.asset_filter_include || "";
  document.getElementById("assetExclude").value = task.asset_filter_exclude || "sha256,asc,sig,txt,sbom";
  document.getElementById("checkInterval").value = task.cron_expr || (task.check_interval || 60);
  document.getElementById("autoDownload").value = task.auto_download !== undefined ? task.auto_download : 1;
  document.getElementById("downloadDir").value = task.download_dir || "";
  document.getElementById("afterDownloadCmd").value = task.after_download_cmd || "";

  renderDownloadDirOptions(task.download_dir || "");
  toggleFilterModeHelp();
  renderMemoryTags("include");
  renderMemoryTags("exclude");
  modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();

  showToast("已载入任务配置模板，可修改专属标识别名或过滤规则后保存", "info");
  setTimeout(() => {
    const subInput = document.getElementById("taskSubName");
    if (subInput) {
      subInput.focus();
      subInput.select();
    }
  }, 150);
}

function toggleFilterModeHelp() {
  const mode = document.getElementById("filterMode").value;
  const desc = document.getElementById("filterModeDesc");
  if (mode === "regex") {
    desc.textContent = "正则表达式模式：直接匹配 GitHub Release 文件名，例如: linux.*amd64.*\\.tar\\.gz";
  } else {
    desc.textContent = "关键词模式：包名必须同时包含上述所有关键词（逗号分隔，不区分大小写）";
  }
}

function applyPreset(ruleStr) {
  document.getElementById("assetInclude").value = ruleStr;
  document.getElementById("filterMode").value = "keywords";
  toggleFilterModeHelp();
  autoUpdateSubName();
  showToast(`已套用预设规则: ${ruleStr}`, "info");
}

async function testFilterRules() {
  const repo = document.getElementById("taskRepo").value.trim();
  if (!repo) {
    showToast("请先填写 GitHub 仓库 (例如 owner/repo)", "warning");
    return;
  }

  const resultBox = document.getElementById("testFilterResult");
  resultBox.style.display = "block";
  resultBox.innerHTML = '<div style="color:#94a3b8;"><i data-lucide="loader-2"></i> 正在连接 GitHub Release 测试匹配中...</div>';
  if (window.lucide) window.lucide.createIcons();

  const payload = {
    repo: repo,
    task_name: (document.getElementById("taskName") ? document.getElementById("taskName").value : "").trim(),
    sub_name: (document.getElementById("taskSubName") ? document.getElementById("taskSubName").value : "").trim(),
    download_dir: (document.getElementById("downloadDir") ? document.getElementById("downloadDir").value : "").trim(),
    include_prerelease: parseInt(document.getElementById("includePrerelease").value) || 0,
    filter_mode: document.getElementById("filterMode").value,
    asset_filter_include: document.getElementById("assetInclude").value.trim(),
    asset_filter_exclude: document.getElementById("assetExclude").value.trim()
  };

  try {
    const res = await fetch("/api/test_filter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const json = await res.json();

    if (json.status === "ok") {
      // 若用户尚未手动编辑标识别名，根据命中的真实资产文件名进一步智能校准别名
      if (!isSubNameManuallyEdited && json.matched_assets && json.matched_assets.length > 0) {
        const firstMatched = json.matched_assets[0].name;
        const detectedPlat = detectPlatformFromRule(firstMatched);
        if (detectedPlat && detectedPlat !== "通用版") {
          document.getElementById("taskSubName").value = detectedPlat;
        }
      }

      const pubDate = json.published_at ? json.published_at.slice(0, 10) : "未知日期";
      let html = `<div style="margin-bottom:0.5rem;color:#f1f5f9;"><strong>最新Release:</strong> ${escapeHtml(json.tag_name || "未知版本")} (${pubDate})</div>`;
      html += `<div style="margin-bottom:0.5rem;">总资产数: ${json.total_assets_count} | <strong>命中匹配: ${json.matched_count}</strong></div>`;

      if (json.matched_count === 0) {
        html += '<div style="color:#f87171;margin-bottom:0.4rem;">⚠️ 未能命中任何资产！请检查关键词或排除规则。</div>';
        if (json.all_assets && json.all_assets.length > 0) {
          html += '<div style="margin-top:0.4rem;color:#94a3b8;font-size:0.75rem;margin-bottom:0.3rem;">可从该Release中的全部文件中直接挑选并【一键套用】:</div>';
          html += json.all_assets.map(a => `
            <div style="display:flex;align-items:center;justify-content:space-between;padding:0.35rem 0.6rem;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:6px;margin-bottom:0.3rem;font-size:0.75rem;">
              <span style="color:#cbd5e1;word-break:break-all;">• ${escapeHtml(a.name)}</span>
              <button type="button" class="btn btn-sm btn-secondary" onclick="applyAssetAsRule('${escapeHtml(a.name)}')" style="padding:2px 8px;font-size:0.75rem;height:24px;flex-shrink:0;margin-left:8px;" title="将此文件特征填入规则并自动识别别名">
                <i data-lucide="check" style="width:12px;height:12px;"></i> 套用此文件
              </button>
            </div>
          `).join('');
        }
      } else {
        html += json.matched_assets.map(a => {
          let localStatusHtml = '';
          if (a.local_exists && a.local_size_matches) {
            localStatusHtml = `
              <div style="margin-top:0.35rem;padding:0.3rem 0.5rem;background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.25);border-radius:6px;color:#10b981;font-size:0.75rem;display:flex;align-items:center;gap:6px;">
                <i data-lucide="check-circle-2" style="width:14px;height:14px;flex-shrink:0;"></i>
                <span><strong>本地已存在完全一致文件</strong> (路径: <code>${escapeHtml(a.local_path)}</code>)<br>添加任务后将自动免下载同步，节省流量 0 KB 消耗！</span>
              </div>`;
          } else if (a.local_exists && !a.local_size_matches) {
            localStatusHtml = `
              <div style="margin-top:0.35rem;padding:0.3rem 0.5rem;background:rgba(245,158,11,0.12);border:1px solid rgba(245,158,11,0.25);border-radius:6px;color:#f59e0b;font-size:0.75rem;display:flex;align-items:center;gap:6px;">
                <i data-lucide="alert-triangle" style="width:14px;height:14px;flex-shrink:0;"></i>
                <span><strong>本地已存在同名文件但体积不符</strong> (本地: ${(a.local_size/1024/1024).toFixed(2)} MB vs 线上: ${(a.size/1024/1024).toFixed(2)} MB)<br>添加任务后将从网络正常下载更新</span>
              </div>`;
          } else if (a.target_dir) {
            localStatusHtml = `
              <div style="margin-top:0.25rem;color:#94a3b8;font-size:0.75rem;">
                目标存储路径: <code>${escapeHtml(a.target_dir)}</code> (本地暂无此文件，添加后将正常下载)
              </div>`;
          }

          return `
            <div class="matched-item" style="display:block;margin-bottom:0.6rem;padding:0.5rem 0.75rem;">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">
                <div style="display:flex;align-items:center;gap:8px;">
                  <i data-lucide="check" style="color:#10b981;flex-shrink:0;"></i>
                  <span style="word-break:break-all;"><strong>${escapeHtml(a.name)}</strong> (${(a.size / 1024 / 1024).toFixed(2)} MB)</span>
                </div>
                <button type="button" class="btn btn-sm btn-secondary" onclick="applyAssetAsRule('${escapeHtml(a.name)}')" style="padding:2px 8px;font-size:0.75rem;height:24px;flex-shrink:0;" title="根据此文件名优化规则并重新识别专属别名">
                  <i data-lucide="sparkles" style="width:12px;height:12px;"></i> 套用此文件
                </button>
              </div>
              ${localStatusHtml}
            </div>
          `;
        }).join('');
      }

      resultBox.innerHTML = html;
      if (window.lucide) window.lucide.createIcons();
    } else {
      resultBox.innerHTML = `<div style="color:#ef4444;">测试失败: ${escapeHtml(json.message)}</div>`;
    }
  } catch (err) {
    resultBox.innerHTML = `<div style="color:#ef4444;">网络请求出错: ${err}</div>`;
  }
}

function applyAssetAsRule(assetName) {
  if (!assetName) return;
  const incInput = document.getElementById("assetInclude");
  const subInput = document.getElementById("taskSubName");

  // 1. 智能提取平台别名
  const detectedPlat = detectPlatformFromRule(assetName);
  if (subInput) {
    subInput.value = detectedPlat;
    isSubNameManuallyEdited = true;
  }

  // 2. 智能提炼最精准的关键词规则
  const fnLower = assetName.toLowerCase();
  const keywords = [];

  if (fnLower.includes("universal")) keywords.push("universal");
  if (fnLower.includes("arm64") || fnLower.includes("aarch64")) keywords.push("arm64");
  else if (fnLower.includes("amd64")) keywords.push("amd64");
  else if (fnLower.includes("x64") || fnLower.includes("x86_64") || fnLower.includes("win64")) keywords.push("x64");
  else if (fnLower.includes("armv7") || fnLower.includes("armeabi") || fnLower.includes("armhf")) keywords.push("arm");
  else if (fnLower.includes("x86") || fnLower.includes("win32") || fnLower.includes("i386")) keywords.push("x86");

  if (fnLower.includes("portable")) keywords.push("portable");
  else if (fnLower.includes("setup")) keywords.push("setup");
  else if (fnLower.includes("appimage")) keywords.push("appimage");

  const extMatch = fnLower.match(/\.(apk|exe|msi|dmg|pkg|deb|rpm|appimage|tar\.gz|tgz|zip|7z)$/);
  if (extMatch) {
    const ext = extMatch[1];
    if (!keywords.includes(ext)) keywords.push(ext);
  }

  const finalRule = keywords.length > 0 ? keywords.join(", ") : assetName;
  if (incInput) {
    incInput.value = finalRule;
    document.getElementById("filterMode").value = "keywords";
    toggleFilterModeHelp();
  }

  showToast(`已成功套用文件「${assetName}」的规则并自动识别别名为「${detectedPlat}」`, "success");
}

async function saveTask() {
  const taskId = document.getElementById("taskId").value;
  const taskName = document.getElementById("taskName").value.trim();
  let taskSubName = document.getElementById("taskSubName").value.trim();
  const repoInput = document.getElementById("taskRepo").value.trim();

  if (!taskName) {
    showToast("请填写软件自定义名称", "warning");
    document.getElementById("taskName").focus();
    return;
  }

  if (!repoInput) {
    showToast("请填写 GitHub 仓库地址 (如 owner/repo)", "warning");
    document.getElementById("taskRepo").focus();
    return;
  }

  const cleanTargetRepo = normalizeRepo(repoInput);

  // 若未手动输入任务专属标识别名，默认设为「软件自定义名称 + {platform}」，并保证唯一值
  if (!taskSubName) {
    const plat = detectPlatformFromRule(document.getElementById("assetInclude").value.trim());
    taskSubName = `${taskName}-${plat}`;
  }

  // 唯一值保证机制：检测同仓库下是否已存在该别名
  let candidateSub = taskSubName;
  let counter = 2;
  while (tasks.some(t => t.id !== taskId && normalizeRepo(t.repo) === cleanTargetRepo && (t.sub_name || "").trim().toLowerCase() === candidateSub.toLowerCase())) {
    if (isSubNameManuallyEdited && candidateSub === taskSubName) {
      showToast(`在仓库「${repoInput}」下已存在标识别名为「${taskSubName}」的任务。标识别名必须唯一，不能重复！`, "warning");
      document.getElementById("taskSubName").focus();
      return;
    }
    candidateSub = `${taskSubName}-${counter}`;
    counter++;
  }
  taskSubName = candidateSub;
  document.getElementById("taskSubName").value = taskSubName;

  const targetFilterSig = normalizeFilterRule(document.getElementById("filterMode").value, document.getElementById("assetInclude").value);
  const duplicateFilter = tasks.find(t => {
    if (t.id === taskId) return false;
    if (normalizeRepo(t.repo) !== cleanTargetRepo) return false;
    const existingSig = normalizeFilterRule(t.filter_mode, t.asset_filter_include);
    return existingSig === targetFilterSig;
  });

  if (duplicateFilter) {
    showToast(`在仓库「${duplicateFilter.repo}」下已存在过滤规则完全一致的任务「${duplicateFilter.name}」(${duplicateFilter.sub_name || ''})。请区分包含规则！`, "warning");
    document.getElementById("assetInclude").focus();
    return;
  }

  const checkVal = document.getElementById("checkInterval").value.trim();
  let intervalNum = 60;
  let cronStr = "";
  if (checkVal.includes(" ")) {
    cronStr = checkVal;
  } else {
    intervalNum = parseInt(checkVal) || 60;
  }

  const autoDlVal = document.getElementById("autoDownload").value;
  const prereleaseVal = document.getElementById("includePrerelease").value;
  const autoExtractVal = document.getElementById("taskAutoExtract") ? (document.getElementById("taskAutoExtract").checked ? 1 : 0) : 0;

  const payload = {
    name: taskName,
    sub_name: taskSubName,
    repo: repoInput,
    filter_mode: document.getElementById("filterMode").value,
    include_prerelease: prereleaseVal === "1" ? 1 : 0,
    asset_filter_include: document.getElementById("assetInclude").value.trim(),
    asset_filter_exclude: document.getElementById("assetExclude").value.trim(),
    check_interval: intervalNum,
    cron_expr: cronStr,
    auto_download: autoDlVal === "0" ? 0 : 1,
    auto_extract: autoExtractVal,
    download_dir: document.getElementById("downloadDir").value.trim(),
    after_download_cmd: document.getElementById("afterDownloadCmd").value.trim()
  };

  try {
    let res;
    if (taskId) {
      res = await fetch(`/api/tasks/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
    } else {
      res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
    }
    const json = await res.json();
    if (res.ok && json.status === "ok") {
      // 记住用户的目录习惯与包含/排除规则标签
      const currentDir = document.getElementById("downloadDir").value.trim();
      if (currentDir) {
        localStorage.setItem("gitrelease_saved_dir", currentDir);
        recordDirectoryHistory(currentDir);
      }
      // 成功后清空搜索框，确保新任务立即呈现不被检索条件遮挡
      const searchEl = document.getElementById("taskSearch");
      if (searchEl) searchEl.value = "";

      showToast(taskId ? "任务修改成功" : "任务已创建并加入自动监控", "success");
      closeTaskModal();
      await loadTasks();
    } else {
      showToast("保存失败: " + (json.detail || json.message || "请检查输入"), "error");
    }
  } catch (err) {
    showToast("提交异常: " + err, "error");
  }
}

// ----------------- 全局设置模态框与通知配置 -----------------

function switchSettingsTab(tabId) {
  const modal = document.getElementById("settingsModal");
  if (!modal) return;
  modal.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
  modal.querySelectorAll(".tab-content").forEach(tc => tc.style.display = "none");

  const targetTab = document.getElementById(tabId);
  if (targetTab) targetTab.style.display = "block";

  // 激活对应的导航按钮
  const activeBtn = Array.from(modal.querySelectorAll(".tab-btn")).find(b => (b.getAttribute("onclick") || "").includes(tabId));
  if (activeBtn) activeBtn.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
}

async function openSettingsModal() {
  const modal = document.getElementById("settingsModal");
  switchSettingsTab('tab-general');

  try {
    const res = await fetch("/api/settings");
    const json = await res.json();
    if (json.status === "ok") {
      const data = json.data;
      document.getElementById("settingPanelTitle").value = data.panel_title || "Github定时下载器";
      document.getElementById("settingPanelSubtitle").value = data.panel_subtitle || "GitHub 升级自动监测与多设备下载";
      document.getElementById("settingCustomDirs").value = data.custom_download_dirs || "";
      const incEl = document.getElementById("settingCustomIncludeTags");
      if (incEl) incEl.value = data.custom_include_tags !== undefined ? data.custom_include_tags : DEFAULT_INCLUDE_TAGS.join("\n");
      const excEl = document.getElementById("settingCustomExcludeTags");
      if (excEl) excEl.value = data.custom_exclude_tags !== undefined ? data.custom_exclude_tags : DEFAULT_EXCLUDE_TAGS.join("\n");

      document.getElementById("settingDeviceName").value = data.device_name || "Linux-01";
      const portEl = document.getElementById("settingServerPort");
      if (portEl) portEl.value = data.server_port || "8088";
      document.getElementById("settingGithubToken").value = data.github_token || "";
      document.getElementById("settingProxyMode").value = data.proxy_mode || "mirror";
      document.getElementById("settingMirrorPrefix").value = data.mirror_prefix || "https://ghproxy.net/";
      const mirrorListEl = document.getElementById("settingMirrorFallbackList");
      if (mirrorListEl) mirrorListEl.value = data.mirror_fallback_list || "https://ghproxy.net/\nhttps://mirror.ghproxy.com/\nhttps://gh.ddlc.top/";
      const minDiskEl = document.getElementById("settingMinDiskFreeGb") || document.getElementById("settingMinDiskGb");
      if (minDiskEl) minDiskEl.value = data.min_disk_free_gb || "2";

      document.getElementById("settingHttpProxy").value = data.http_proxy || "";
      document.getElementById("settingDefaultDir").value = data.default_download_dir || "";
      document.getElementById("settingKeepVersions").value = data.keep_latest_versions || "3";

      const wbEn = document.getElementById("settingWebhookEnabled");
      if (wbEn) wbEn.value = data.webhook_enabled || "1";
      const wbTk = document.getElementById("settingWebhookToken");
      if (wbTk) wbTk.value = data.webhook_token || "";

      // 填充通知字段
      document.getElementById("settingNotifyEnabled").checked = (data.notify_enabled === "1");
      const events = (data.notify_events || "upgrade_found,download_success,download_failed").split(",");
      document.getElementById("evUpgrade").checked = events.includes("upgrade_found");
      document.getElementById("evSuccess").checked = events.includes("download_success");
      document.getElementById("evFailed").checked = events.includes("download_failed");
      const evDisk = document.getElementById("evDisk");
      if (evDisk) evDisk.checked = events.includes("disk_warning");

      document.getElementById("settingSmtpHost").value = data.smtp_host || "";
      document.getElementById("settingSmtpPort").value = data.smtp_port || "465";
      document.getElementById("settingSmtpSsl").value = data.smtp_ssl || "1";
      document.getElementById("settingSmtpUser").value = data.smtp_user || "";
      document.getElementById("settingSmtpPass").value = data.smtp_pass || "";
      document.getElementById("settingSmtpTo").value = data.smtp_to || "";

      document.getElementById("settingFeishuWebhook").value = data.feishu_webhook || "";
      document.getElementById("settingFeishuSecret").value = data.feishu_secret || "";

      document.getElementById("settingDingtalkWebhook").value = data.dingtalk_webhook || "";
      document.getElementById("settingDingtalkSecret").value = data.dingtalk_secret || "";

      document.getElementById("settingWechatWebhook").value = data.wechat_webhook || "";

      const tgEn = document.getElementById("settingTelegramEnabled");
      if (tgEn) tgEn.checked = (data.telegram_enabled === "1");
      const tgTok = document.getElementById("settingTelegramBotToken");
      if (tgTok) tgTok.value = data.telegram_bot_token || "";
      const tgChat = document.getElementById("settingTelegramChatId");
      if (tgChat) tgChat.value = data.telegram_chat_id || "";
      const tgApi = document.getElementById("settingTelegramApiUrl");
      if (tgApi) tgApi.value = data.telegram_api_url || "";

      const barkEn = document.getElementById("settingBarkEnabled");
      if (barkEn) barkEn.checked = (data.bark_enabled === "1");
      const barkKey = document.getElementById("settingBarkKey");
      if (barkKey) barkKey.value = data.bark_key || "";
      const barkUrl = document.getElementById("settingBarkServerUrl");
      if (barkUrl) barkUrl.value = data.bark_server_url || "";

      const apiKeyEn = document.getElementById("settingApiKeyEnabled");
      if (apiKeyEn) apiKeyEn.value = data.api_key_enabled || "0";
      const apiKeyInput = document.getElementById("settingApiKey");
      if (apiKeyInput) apiKeyInput.value = data.api_key || "";

      const csStrict = document.getElementById("settingChecksumStrict");
      if (csStrict) csStrict.value = data.checksum_strict || "0";

      const discordEn = document.getElementById("settingDiscordEnabled");
      if (discordEn) discordEn.checked = (data.discord_enabled === "1");
      const discordWb = document.getElementById("settingDiscordWebhook");
      if (discordWb) discordWb.value = data.discord_webhook || "";

      const pushplusEn = document.getElementById("settingPushplusEnabled");
      if (pushplusEn) pushplusEn.checked = (data.pushplus_enabled === "1");
      const pushplusTok = document.getElementById("settingPushplusToken");
      if (pushplusTok) pushplusTok.value = data.pushplus_token || "";

      toggleProxyFields();
    }
    modal.classList.add("active");
    if (window.lucide) window.lucide.createIcons();
  } catch (err) {
    showToast("获取设置失败: " + err, "error");
  }
}

function closeSettingsModal() {
  document.getElementById("settingsModal").classList.remove("active");
}

function toggleProxyFields() {
  const mode = document.getElementById("settingProxyMode").value;
  const mirrorGroup = document.getElementById("groupMirrorPrefix");
  if (mirrorGroup) {
    mirrorGroup.style.display = (mode === "mirror") ? "flex" : "none";
  }
  const httpGroup = document.getElementById("groupHttpProxy");
  if (httpGroup) {
    httpGroup.style.display = (mode === "http_proxy") ? "flex" : "none";
  }
}

function getSettingsFormData() {
  const events = [];
  if (document.getElementById("evUpgrade").checked) events.push("upgrade_found");
  if (document.getElementById("evSuccess").checked) events.push("download_success");
  if (document.getElementById("evFailed").checked) events.push("download_failed");
  if (document.getElementById("evDisk") && document.getElementById("evDisk").checked) events.push("disk_warning");

  return {
    panel_title: document.getElementById("settingPanelTitle").value.trim() || "GitRelease Watcher",
    panel_subtitle: document.getElementById("settingPanelSubtitle").value.trim(),
    custom_download_dirs: document.getElementById("settingCustomDirs").value.trim(),
    custom_include_tags: (document.getElementById("settingCustomIncludeTags") ? document.getElementById("settingCustomIncludeTags").value.trim() : ""),
    custom_exclude_tags: (document.getElementById("settingCustomExcludeTags") ? document.getElementById("settingCustomExcludeTags").value.trim() : ""),

    device_name: document.getElementById("settingDeviceName").value.trim(),
    server_port: (document.getElementById("settingServerPort") ? document.getElementById("settingServerPort").value.trim() : "8088") || "8088",
    keep_latest_versions: document.getElementById("settingKeepVersions").value.trim() || "3",
    min_disk_free_gb: ((document.getElementById("settingMinDiskFreeGb") || document.getElementById("settingMinDiskGb")) ? (document.getElementById("settingMinDiskFreeGb") || document.getElementById("settingMinDiskGb")).value.trim() : "2") || "2",
    github_token: document.getElementById("settingGithubToken").value.trim(),
    proxy_mode: document.getElementById("settingProxyMode").value,
    mirror_prefix: document.getElementById("settingMirrorPrefix").value.trim(),
    mirror_fallback_list: (document.getElementById("settingMirrorFallbackList") ? document.getElementById("settingMirrorFallbackList").value.trim() : ""),
    http_proxy: document.getElementById("settingHttpProxy").value.trim(),
    default_download_dir: document.getElementById("settingDefaultDir").value.trim(),
    webhook_enabled: (document.getElementById("settingWebhookEnabled") ? document.getElementById("settingWebhookEnabled").value : "1"),
    webhook_token: (document.getElementById("settingWebhookToken") ? document.getElementById("settingWebhookToken").value.trim() : ""),

    // API Key 与 SHA256 校验
    api_key_enabled: document.getElementById("settingApiKeyEnabled") ? document.getElementById("settingApiKeyEnabled").value : "0",
    api_key: document.getElementById("settingApiKey") ? document.getElementById("settingApiKey").value.trim() : "",
    checksum_strict: document.getElementById("settingChecksumStrict") ? document.getElementById("settingChecksumStrict").value : "0",

    // 通知设置
    notify_enabled: document.getElementById("settingNotifyEnabled").checked ? "1" : "0",
    notify_events: events.join(","),
    smtp_host: document.getElementById("settingSmtpHost").value.trim(),
    smtp_port: document.getElementById("settingSmtpPort").value.trim(),
    smtp_ssl: document.getElementById("settingSmtpSsl").value,
    smtp_user: document.getElementById("settingSmtpUser").value.trim(),
    smtp_pass: document.getElementById("settingSmtpPass").value.trim(),
    smtp_to: document.getElementById("settingSmtpTo").value.trim(),

    feishu_webhook: document.getElementById("settingFeishuWebhook").value.trim(),
    feishu_secret: document.getElementById("settingFeishuSecret").value.trim(),

    dingtalk_webhook: document.getElementById("settingDingtalkWebhook").value.trim(),
    dingtalk_secret: document.getElementById("settingDingtalkSecret").value.trim(),

    wechat_webhook: document.getElementById("settingWechatWebhook").value.trim(),

    telegram_enabled: (document.getElementById("settingTelegramEnabled") && document.getElementById("settingTelegramEnabled").checked) ? "1" : "0",
    telegram_bot_token: document.getElementById("settingTelegramBotToken") ? document.getElementById("settingTelegramBotToken").value.trim() : "",
    telegram_chat_id: document.getElementById("settingTelegramChatId") ? document.getElementById("settingTelegramChatId").value.trim() : "",
    telegram_api_url: document.getElementById("settingTelegramApiUrl") ? document.getElementById("settingTelegramApiUrl").value.trim() : "",

    bark_enabled: (document.getElementById("settingBarkEnabled") && document.getElementById("settingBarkEnabled").checked) ? "1" : "0",
    bark_key: document.getElementById("settingBarkKey") ? document.getElementById("settingBarkKey").value.trim() : "",
    bark_server_url: document.getElementById("settingBarkServerUrl") ? document.getElementById("settingBarkServerUrl").value.trim() : "",

    discord_enabled: (document.getElementById("settingDiscordEnabled") && document.getElementById("settingDiscordEnabled").checked) ? "1" : "0",
    discord_webhook: document.getElementById("settingDiscordWebhook") ? document.getElementById("settingDiscordWebhook").value.trim() : "",

    pushplus_enabled: (document.getElementById("settingPushplusEnabled") && document.getElementById("settingPushplusEnabled").checked) ? "1" : "0",
    pushplus_token: document.getElementById("settingPushplusToken") ? document.getElementById("settingPushplusToken").value.trim() : ""
  };
}

async function saveSettings() {
  const payload = getSettingsFormData();
  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const json = await res.json();
    if (json.status === "ok") {
      if (payload.custom_download_dirs !== undefined) {
        localStorage.setItem("gitrelease_custom_dirs", payload.custom_download_dirs);
      }
      if (payload.custom_include_tags !== undefined) {
        localStorage.setItem("gitrelease_custom_include_tags", payload.custom_include_tags);
      }
      if (payload.custom_exclude_tags !== undefined) {
        localStorage.setItem("gitrelease_custom_exclude_tags", payload.custom_exclude_tags);
      }
      if (payload.api_key_enabled === "1" && payload.api_key) {
        localStorage.setItem("gitrelease_api_key", payload.api_key);
      } else if (payload.api_key_enabled === "0") {
        localStorage.removeItem("gitrelease_api_key");
      }
      renderDownloadDirOptions();
      renderMemoryTags("include");
      renderMemoryTags("exclude");
      if (payload.server_port) {
        showToast(`系统与规则配置已保存！(端口: ${payload.server_port}，重启服务后生效)`, "success");
      } else {
        showToast("全局与规则标签配置已成功保存", "success");
      }
      closeSettingsModal();
      await loadSystemInfo();
    }
  } catch (err) {
    showToast("保存设置异常: " + err, "error");
  }
}

// ----------------- 即时通知测试 -----------------

async function testNotifyChannel(channel) {
  showToast(`正在发送 [${channel}] 测试通知...`, "info");
  const formData = getSettingsFormData();

  try {
    const res = await fetch("/api/notify/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        channel: channel,
        config: formData
      })
    });
    const json = await res.json();
    if (json.status === "ok") {
      showToast(json.message, "success");
    } else {
      showToast(json.message, "error");
      alert("测试通知发送失败:\n" + json.message);
    }
  } catch (err) {
    showToast("请求错误: " + err, "error");
  }
}

// ----------------- 数据库备份与还原 -----------------

async function backupDatabase() {
  showToast("正在导出数据库完整快照...", "info");
  try {
    const res = await fetch("/api/database/backup");
    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson.message || errJson.detail || `HTTP ${res.status}`);
    }
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `gitrelease_backup_${new Date().toISOString().slice(0, 10)}.db`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);
    showToast("数据库快照已成功导出并开始下载", "success");
  } catch (err) {
    showToast("备份数据库失败: " + err.message, "error");
  }
}

async function restoreDatabase(event) {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.name.endsWith(".db")) {
    showToast("请上传有效的 .db 格式数据库文件", "error");
    event.target.value = "";
    return;
  }

  if (!confirm(`确定要从快照文件 [${file.name}] 恢复数据库吗？\n警告：当前系统所有任务、配置及历史记录将被快照完全覆盖！`)) {
    event.target.value = "";
    return;
  }

  showToast("正在上传并还原数据库快照...", "info");
  const formData = new FormData();
  formData.append("file", file);

  try {
    const res = await fetch("/api/database/restore", {
      method: "POST",
      body: formData
    });
    const json = await res.json();
    if (res.ok && json.status === "ok") {
      showToast("数据库已成功还原，正在刷新系统...", "success");
      closeSettingsModal();
      await loadTasks();
      await loadSystemInfo();
    } else {
      showToast("还原失败: " + (json.message || json.detail || "未知错误"), "error");
    }
  } catch (err) {
    showToast("请求失败: " + err.message, "error");
  } finally {
    event.target.value = "";
  }
}

// ----------------- 下载历史 -----------------

async function openHistoryModal() {
  const modal = document.getElementById("historyModal");
  const tbody = document.getElementById("historyTableBody");
  tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#94a3b8;padding:2rem;">正在读取下载历史...</td></tr>';
  modal.classList.add("active");

  try {
    const res = await fetch("/api/history");
    const json = await res.json();
    if (json.status === "ok") {
      const records = json.data;
      if (records.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#64748b;padding:2.5rem;">暂无安装包下载历史记录</td></tr>';
        return;
      }
      tbody.innerHTML = records.map(r => {
        const fileExists = Boolean(r.file_exists);
        const sizeMb = (r.file_size / 1024 / 1024).toFixed(2);
        return `
        <tr>
          <td>
            <strong>${escapeHtml(r.task_name)}</strong>
          </td>
          <td><span class="tag-badge">${escapeHtml(r.tag_name)}</span></td>
          <td>
            <div style="font-family:'Fira Code', monospace; font-size:0.8rem; color:#93c5fd; word-break:break-all;">
              ${escapeHtml(r.file_name)}
            </div>
          </td>
          <td>
            <div style="font-size:0.8rem;">${sizeMb} MB</div>
            <div style="font-size:0.7rem; color:#94a3b8;">${r.duration} 秒</div>
          </td>
          <td>
            <div style="font-family:'Fira Code', monospace;font-size:0.75rem; max-width: 220px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="${escapeHtml(r.save_path)}">
              ${escapeHtml(r.save_path)}
            </div>
            <div style="font-size:0.7rem; margin-top:2px;">
              ${fileExists ? '<span style="color:#10b981;">● 磁盘文件在位</span>' : '<span style="color:#94a3b8;">○ 已被旧版清理</span>'}
            </div>
          </td>
          <td style="font-size:0.75rem; color:#94a3b8;">${escapeHtml(r.download_time)}</td>
          <td>
            <span class="tag-badge ${r.status === 'success' ? 'include' : 'exclude'}">
              ${r.status === 'success' ? '下载完成' : '下载失败'}
            </span>
            ${r.checksum_status === 'verified' ? '<div style="margin-top:3px;"><span class="tag-badge include" style="font-size:0.65rem;" title="已通过 SHA256 完整性哈希校验">SHA256✓</span></div>' : ''}
            ${r.checksum_status === 'mismatch' ? '<div style="margin-top:3px;"><span class="tag-badge exclude" style="font-size:0.65rem;" title="SHA256 哈希比对不匹配">SHA256异常</span></div>' : ''}
          </td>
          <td style="text-align:center;">
            <div style="display:inline-flex; gap:0.35rem; align-items:center;">
              <button type="button" class="btn btn-sm btn-secondary" onclick="downloadHistoryFile(${r.id}, '${escapeJs(r.file_name)}')" ${fileExists ? '' : 'disabled style="opacity:0.45; cursor:not-allowed;"'} title="${fileExists ? '直接拉取下载到当前电脑或手机' : '物理文件已被轮换清理或移除'}">
                <i data-lucide="download"></i> 本地取回
              </button>
              <button type="button" class="btn btn-sm btn-danger" onclick="deleteHistoryItem(${r.id}, ${fileExists})" title="删除此记录或同时移除物理文件">
                <i data-lucide="trash"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
      }).join("");

      if (window.lucide) window.lucide.createIcons();
    }
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" style="color:#ef4444;text-align:center;padding:2rem;">加载历史失败: ${err}</td></tr>`;
  }
}

function closeHistoryModal() {
  document.getElementById("historyModal").classList.remove("active");
}

function downloadHistoryFile(historyId, fileName) {
  showToast(`正在从服务器拉取本地文件: ${fileName}`, "info");
  const a = document.createElement("a");
  a.href = `/api/history/${historyId}/download`;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

async function deleteHistoryItem(historyId, hasPhysicalFile) {
  let deleteFile = false;
  if (hasPhysicalFile) {
    const choice = confirm("发现本地磁盘上仍存有该安装包物理文件：\n\n【确定】：彻底删除磁盘上的实际文件与历史记录（推荐，释放存储空间）\n【取消】：仅从列表中删除历史记录，保留磁盘文件");
    deleteFile = choice;
  } else {
    if (!confirm("确定删除该条下载历史记录吗？")) return;
  }

  try {
    const res = await fetch(`/api/history/${historyId}?delete_file=${deleteFile ? 'true' : 'false'}`, {
      method: "DELETE"
    });
    const json = await res.json();
    if (json.status === "ok") {
      showToast(deleteFile ? "已彻底清理磁盘物理安装包及历史记录" : "历史记录已删除", "success");
      await openHistoryModal();
      await loadSystemInfo();
    } else {
      showToast(json.detail || "删除失败", "error");
    }
  } catch (err) {
    showToast("删除异常: " + err, "error");
  }
}

// ----------------- 版本更新日志查看 -----------------

function viewReleaseNotes(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;

  const modal = document.getElementById("notesModal");
  const title = document.getElementById("notesModalTitle");
  const content = document.getElementById("notesModalContent");

  title.innerHTML = `<i data-lucide="file-text"></i> ${escapeHtml(task.name)} ${escapeHtml(task.remote_version || task.local_version || '')} 更新日志`;
  
  if (task.release_notes && task.release_notes.trim()) {
    content.textContent = task.release_notes.trim();
  } else {
    content.innerHTML = '<span style="color:#64748b;">该版本发布时未附带更新说明，或尚未从 GitHub 线上拉取。</span>';
  }

  modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
}

function closeNotesModal() {
  const modal = document.getElementById("notesModal");
  if (modal) modal.classList.remove("active");
}

async function clearAllHistory() {
  const deleteFiles = confirm("清空历史记录时：\n\n是否同时彻底删除本地磁盘上所有历史安装包文件？\n\n【确定】：同时删除磁盘物理文件（极大释放空间）\n【取消】：仅清空界面记录，保留磁盘文件");
  try {
    const res = await fetch(`/api/history?delete_files=${deleteFiles ? 'true' : 'false'}`, { method: "DELETE" });
    const json = await res.json();
    if (json.status === "ok") {
      showToast(deleteFiles ? "历史记录与对应物理文件已全部清理" : "历史记录已清空", "success");
      await openHistoryModal();
      await loadSystemInfo();
      updateMetrics();
    }
  } catch (err) {
    showToast("清空历史失败: " + err, "error");
  }
}

// ----------------- 监控任务清单批量导入与导出系统 -----------------

let currentExportData = null;

async function openImportExportModal() {
  const modal = document.getElementById("importExportModal");
  if (!modal) return;
  switchImportExportTab("export");
  await loadExportData();
  setupFileDropZone();
  modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
}

function closeImportExportModal() {
  const modal = document.getElementById("importExportModal");
  if (modal) modal.classList.remove("active");
}

function switchImportExportTab(tabName) {
  const subExport = document.getElementById("subtab-export");
  const subImport = document.getElementById("subtab-import");
  const btnExport = document.getElementById("tabBtnExport");
  const btnImport = document.getElementById("tabBtnImport");
  const btnExec = document.getElementById("btnExecuteImport");

  if (tabName === "export") {
    if (subExport) subExport.style.display = "block";
    if (subImport) subImport.style.display = "none";
    if (btnExport) btnExport.classList.add("active");
    if (btnImport) btnImport.classList.remove("active");
    if (btnExec) btnExec.style.display = "none";
  } else {
    if (subExport) subExport.style.display = "none";
    if (subImport) subImport.style.display = "block";
    if (btnExport) btnExport.classList.remove("active");
    if (btnImport) btnImport.classList.add("active");
    if (btnExec) btnExec.style.display = "inline-flex";
  }
  if (window.lucide) window.lucide.createIcons();
}

async function loadExportData() {
  const previewEl = document.getElementById("exportJsonPreview");
  const countEl = document.getElementById("exportTaskCount");
  try {
    const res = await fetch("/api/tasks/export");
    const json = await res.json();
    if (json.status === "ok") {
      currentExportData = json.data;
      const formatted = JSON.stringify(currentExportData, null, 2);
      if (previewEl) previewEl.value = formatted;
      if (countEl) countEl.textContent = currentExportData.count || 0;
    }
  } catch (err) {
    if (previewEl) previewEl.value = "获取导出数据失败: " + err;
  }
}

function downloadExportFile() {
  if (!currentExportData) {
    showToast("暂无可导出的任务数据", "warning");
    return;
  }
  const blob = new Blob([JSON.stringify(currentExportData, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  a.href = url;
  a.download = `gitrelease_tasks_export_${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast("任务配置文件已成功下载", "success");
}

function copyExportJson() {
  const previewEl = document.getElementById("exportJsonPreview");
  if (!previewEl || !previewEl.value) {
    showToast("暂无可复制的数据", "warning");
    return;
  }
  navigator.clipboard.writeText(previewEl.value)
    .then(() => showToast("已将全部任务 JSON 复制到剪贴板", "success"))
    .catch(() => {
      previewEl.select();
      document.execCommand("copy");
      showToast("已选中并复制任务 JSON", "success");
    });
}

function handleImportFileSelect(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const dropLabel = document.getElementById("dropFileName");
  if (dropLabel) dropLabel.textContent = `已选定文件: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
  
  const reader = new FileReader();
  reader.onload = function(e) {
    const text = e.target.result;
    document.getElementById("importJsonText").value = text;
    showToast(`文件「${file.name}」载入成功，请确认策略后点击下方「立即执行导入」`, "info");
  };
  reader.readAsText(file);
}

function setupFileDropZone() {
  const dropZone = document.getElementById("fileDropZone");
  if (!dropZone || dropZone.dataset.bound === "1") return;
  dropZone.dataset.bound = "1";

  ["dragenter", "dragover"].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.add("drag-over");
    });
  });

  ["dragleave", "drop"].forEach(eventName => {
    dropZone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropZone.classList.remove("drag-over");
    });
  });

  dropZone.addEventListener("drop", (e) => {
    const dt = e.dataTransfer;
    const file = dt && dt.files && dt.files[0];
    if (file) {
      const dropLabel = document.getElementById("dropFileName");
      if (dropLabel) dropLabel.textContent = `已选定文件: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
      const reader = new FileReader();
      reader.onload = function(ev) {
        document.getElementById("importJsonText").value = ev.target.result;
        showToast(`文件「${file.name}」已载入，可点击「立即执行导入」`, "info");
      };
      reader.readAsText(file);
    }
  });
}

async function executeImport() {
  const textVal = document.getElementById("importJsonText").value.trim();
  const resultBox = document.getElementById("importResultBox");
  if (!textVal) {
    showToast("请先选择 .json 文件或粘贴配置内容", "warning");
    return;
  }

  let parsedData = null;
  try {
    parsedData = JSON.parse(textVal);
  } catch (e) {
    showToast("JSON 语法解析失败，请检查输入格式", "error");
    return;
  }

  // 兼容直接是数组或包裹在对象中的标准结构
  let taskList = [];
  if (Array.isArray(parsedData)) {
    taskList = parsedData;
  } else if (parsedData && Array.isArray(parsedData.tasks)) {
    taskList = parsedData.tasks;
  } else {
    showToast("无法识别的任务结构，请确保内容为任务数组或导出对象", "error");
    return;
  }

  if (taskList.length === 0) {
    showToast("没有解析到任何可导入的任务", "warning");
    return;
  }

  const conflictMode = document.getElementById("importConflictMode").value;
  resultBox.style.display = "block";
  resultBox.style.background = "rgba(59, 130, 246, 0.1)";
  resultBox.style.border = "1px solid rgba(59, 130, 246, 0.25)";
  resultBox.style.color = "#93c5fd";
  resultBox.innerHTML = `正在导入 ${taskList.length} 个任务并校验唯一性别名...`;

  try {
    const res = await fetch("/api/tasks/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tasks: taskList,
        conflict_mode: conflictMode
      })
    });
    const json = await res.json();
    if (json.status === "ok") {
      resultBox.style.background = "rgba(16, 185, 129, 0.12)";
      resultBox.style.border = "1px solid rgba(16, 185, 129, 0.3)";
      resultBox.style.color = "#10b981";
      resultBox.innerHTML = `
        <strong>🎉 导入执行成功！</strong><br>
        共处理: ${taskList.length} 项 | 新增: <strong>${json.added}</strong> | 覆盖更新: <strong>${json.updated}</strong> | 跳过: <strong>${json.skipped}</strong>
        ${json.errors && json.errors.length ? `<div style="color:#f87171;margin-top:4px;font-size:0.75rem;">${json.errors.join('<br>')}</div>` : ''}
      `;
      showToast(json.message || "任务导入完成", "success");
      await loadTasks();
      updateMetrics();
    } else {
      resultBox.style.background = "rgba(239, 68, 68, 0.12)";
      resultBox.style.border = "1px solid rgba(239, 68, 68, 0.3)";
      resultBox.style.color = "#ef4444";
      resultBox.innerHTML = `导入失败: ${escapeHtml(json.detail || json.message || "未知错误")}`;
      showToast("导入失败: " + (json.detail || json.message), "error");
    }
  } catch (err) {
    resultBox.style.background = "rgba(239, 68, 68, 0.12)";
    resultBox.style.border = "1px solid rgba(239, 68, 68, 0.3)";
    resultBox.style.color = "#ef4444";
    resultBox.innerHTML = `网络异常: ${err}`;
    showToast("导入请求失败: " + err, "error");
  }
}

// ----------------- 实用工具函数 -----------------

function showToast(msg, type = "info") {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${escapeHtml(msg)}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 4000);
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ----------------- 下载统计面板逻辑 (StatsModal) -----------------

async function openStatsModal() {
  const modal = document.getElementById("statsModal");
  if (!modal) return;
  modal.classList.add("active");
  await loadDownloadStats(false);
  if (window.lucide) window.lucide.createIcons();
}

function closeStatsModal() {
  const modal = document.getElementById("statsModal");
  if (modal) modal.classList.remove("active");
}

async function loadDownloadStats(showNotice = false) {
  try {
    const res = await fetch("/api/stats");
    const json = await res.json();
    if (json.status === "ok") {
      const data = json.data;
      const weekEl = document.getElementById("statWeekDownloads");
      const monthEl = document.getElementById("statMonthDownloads");
      const totalEl = document.getElementById("statTotalDownloads");
      const trafficEl = document.getElementById("statTotalTraffic");
      const rateEl = document.getElementById("statSuccessRate");
      const detailEl = document.getElementById("statSuccessDetail");

      if (weekEl) weekEl.textContent = (data.week_downloads || 0).toLocaleString();
      if (monthEl) monthEl.textContent = (data.month_downloads || 0).toLocaleString();
      if (totalEl) totalEl.textContent = (data.total_downloads || 0).toLocaleString();

      const totalMb = ((data.total_bytes || 0) / 1024 / 1024);
      const trafficText = totalMb >= 1024 ? `${(totalMb / 1024).toFixed(2)} GB` : `${totalMb.toFixed(1)} MB`;
      if (trafficEl) trafficEl.textContent = `累计流量: ${trafficText}`;

      if (rateEl) rateEl.textContent = `${data.success_rate || 100}%`;
      if (detailEl) detailEl.textContent = `成功: ${data.success_downloads || 0} / 失败: ${data.failed_downloads || 0}`;

      const listEl = document.getElementById("statsRankingList");
      if (listEl) {
        const topList = data.top_downloaded || [];
        if (topList.length === 0) {
          listEl.innerHTML = '<div style="text-align:center; padding:2rem; color:var(--text-muted);">暂无下载历史统计数据</div>';
        } else {
          const maxCount = Math.max(...topList.map(t => t.count), 1);
          listEl.innerHTML = topList.map((item, idx) => {
            const rank = idx + 1;
            const pct = Math.round((item.count / maxCount) * 100);
            const sizeMb = ((item.total_size || 0) / 1024 / 1024).toFixed(1);
            const badgeClass = rank === 1 ? 'rank-1' : (rank === 2 ? 'rank-2' : (rank === 3 ? 'rank-3' : ''));
            return `
              <div class="ranking-item">
                <div class="rank-badge ${badgeClass}">${rank}</div>
                <div class="ranking-info">
                  <div class="ranking-name-row">
                    <span>${escapeHtml(item.name)}</span>
                    <span style="font-family:var(--font-mono); font-size:0.8rem; color:var(--accent-primary);">
                      <strong>${item.count}</strong> 次下载 (${sizeMb} MB)
                    </span>
                  </div>
                  <div class="ranking-bar-bg">
                    <div class="ranking-bar-fill" style="width: ${pct}%"></div>
                  </div>
                </div>
              </div>
            `;
          }).join("");
        }
      }

      if (showNotice) showToast("下载统计数据已刷新", "info");
      if (window.lucide) window.lucide.createIcons();
    }
  } catch (err) {
    console.error("加载下载统计异常:", err);
  }
}

// ----------------- 仓库多资产详情抽屉/模态框逻辑 (RepoDetailModal) -----------------

let currentDetailTaskId = null;

async function openRepoDetailModal(taskId) {
  const task = tasks.find(t => t.id === taskId);
  if (!task) return;

  currentDetailTaskId = taskId;
  const modal = document.getElementById("repoDetailModal");
  const title = document.getElementById("repoDetailTitle");
  const metaBox = document.getElementById("repoDetailMetaBox");
  const assetsBody = document.getElementById("repoDetailAssetsBody");
  const notesBox = document.getElementById("repoDetailNotes");
  const forceBtn = document.getElementById("btnRepoDetailForceDownload");

  title.innerHTML = `<i data-lucide="package"></i> ${escapeHtml(task.name)} 仓库多资产与版本详情`;
  
  const hasUpdate = Boolean(task.remote_version && task.local_version && task.remote_version !== task.local_version);
  metaBox.innerHTML = `
    <div>
      <div style="font-size:0.75rem; color:var(--text-muted);">软件名称 / 专属标识</div>
      <div style="font-weight:600; font-size:1rem; color:var(--text-primary); margin-top:2px;">
        ${escapeHtml(task.name)}
        ${task.sub_name ? `<span class="subname-badge" style="margin-left:4px;">${escapeHtml(task.sub_name)}</span>` : ''}
      </div>
    </div>
    <div>
      <div style="font-size:0.75rem; color:var(--text-muted);">GitHub 官方仓库</div>
      <div style="margin-top:2px;">
        <a href="https://github.com/${escapeHtml(task.repo)}" target="_blank" style="color:var(--accent-primary); font-weight:500;">
          <i data-lucide="github" style="width:14px;height:14px;vertical-align:middle;"></i> ${escapeHtml(task.repo)}
        </a>
      </div>
    </div>
    <div>
      <div style="font-size:0.75rem; color:var(--text-muted);">当前版本状态</div>
      <div style="font-family:var(--font-mono); font-size:0.85rem; margin-top:2px;">
        ${escapeHtml(task.local_version || "无")} ➔ 
        <span class="${hasUpdate ? 'has-update' : ''}" style="font-weight:600;">${escapeHtml(task.remote_version || "等待检测")}</span>
      </div>
    </div>
    <div>
      <div style="font-size:0.75rem; color:var(--text-muted);">最后检测 / 同步</div>
      <div style="font-size:0.8rem; color:var(--text-secondary); margin-top:2px;">
        ${escapeHtml(task.last_checked_at || task.last_downloaded_at || "未执行")}
      </div>
    </div>
  `;

  notesBox.textContent = task.release_notes || "暂无版本更新说明";
  if (forceBtn) {
    forceBtn.onclick = forceDownloadFromDetail;
  }

  assetsBody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:1.5rem;">正在向 GitHub 在线拉取该 Release 的全部资产清单...</td></tr>';
  modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();

  try {
    const res = await fetch("/api/test_filter", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        repo: task.repo,
        include_prerelease: task.include_prerelease,
        filter_mode: task.filter_mode,
        asset_filter_include: task.asset_filter_include,
        asset_filter_exclude: task.asset_filter_exclude,
        download_dir: task.download_dir,
        task_name: task.name,
        sub_name: task.sub_name
      })
    });
    const json = await res.json();
    if (json.status === "ok" && json.all_assets) {
      const matchedNames = new Set((json.matched_assets || []).map(a => a.name));
      const matchedMap = {};
      (json.matched_assets || []).forEach(a => { matchedMap[a.name] = a; });

      assetsBody.innerHTML = json.all_assets.map(a => {
        const isMatched = matchedNames.has(a.name);
        const matchInfo = matchedMap[a.name];
        const sizeMb = (a.size / 1024 / 1024).toFixed(2);
        const plat = detectPlatformFromRule(a.name);
        const fileExists = matchInfo && matchInfo.local_exists;

        return `
          <tr style="${isMatched ? 'background:rgba(59,130,246,0.06);' : ''}">
            <td>
              <div style="font-family:var(--font-mono); font-size:0.8rem; font-weight:500; color:${isMatched ? 'var(--accent-primary)' : 'var(--text-primary)'}; word-break:break-all;">
                ${escapeHtml(a.name)}
              </div>
            </td>
            <td><span class="tag-badge">${escapeHtml(plat)}</span></td>
            <td style="font-family:var(--font-mono); font-size:0.8rem;">${sizeMb} MB</td>
            <td>
              ${isMatched ? '<span class="tag-badge include">已命中规则</span>' : '<span class="tag-badge" style="opacity:0.6;">未匹配</span>'}
            </td>
            <td>
              ${fileExists ? '<span style="color:#10b981;font-size:0.75rem;">● 磁盘已存在 (免流)</span>' : '<span style="color:var(--text-muted);font-size:0.75rem;">○ 未在本地</span>'}
            </td>
          </tr>
        `;
      }).join("");
    } else {
      assetsBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#ef4444; padding:1.5rem;">获取资产清单失败: ${escapeHtml(json.message || "未知错误")}</td></tr>`;
    }
  } catch (err) {
    assetsBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#ef4444; padding:1.5rem;">网络连接异常: ${err}</td></tr>`;
  }
  if (window.lucide) window.lucide.createIcons();
}

function closeRepoDetailModal() {
  const modal = document.getElementById("repoDetailModal");
  if (modal) modal.classList.remove("active");
  currentDetailTaskId = null;
}

function forceDownloadFromDetail() {
  if (currentDetailTaskId) {
    forceDownloadTask(currentDetailTaskId);
    closeRepoDetailModal();
  }
}

// ----------------- 任务批量操作管理与工具栏 -----------------

function toggleTaskSelection(taskId, isChecked) {
  if (isChecked) {
    selectedTaskIds.add(taskId);
  } else {
    selectedTaskIds.delete(taskId);
  }
  updateBatchToolbar();
}

function toggleSelectAll(isChecked) {
  if (isChecked) {
    tasks.forEach(t => selectedTaskIds.add(t.id));
  } else {
    selectedTaskIds.clear();
  }
  updateBatchToolbar();
  document.querySelectorAll(".task-batch-checkbox").forEach(cb => {
    const card = cb.closest(".task-card, .list-row");
    const rawId = (card?.id || "").replace("card-", "").replace("list-row-", "");
    cb.checked = selectedTaskIds.has(rawId);
    if (card) {
      if (cb.checked) card.classList.add("is-selected");
      else card.classList.remove("is-selected");
    }
  });
}

function clearBatchSelection() {
  selectedTaskIds.clear();
  updateBatchToolbar();
  document.querySelectorAll(".task-batch-checkbox").forEach(cb => cb.checked = false);
  document.querySelectorAll(".task-card.is-selected, .list-row.is-selected").forEach(el => el.classList.remove("is-selected"));
}

function updateBatchToolbar() {
  const bar = document.getElementById("batchActionBar");
  const countEl = document.getElementById("selectedTasksCount") || document.getElementById("batchSelectedCount");
  const selectAllCb = document.getElementById("selectAllCheckbox");
  const selectAllList = document.getElementById("selectAllList");
  const count = selectedTaskIds.size;

  if (countEl) countEl.innerText = count;
  if (bar) {
    if (count > 0) {
      bar.style.display = "flex";
      bar.classList.add("active");
    } else {
      bar.style.display = "none";
      bar.classList.remove("active");
    }
  }

  const allChecked = tasks.length > 0 && count === tasks.length;
  if (selectAllCb) selectAllCb.checked = allChecked;
  if (selectAllList) selectAllList.checked = allChecked;

  // 同步卡片/列表行上的高亮状态
  document.querySelectorAll(".task-card, .list-row").forEach(el => {
    const rawId = el.id.replace("card-", "").replace("list-row-", "");
    if (selectedTaskIds.has(rawId)) {
      el.classList.add("is-selected");
    } else {
      el.classList.remove("is-selected");
    }
  });
}

async function executeBatchAction(action) {
  if (selectedTaskIds.size === 0) {
    showToast("请先勾选需要批量操作的任务", "warning");
    return;
  }
  const taskIds = Array.from(selectedTaskIds);

  let confirmMsg = "";
  if (action === "delete") {
    confirmMsg = `确定要永久删除选中的 ${taskIds.length} 个任务及其所有历史记录吗？`;
  } else if (action === "download") {
    confirmMsg = `确定要为选中的 ${taskIds.length} 个任务启动强制重新下载吗？`;
  }

  if (confirmMsg && !confirm(confirmMsg)) {
    return;
  }

  try {
    showToast(`正在执行批量操作: ${action}...`, "info");
    const res = await fetch("/api/tasks/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: action, task_ids: taskIds })
    });
    const data = await res.json();
    if (data.status === "ok") {
      showToast(data.message || `批量操作完成`, "success");
      if (action === "delete") {
        clearBatchSelection();
      }
      await loadTasks();
    } else {
      showToast(`批量操作失败: ${data.detail || data.message || "未知错误"}`, "error");
    }
  } catch (err) {
    showToast(`批量请求异常: ${err.message}`, "error");
  }
}

function openBatchDirModal() {
  if (selectedTaskIds.size === 0) {
    showToast("请先勾选需要修改路径的任务", "warning");
    return;
  }
  const countEl = document.getElementById("batchDirTaskCount");
  if (countEl) countEl.innerText = selectedTaskIds.size;
  const modal = document.getElementById("batchDirModal");
  if (modal) modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
}

function closeBatchDirModal() {
  const modal = document.getElementById("batchDirModal");
  if (modal) modal.classList.remove("active");
}

async function submitBatchDir() {
  const newDir = document.getElementById("batchNewDir")?.value.trim();
  if (!newDir) {
    showToast("请输入新的存储保存路径", "warning");
    return;
  }
  const taskIds = Array.from(selectedTaskIds);
  try {
    const res = await fetch("/api/tasks/batch", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "set_dir", task_ids: taskIds, download_dir: newDir })
    });
    const data = await res.json();
    if (data.status === "ok") {
      showToast(data.message || "批量更新路径成功", "success");
      closeBatchDirModal();
      clearBatchSelection();
      await loadTasks();
    } else {
      showToast(`更新失败: ${data.detail || data.message}`, "error");
    }
  } catch (err) {
    showToast(`提交请求异常: ${err.message}`, "error");
  }
}

// ----------------- Shell 常用命令模板填充 -----------------

function applyCommandTemplate(type) {
  const input = document.getElementById("afterDownloadCmd");
  if (!input) return;

  const templates = {
    docker_restart: "docker restart my-container",
    systemd_restart: "systemctl restart my-service",
    linux_chmod: "chmod +x \"$RELEASE_FILEPATH\"",
    extract_tar: "tar -zxvf \"$RELEASE_FILEPATH\" -C \"$RELEASE_DIR\"",
    curl_webhook: "curl -X POST -H \"Content-Type: application/json\" -d '{\"app\":\"'$APP_NAME'\",\"ver\":\"'$RELEASE_VER'\"}' https://example.com/webhook"
  };

  if (templates[type]) {
    if (input.value.trim()) {
      input.value = input.value.trim() + "\n" + templates[type];
    } else {
      input.value = templates[type];
    }
    showToast(`已插入命令模板: ${type}`, "info");
  }
}

// ----------------- 调度与运行实时日志抽屉 -----------------

async function openLogsModal() {
  const modal = document.getElementById("logsModal");
  if (modal) modal.classList.add("active");
  if (window.lucide) window.lucide.createIcons();
  await fetchLogs(false);

  if (logsPollingTimer) clearInterval(logsPollingTimer);
  logsPollingTimer = setInterval(() => {
    const modalActive = document.getElementById("logsModal")?.classList.contains("active");
    if (modalActive) {
      fetchLogs(false);
    } else {
      clearInterval(logsPollingTimer);
      logsPollingTimer = null;
    }
  }, 3000);
}

function closeLogsModal() {
  const modal = document.getElementById("logsModal");
  if (modal) modal.classList.remove("active");
  if (logsPollingTimer) {
    clearInterval(logsPollingTimer);
    logsPollingTimer = null;
  }
}

async function fetchLogs(showFeedback = false) {
  try {
    const res = await fetch("/api/logs?limit=500");
    const json = await res.json();
    if (json.status === "ok") {
      currentLogsList = json.data || [];
      renderLogs();
      if (showFeedback) {
        showToast("已刷新最新系统日志", "info");
      }
    }
  } catch (err) {
    console.error("获取实时日志失败:", err);
  }
}

function setLogLevelFilter(level) {
  activeLogLevel = level;
  document.querySelectorAll("#logFilterTabs .filter-tab").forEach(tab => {
    if (tab.getAttribute("data-level") === level) {
      tab.classList.add("active");
    } else {
      tab.classList.remove("active");
    }
  });
  renderLogs();
}

function renderLogs() {
  const container = document.getElementById("terminalLogContainer");
  const search = (document.getElementById("logsSearch")?.value || "").toLowerCase().trim();
  const autoScroll = document.getElementById("logsAutoScroll")?.checked;
  const metaEl = document.getElementById("logsMetaInfo");

  if (!container) return;

  let filtered = currentLogsList;
  if (activeLogLevel !== "all") {
    filtered = filtered.filter(item => (item.level || "").toUpperCase() === activeLogLevel.toUpperCase());
  }
  if (search) {
    filtered = filtered.filter(item => 
      (item.message || "").toLowerCase().includes(search) || 
      (item.module || "").toLowerCase().includes(search) ||
      (item.time || item.timestamp || "").toLowerCase().includes(search)
    );
  }

  if (metaEl) {
    metaEl.innerText = `共 ${currentLogsList.length} 条记录 (当前显示 ${filtered.length} 条)`;
  }

  if (filtered.length === 0) {
    container.innerHTML = '<div style="color:#64748b; font-size:0.85rem; padding:1.5rem; text-align:center;">暂无匹配的系统运行日志</div>';
    return;
  }

  const html = filtered.map(log => {
    const lvl = (log.level || "INFO").toUpperCase();
    let lvlClass = "info";
    if (lvl === "SUCCESS") lvlClass = "success";
    else if (lvl === "WARNING" || lvl === "WARN") lvlClass = "warning";
    else if (lvl === "ERROR") lvlClass = "error";

    const rawTime = log.time || log.timestamp || "";
    const time = rawTime.slice(11, 19) || rawTime;
    const mod = log.module ? `[${escapeHtml(log.module)}]` : "";

    return `
      <div class="log-line">
        <span class="log-timestamp">${escapeHtml(time)}</span>
        <span class="log-level ${lvlClass}">${lvl}</span>
        <span class="log-module">${escapeHtml(mod)}</span>
        <span class="log-msg">${escapeHtml(log.message || '')}</span>
      </div>
    `;
  }).join("");

  container.innerHTML = html;

  if (autoScroll) {
    container.scrollTop = container.scrollHeight;
  }
}

async function clearSystemLogs() {
  if (!confirm("确定要清空内存中的系统运行日志吗？")) return;
  try {
    const res = await fetch("/api/logs", { method: "DELETE" });
    const json = await res.json();
    if (json.status === "ok") {
      currentLogsList = [];
      renderLogs();
      showToast("系统日志已清空", "success");
    }
  } catch (err) {
    showToast(`清空失败: ${err.message}`, "error");
  }
}

function copyLogsToClipboard() {
  const container = document.getElementById("terminalLogContainer");
  if (!container) return;
  const text = container.innerText;
  if (!text) {
    showToast("没有可复制的日志内容", "warning");
    return;
  }
  if (navigator && navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showToast("可见日志已成功复制到剪贴板", "success");
    }).catch(err => {
      showToast("复制失败: " + err, "error");
    });
  } else {
    // 兼容环境或非安全上下文
    try {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      showToast("可见日志已复制到剪贴板", "success");
    } catch (e) {
      showToast("当前浏览器环境不支持自动复制，请手动选中日志文本复制", "warning");
    }
  }
}

