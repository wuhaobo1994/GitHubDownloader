# GitRelease Watcher 生产级安装部署与全功能使用指南 (Official Guide)

> **适用版本**: v2.1+  
> **文档定位**: 生产部署、容器运维、任务调度、防呆测试与故障排查全能手册  
> **更新时间**: 2026-09-07  

---

## 目录
1. [系统简介与架构特性](#一系统简介与架构特性)
2. [环境要求与网络准备](#二环境要求与网络准备)
3. [三种安装部署方式 (保姆级教程)](#三三种安装部署方式-保姆级教程)
   - [方式一：Linux Systemd 系统服务 (最推荐)](#方式一linux-systemd-系统服务-最推荐)
   - [方式二：Docker & Docker Compose 容器化部署](#方式二docker--docker-compose-容器化部署)
   - [方式三：裸机轻量开发运行 (Windows / Linux / macOS)](#方式三裸机轻量开发运行-windows--linux--macos)
4. [控制面板首次配置向导 (必读)](#四控制面板首次配置向导-必读)
5. [监控任务全生命周期操作指南](#五监控任务全生命周期操作指南)
6. [进阶企业级特性实战](#六进阶企业级特性实战)
   - [多镜像故障自动降级轮询池](#61-多镜像故障自动降级轮询池)
   - [公网 API Key 访问控制与外部 Webhook 触发](#62-公网-api-key-访问控制与外部-webhook-触发)
   - [数据库在线热快照与一键还原](#63-数据库在线热快照与一键还原)
   - [多通道消息推送集成](#64-多通道消息推送集成)
7. [常见问题排查与 FAQ](#七常见问题排查与-faq)

---

## 一、系统简介与架构特性

**GitRelease Watcher** 是一套专为极客、站长与企业运维打造的自动化 GitHub 资产追踪、拉取与分发系统。深度解决国内服务器下载 GitHub Release 慢、易中断、命名混乱以及版本繁多的痛点。

```
                    ┌──────────────────────────────────┐
                    │    GitRelease Watcher 控制台     │
                    │   (4大视图 / 大盘看板 / 批量胶囊) │
                    └────────────────┬─────────────────┘
                                     │ FastAPI REST API
            ┌────────────────────────┼────────────────────────┐
            ▼                        ▼                        ▼
  【GitHub API 轮询】       【多加速源下载引擎】     【安全与自动化调度】
  • 智能架构识别 (x64/arm)   • 3 大镜像顺次故障降级   • 磁盘空间自动熔断 (2GB+)
  • 规则在线测试器防错       • 断点续传与 Range 拼接   • 归档解压与 chmod +x 赋权
  • 指数退避重试 (防雪崩)    • SHA256 清单严格校验    • Shell 自动化后处理管道
```

---

## 二、环境要求与网络准备

- **操作系统**：Linux (Debian 10+, Ubuntu 20.04+, CentOS 7+, Rocky Linux, Alpine), macOS, 或 Windows 10/11
- **Python 版本**：Python 3.8 及以上（建议 3.10+）
- **默认服务端口**：`8088` (可通过环境变量 `PORT` 或设置面板自定义)
- **磁盘建议**：预留至少 5GB 可用存储空间（用于缓存及归档软件包）

---

## 三、三种安装部署方式 (保姆级教程)

### 方式一：Linux Systemd 系统服务 (最推荐)

适合物理机、VPS、云服务器、软路由、树莓派等生产 Linux 环境，具备开机自启、崩溃自动重启与日志持久化守护。

#### 1. 克隆或解压项目文件
```bash
# 将项目代码置于推荐安装路径 /opt/gitrelease-watcher
sudo mkdir -p /opt/gitrelease-watcher
cd /opt/gitrelease-watcher
# 上传或拉取文件后赋予脚本执行权限
sudo chmod +x scripts/*.sh
```

#### 2. 执行一键安装脚本
```bash
sudo bash scripts/install.sh
```
安装脚本将自动执行：
- 检查系统 Python3 与 pip 环境；
- 自动安装必要依赖（`fastapi`, `uvicorn`, `apscheduler`, `httpx` 等）；
- 自动创建默认存储目录 `/www/zfile/dow`；
- 注册 Systemd 单元并自动设置开机自启。

#### 3. 常用运维管理命令
```bash
# 查看服务实时运行状态
sudo systemctl status gitrelease-watcher

# 查看后台实时滚动日志
sudo journalctl -u gitrelease-watcher -f

# 重启 / 停止 / 启动服务
sudo systemctl restart gitrelease-watcher
sudo systemctl stop gitrelease-watcher
sudo systemctl start gitrelease-watcher

# 卸载服务
sudo bash scripts/uninstall.sh
```

---

### 方式二：Docker & Docker Compose 容器化部署

适合追求容器隔离、NAS 用户（群晖 Synology、绿联 UGOS、极空间、威联通 QNAP）以及 Docker Swarm / K8s 环境。

#### 1. 准备 `docker-compose.yml`
在项目根目录已有预置配置文件：
```yaml
version: '3.8'

services:
  gitrelease-watcher:
    build:
      context: .
      dockerfile: docker/Dockerfile
    image: gitrelease-watcher:latest
    container_name: gitrelease-watcher
    restart: unless-stopped
    ports:
      - "8088:8088"
    volumes:
      # 持久化数据库与配置文件
      - ./data:/app/data
      # 挂载宿主机真实下载存储路径 (根据实际需求调整)
      - /www/zfile/dow:/www/zfile/dow
    environment:
      - TZ=Asia/Shanghai
      - PORT=8088
      - GITRELEASE_DB_PATH=/app/data/gitrelease_watcher.db
```

#### 2. 一键启动容器
```bash
# 后台构建并启动
docker compose up -d

# 查看容器日志
docker compose logs -f

# 停止容器
docker compose down
```

---

### 方式三：裸机轻量开发运行 (Windows / Linux / macOS)

适合本机快速体验、二次开发或临时测试：

```bash
# 1. 安装 Python 依赖库
pip install -r requirements.txt

# 2. 启动服务
python run.py
```
> Windows 用户可直接双击根目录下的 `start.bat` 快速启动。

---

## 四、控制面板首次配置向导 (必读)

打开浏览器，访问：`http://<您的服务器IP>:8088`

首次进入面板，强烈建议点击顶部右上角 **「通知与配置」** 进行 3 项关键初始化：

### 1. 填入 GitHub 个人访问令牌 (GitHub Token)
- **必要性**：GitHub 对未授权匿名 IP 施加了 **每小时 60 次** 的严格限频；填入任意有效 Token 后，API 额度提升至 **5,000 次/小时**！
- **获取步骤**：
  1. 登录 GitHub，点击右上角头像 ➜ `Settings`；
  2. 左侧最底端点击 `Developer Settings` ➜ `Personal access tokens (classic)` ➜ `Generate new token`；
  3. 权限勾选 `public_repo`，生成后复制 `ghp_xxxx` 粘贴至面板即可。

### 2. 确认加速镜像源
- 若服务器在**中国大陆**：代理模式保持「使用 GitHub 镜像加速前缀」，预置首选源为 `https://ghproxy.net/`；
- 系统已默认配置多镜像自动故障转移池，若首选源不可用将自动无缝轮询备用源。

### 3. 配置存储路径
- 全局默认目录为 `/www/zfile/dow`，支持结合路径宏变量自动分类存放。

---

## 五、监控任务全生命周期操作指南

### 1. 新建监控任务
点击右上角蓝色的 **「添加监控任务」** 按钮：
- **软件名称**：输入软件标识，如 `v2rayN` 或 `clash-verge`；
- **标识别名**：同仓库多任务专属别名（如 `Windows x64 便携版`、`Linux AMD64`），用于同仓库多平台任务隔离；
- **GitHub 仓库**：填写格式为标准 `owner/repo`，如 `2dust/v2rayN`；
- **包含规则 (Include)**：支持填入关键词（如 `windows, x64, zip`）或正则表达式；
- **排除规则 (Exclude)**：默认过滤 `sha256,asc,sig,txt,sbom` 等校验与源码附属文件；
- **自动解压归档包**：**默认未勾选**，如有自动解压需求可一键勾选，下载后将自动解压并赋予可执行权限；
- **检测周期**：可填入分钟数（如 `60`）或标准 Cron 表达式（如 `0 3 * * *` 每日凌晨3点执行）。

### 2. 规则在线测试器 (防写错神器)
在任务弹窗中点击 **「测试当前匹配效果」**：
- 系统即时连线 GitHub 解析 Release 资产列表；
- 直观展示“命中 1 个”、“命中多个”或“未命中”，并高亮命中的文件名，**彻底杜绝将整个 Release 的数十个安装包全部错误拉取的事故**。

### 3. 多视图自由切换
- **仓库聚合视图 (`grouped`)**：按软件仓库将不同系统分支卡片归拢展示；
- **平铺网格视图 (`flat`)**：现代高密自适应网格，每张卡片展示丰富版本及操作栏；
- **极简高密列表 (`list`)**：**行高锁定 38px**，去除臃肿堆叠，单行展示完整信息，操作栏提炼为【下载/编辑/删除】黄金 3 键，彻底解决横向滚动跳位问题；
- **活动时间线 (`timeline`)**：按发生时间倒序串联全部任务的发现、传输与错误事件。

### 4. 批量操作流线胶囊栏
勾选卡片复选框后，屏幕底部自动滑出居中胶囊工具条：
- 支持单行批量检测、批量启用、批量暂停、批量修改存储目录、批量重新拉取与批量安全删除。

---

## 六、进阶企业级特性实战

### 6.1 多镜像故障自动降级轮询池
系统内置了智能候选池：
```text
https://ghproxy.net/
https://mirror.ghproxy.com/
https://gh.ddlc.top/
```
当首选源遇到超时、404、502 时，下载引擎自动切换至下一个镜像并带上完整 URL 重新发起 Range 请求；全部镜像均失效时回退直连，确保高可用交付。

### 6.2 公网 API Key 访问控制与外部 Webhook 触发
1. **API Key 防护**：
   - 在设置面板中开启「启用 API Key 访问控制」，设置自定义密钥（如 `MySecret2026`）；
   - 前端集成智能凭据记忆与全局拦截，公网暴露时安全无忧。
2. **外部 Webhook 即时触发**：
   - 支持通过外部 CI/CD、脚本或监控中心发送请求：
     ```bash
     curl -X POST "http://localhost:8088/api/webhook/trigger/{task_id}" \
          -H "X-API-Key: MySecret2026"
     ```

### 6.3 数据库在线热快照与一键还原
- 在设置面板中点击 **「导出备份 (.db)」**，一秒导出当前全部任务、参数与下载记录的独立快照；
- 换机迁移或系统重装时，点击 **「导入还原」**，选择 `.db` 文件即可完整无损复原。

### 6.4 多通道消息推送集成
系统支持 8 大渠道并行推送，支持独立测试连接：
- **Telegram Bot** (支持代理服务器与 Markdown 排版)
- **Bark** (iOS 轻量即时推送)
- **钉钉 / 飞书 / 企业微信** 机器人 Webhook
- **Discord Webhook**
- **PushPlus** 微信公众号免客户端推送
- **SMTP 邮件通知**

### 6.5 版本平滑升级与零丢数据灾备自愈机制 (升级必读)

在过去版本中，部分用户反馈“升级版本后监控任务清单和计划被清空”，其本质原因是：
- **旧版打包缺陷**：早期的代码仓库或发行压缩包中意外包含了默认的空白 `data/gitrelease_watcher.db`。当用户下载新版本压缩包并在原目录 `unzip -o` 覆盖解压时，压缩包内的空白库将用户真实的任务库直接覆盖冲毁。
- **缺乏系统级灾备与自愈能力**：早期数据仅存放于项目内 `data/` 目录，若升级采用“删除旧目录重建”或“覆盖解压”，程序启动检测到 0 任务就作为全新安装启动，无法自动寻回历史任务。

**v2.1+ 全新重构了全链路「零丢失」灾备与自愈防御体系：**

```
 ┌───────────────────────────────────────────────────────────────┐
 │                  GitRelease Watcher 四重数据安全防线            │
 └───────────────────────────────────────────────────────────────┘
  [防线1: 源码与打包物理隔离]
  • 官方打包脚本 scripts/package_release.py 与 .gitignore 严禁携带任何 *.db
  • 发行压缩包内只有 data/.gitkeep 结构占位符，解压绝不可能覆盖用户数据！
                             ▼
  [防线2: 任务变更自动跨目录热备份]
  • 用户每次新增、修改、删除任务或保存设置，系统自动双写热快照：
    - Linux 系统级: /var/backups/gitrelease-watcher/gitrelease_auto_snapshot.db
    - Windows 系统级: %APPDATA%/gitrelease-watcher/backups/
    - 项目级备份: data/backups/gitrelease_auto_snapshot.db
  • 独立于项目源码目录之外，即使整目录被删除、覆盖，持久快照依然 100% 留存！
                             ▼
  [防线3: 启动期灾难自愈引擎 (Auto-Recovery)]
  • 每次服务启动 (init_db)，若检测到当前激活的数据库任务数为 0：
  • 自动毫秒级全盘扫描系统持久备份与历史 backup_* 目录；
  • 一旦发现存在历史任务的备份，自动执行无缝灾备回填与完整性校验！
  • 控制台输出 [Database 灾难自愈引擎] [OK] 恢复日志，前端打开任务全部都在！
                             ▼
  [防线4: 强化版平滑升级脚本]
  • scripts/update.sh 内置升级前自动快照 + unzip/tar 强制排除 data/* 选项。
```

#### 官方推荐的 3 种安全升级步骤：

- **推荐方式一：通过升级脚本一键更新 (传入压缩包)**
  ```bash
  cd /opt/gitrelease-watcher
  sudo bash scripts/update.sh /root/GitReleaseWatcher-v2.1.zip
  ```
  *(脚本会自动安全备份现有数据，以 `--exclude "data/*"` 物理隔离解压，增量更新依赖并重启服务)*

- **方式二：手动解压新版本升级**
  ```bash
  cd /opt/gitrelease-watcher
  # 关键: 使用 -x 明确排除 data 目录，确保不影响已有数据库
  unzip -o /path/to/GitReleaseWatcher-v2.1.zip -d . -x "data/*" "backup_*"
  # 运行升级适配脚本
  sudo bash scripts/update.sh
  ```

- **方式三：Git 拉取升级**
  ```bash
  cd /opt/gitrelease-watcher
  git pull
  sudo bash scripts/update.sh
  ```

*(注：即使因误操作手动将空白数据库覆盖了原库，v2.1+ 服务启动时也会自动通过「灾备自愈引擎」从系统保护备份中自动找回并恢复所有任务与计划！)*

---

## 七、常见问题排查与 FAQ

### Q1: 提示 `GitHub API 限流受限 (403)` 如何处理？
- **原因**：GitHub 限制未登录 IP 每小时最多请求 60 次，同一局域网或公网 IP 容易超标。
- **解决**：进入面板顶部「通知与配置」，填入免费申请的 GitHub Personal Access Token 即可拥有 5000 次/小时配额。

### Q2: 下载总是失败或速度极慢？
- **排查**：
  1. 检查设置中的「下载加速通道」是否为 `mirror`；
  2. 检查多镜像候选池中的镜像源在国内网络环境的连通性；
  3. 可在面板「系统日志」抽屉中查看详细的流式下载与重试过程。

### Q3: 提示 `磁盘剩余空间不足，触发安全熔断`？
- **原因**：目标存储盘剩余容量低于设定的安全阈值（默认 2.0 GB）。
- **解决**：清理对应磁盘空间，或在设置面板中将「磁盘最小剩余空间阈值」调小。

### Q4: 忘记全局 API Key 导致无法登录面板？
- **应急恢复**：
  在服务器终端执行 SQLite 命令直接关闭鉴权：
  ```bash
  sqlite3 data/gitrelease_watcher.db "UPDATE settings SET value = '0' WHERE key = 'api_key_enabled';"
  ```
  刷新浏览器页面即可免密直接进入。

### Q5: 如何彻底清理或完全卸载？
- Systemd 模式运行：
  ```bash
  sudo bash scripts/uninstall.sh
  ```
- 容器模式运行：
  ```bash
  docker compose down -v
  ```
