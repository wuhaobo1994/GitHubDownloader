import uvicorn
import os
import sys

# 将当前目录加入系统路径
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

if __name__ == "__main__":
    from backend.database import get_all_settings
    host = os.environ.get("HOST", "0.0.0.0")
    port = 8088
    try:
        db_settings = get_all_settings()
        cfg_port = db_settings.get("server_port")
        if cfg_port and str(cfg_port).strip().isdigit():
            port = int(str(cfg_port).strip())
        elif os.environ.get("PORT", "").isdigit():
            port = int(os.environ["PORT"])
    except Exception:
        if os.environ.get("PORT", "").isdigit():
            port = int(os.environ["PORT"])

    print(f"==================================================")
    print(f" GitRelease Watcher 服务正在启动...")
    print(f" 本地访问地址: http://127.0.0.1:{port}")
    print(f" 局域网访问: http://{host}:{port}")
    print(f"==================================================")
    uvicorn.run("backend.app:app", host=host, port=port, reload=False)
