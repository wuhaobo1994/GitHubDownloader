@echo off
chcp 65001 >nul
title GitRelease Watcher
echo ==================================================
echo  GitRelease Watcher - GitHub 自动升级下载面板
echo ==================================================

echo 正在检查 Python 依赖...
python -m pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

echo 启动服务...
python run.py
pause
