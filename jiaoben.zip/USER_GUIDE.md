# GitRelease Watcher - 完整使用与运维教程

欢迎使用 **GitRelease Watcher**！本系统专为自动化跟踪 GitHub 软件更新打造，特别适合部署在 Linux 服务器、树莓派、软路由以及各类 NAS（群晖、绿联、极空间）上，自动下载安装包并整理归档到您的本地目录（如 `/www/zfile/dow`）。

---

## 目录
1. [快速安装与启动](#一快速安装与启动)
2. [首次启动基础设置 (必看)](#二首次启动基础设置-必看)
3. [如何添加一个监控任务 (新手教程)](#三如何添加一个监控任务-新手教程)
4. [全平台智能自动分类说明](#四全平台智能自动分类说明)
5. [常用热门软件规则速查表](#五常用热门软件规则速查表)
6. [消息通知配置 (邮件/飞书/钉钉/企微)](#六消息通知配置)
7. [常见问题排查 (FAQ)](#七常见问题排查-faq)

---

## 一、快速安装与启动

### 1. 本地 Linux 服务器（一键安装）
将项目文件夹上传到服务器（如 `/opt/gitrelease-watcher`），在终端执行：
```bash
cd /opt/gitrelease-watcher
sudo bash scripts/install.sh
```
安装脚本会自动准备环境、安装依赖、创建目录 `/www/zfile/dow` 并配置好开机自启。

### 2. 访问控制面板
打开浏览器，访问：
👉 `http://<您的服务器IP>:8088`

---

## 二、首次启动基础设置 (必看)

首次打开面板，点击顶部导航栏右上角的 **「通知与配置」**：

1. **GitHub Token (强烈建议填入)**：
   - **为什么要填**：GitHub 对未登录的 IP 限制每小时只能查询 60 次 API。填入一个 Token 后额度直接飙升至 **5,000次/小时**！
   - **如何获取 (免费)**：登录 GitHub ➜ 点击右上角头像 ➜ `Settings` ➜ 左下角 `Developer settings` ➜ `Personal access tokens (classic)` ➜ `Generate new token` ➜ 名字随意填，勾选 `public_repo` ➜ 复制生成的 `ghp_xxxx` 填入面板即可。
2. **下载加速通道**：
   - 如果您的服务器位于**国内**：选择 **“使用 GitHub 镜像加速前缀”**（默认 `https://ghproxy.net/`），下载速度极快且防中断。
   - 如果您的服务器在**海外 VPS**：选择 **“直连官方下载”**。
3. **全局默认下载存储目录**：
   - 系统已默认设定为 **`/www/zfile/dow`**，与 ZFile 网盘无缝对接。

---

## 三、如何添加一个监控任务 (新手教程)

点击右上角蓝色的 **「添加监控任务」** 按钮：

### 步骤 1：填写软件名称与仓库
- **软件自定义名称**：随便起个好记的名字，例如 `v2rayN` 或 `Clash-Verge`。
- **GitHub 仓库**：填写 GitHub 上的 `作者/仓库名`，例如 `2dust/v2rayN` 或 `clash-verge-rev/clash-verge-rev`。

### 步骤 2：选择想要下载的系统架构
直接点击输入框上方的**预设按钮**：
- 🪟 如果要 Windows 版：点击 **「Windows x64 (.exe)」** 按钮
- 🍎 如果要 Mac 苹果电脑版：点击 **「Mac Apple Silicon (.dmg)」** 按钮
- 🤖 如果要手机安卓版：点击 **「Android (.apk)」** 按钮
- 🐧 如果要 Linux 版：点击 **「Linux x86_64 (.tar.gz)」** 或 **「Debian/Ubuntu (.deb)」**

### 步骤 3：规则在线测试 (✨ 核心功能，防写错)
填好后，点击右侧的 **「测试当前匹配效果」** 按钮：
- 系统会当场连接 GitHub，列出该项目最新版本的全部文件，并用绿字标明 **命中了哪一个文件**！
- 如果显示“命中 1 个”，且名字是您想要的安装包，说明规则完全正确！

### 步骤 4：设置检测周期
- 默认输入 `60` 表示每 60 分钟检测一次。
- 如果希望在固定的闲时/夜间下载，可输入 Cron 表达式，如 `0 3 * * *`（每天凌晨 3:00 执行）。

### 步骤 5：处理策略（自动下载 vs 仅提醒）
- **自动拉取下载最新安装包**：检测到新版本立刻自动静默下载到指定文件夹。
- **仅记录并通知，等待手动下载**：检测到新版本时不消耗流量，只给您发一条微信/飞书/邮件提醒，等您到面板上手动点击【下载】按钮才开始下载。

### 步骤 6：确认下载目录
输入框上方提供了快捷胶囊，点击 **「常用: 按系统分类」**，输入框会自动填入：
`/www/zfile/dow/{platform}/{name}`
（系统会自动记住这个目录，下次新建任务无需重复输入）。

最后点击 **「保存任务」**，任务即可正式开始自动化守护！

---

## 四、全平台智能自动分类说明

当您在保存路径中使用以下占位符时，系统在下载时会自动创建规整的子文件夹：

| 占位符 | 说明 | 实际转换效果示例 |
| :--- | :--- | :--- |
| `{platform}` 或 `{os}` | 自动识别系统大类 | 自动变成 `Windows`、`macOS`、`Android` 或 `Linux` |
| `{arch}` | 自动识别 CPU 架构 | 自动变成 `x64`、`arm64`、`x86`、`armv7` 等 |
| `{name}` | 您给软件起的别名 | 例如 `v2rayN`、`clash` |
| `{tag}` | 当前版本号 | 例如 `v1.5.0`、`7.24.9` |
| `{date}` | 下载当天的日期 | 格式 `2026-09-03` |

**推荐经典路径写法：**
```text
/www/zfile/dow/{platform}/{name}
```
下载后文件会自动存入：
- Windows 版：`/www/zfile/dow/Windows/v2rayN/v2rayN-windows-64-desktop.zip`
- Mac 版：`/www/zfile/dow/macOS/v2rayN/v2rayN-macos-arm64.dmg`
- 安卓版：`/www/zfile/dow/Android/v2rayNG/v2rayNG_arm64-v8a.apk`

---

## 五、常用热门软件规则速查表

| 软件名称 | GitHub 仓库 (`owner/repo`) | 包含规则 (Include) | 排除规则 (默认即可) | 对应平台 |
| :--- | :--- | :--- | :--- | :--- |
| **v2rayN** | `2dust/v2rayN` | `windows, 64-desktop` | `sha256, sig` | Windows x64 |
| **v2rayN (Mac)** | `2dust/v2rayN` | `macos, arm64.dmg` | `sha256, sig` | Mac 苹果芯片 |
| **v2rayNG (安卓)** | `2dust/v2rayNG` | `arm64-v8a.apk` | `sha256, txt` | Android 手机 |
| **Clash Verge Rev** | `clash-verge-rev/clash-verge-rev` | `x64-setup.exe` | `sha256, sig` | Windows x64 |
| **Clash Verge (Mac)** | `clash-verge-rev/clash-verge-rev` | `arm64.dmg` | `sha256, sig` | Mac 苹果芯片 |
| **Clash Verge (Ubuntu)** | `clash-verge-rev/clash-verge-rev` | `amd64.deb` | `sha256, sig` | Linux Debian/Ubuntu |
| **Syncthing** | `syncthing/syncthing` | `linux-amd64, tar.gz` | `sha256, asc` | Linux 64位 |
| **Frp 内网穿透** | `fatedier/frp` | `linux_amd64.tar.gz` | `sha256` | Linux 64位 |
| **Docker Compose** | `docker/compose` | `linux-x86_64` | `sha256` | Linux 独立二进制 |
| **Ollama** | `ollama/ollama` | `linux-amd64.tgz` | `sha256` | Linux 64位 |

---

## 六、消息通知配置

在「通知与配置」弹窗的第二个标签页 **「邮箱与机器人通知」** 中：

### 1. 邮件通知 (SMTP)
- **SMTP 服务器**：QQ 邮箱填 `smtp.qq.com`；163 邮箱填 `smtp.163.com`。
- **端口**：一般为 `465`（SSL 加密开）。
- **密码/授权码**：⚠️ 必须是邮箱后台生成的 **16位独立授权码**（并非邮箱本身的登录密码）。
- 点击 **“发送测试邮件”**，若邮箱收到邮件，说明设置成功！

### 2. 飞书自定义机器人 (Feishu)
- 在飞书群里添加“自定义机器人”，复制 Webhook 地址粘贴进面板。
- 如开启了安全签名加签，将密钥填入 Secret。
- 点击 **“测试飞书推送”** 验证。

### 3. 钉钉机器人 (DingTalk)
- 在钉钉群设置 ➜ 机器人 ➜ 自定义机器人 ➜ 复制 Webhook 粘贴进面板。
- 点击 **“测试钉钉推送”** 验证。

### 4. 企业微信机器人 (WeChat Work)
- 在微信群添加机器人，复制 Webhook 地址粘贴进面板。
- 点击 **“测试企微推送”** 验证。

---

## 七、常见问题排查 (FAQ)

### Q1：为什么测试规则时提示 `403 Rate Limited`？
**答**：这是因为没有配置 GitHub Token，触发了 GitHub 对同一个 IP 每小时 60 次的匿名访问限制。请按照本教程第二节生成一个免费的 GitHub Token 填入即可彻底解决。

### Q2：为什么提示“检测到新版，但未匹配到资产安装包”？
**答**：说明您的**包含规则写得太严格**，或者该项目的作者在这个版本中改变了安装包文件名。点击编辑任务，使用 **“规则在线测试器”**，查看该 Release 的所有实际文件名，微调包含关键词即可。

### Q3：下载完成后如何自动解压或重启我的程序？
**答**：在任务配置里的“下载完成后触发命令”中填入系统命令，例如：
```bash
tar -zxvf {filepath} -C /usr/local/bin/ && systemctl restart myapp
```
系统下载完后会自动替换路径并静默在后台执行。

### Q4：以后更新了代码，旧的任务和数据会丢吗？
**答**：绝不会丢失！只要您的 `data/` 文件夹还在，无论怎么升级程序，执行 `sudo bash scripts/update.sh` 都会自动继承所有任务和历史记录。

---

## 八、进阶高级特性

### 1. GitHub WebHook 0 秒秒级同步 (免等待轮询)
如果您监控的是自己或团队管理的 GitHub 仓库，无需等待每 60 分钟的周期轮询：
1. 打开 GitHub 仓库页面 ➜ **Settings** ➜ **Webhooks** ➜ **Add webhook**；
2. **Payload URL**：填入 `http://<您的服务器IP>:8088/api/webhook/github`；
3. **Content type**：选择 `application/json`；
4. **Which events would you like to trigger this webhook?**：勾选 `Let me select individual events.` 并勾选 **`Releases`**；
5. 点击 **Add webhook** 保存。以后一旦在 GitHub 发布 Release，面板将在 **0 秒内瞬间感知并启动自动下载**！

### 2. 软件更新日志 (Release Notes) 面板速览与推送卡片
- 在每个任务卡片右侧，点击 **「日志」** 按钮，即可弹出该版本由官方发布的完整 Markdown 更新日志；
- 在微信/钉钉/飞书推送的卡片中，系统也会自动摘录前 300 字更新日志摘要，一眼洞悉更新要点。

### 3. 断点续传与 SHA256 完整性自动校验
- **断点续传 (HTTP Range)**：当网络偶发波动中断时，重新检测将自动利用已下载的 `.tmp.part` 字节范围续传，无需从头重下；
- **SHA256 校验**：若作者发布时附带了 `.sha256` 或 `checksums.txt`，系统下载落地后会自动计算本地文件的 Hash 进行比对，并在历史记录中点亮 `SHA256✓` 绿标。
