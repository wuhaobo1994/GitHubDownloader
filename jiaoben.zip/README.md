# GitRelease Watcher (GitHub 安装包自动升级与多设备下载面板)

<p align="center">
  <b>轻量、高可用、高颜值的 GitHub Release 升级监测与自动化多设备下载面板</b><br>
  专为本地 Linux 主机、软路由、云服务器、各类 NAS（群晖/绿联/极空间）及跨平台环境打造<br><br>
  👉 <b><a href="docs/INSTALL_AND_USER_GUIDE.md">📖 完整安装部署与使用指南</a></b> | 
  👉 <b><a href="docs/PRODUCT_PLANNING.md">📑 产品规划与演进白皮书</a></b> | 
  👉 <b><a href="USER_GUIDE.md">🚀 新手速成教程</a></b>
</p>

---

## 🌟 核心特性

- 🖥️ **现代化可视化控制台**：精致深色极客风设计，玻璃拟态质感，支持移动端/PC端响应式自适应。
- 📦 **多任务并发监控**：支持同时跟踪任意数量的 GitHub 软件仓库（如 `syncthing/syncthing`、`fatedier/frp` 等）。
- 🔔 **全渠道即时通知推送**：
  - **邮件 (SMTP)**：支持 QQ/163/Gmail/企业邮箱等，支持 SSL 加密与富文本通知。
  - **飞书机器人 (Feishu)**：支持 Webhook 及安全加签 Secret，卡片式美观呈现。
  - **钉钉群机器人 (DingTalk)**：支持 Webhook 与签名防伪。
  - **企业微信机器人 (WeChat Work)**：支持群机器人一键推送。
  - **即时测试按钮**：在面板中可当场点击“测试推送”，秒速排查通知配置是否正常。
- 🧹 **磁盘老旧版本自动清理 (Retention)**：
  - 可配置每个软件保留最近 N 个版本包（默认 3 个），自动淘汰过期旧包，杜绝塞满磁盘。
- 🎯 **智能资产规则匹配引擎**：
  - **关键词匹配**：支持逗号分隔多关键词（如 `linux, amd64, tar.gz`），不区分大小写，精准锁定所需架构安装包。
  - **正则匹配**：支持高级正则表达式匹配，从容应对复杂命名规则。
  - **排除规则**：自动过滤 `sha256`, `asc`, `sig`, `txt` 等杂项校验文件。
  - **在线规则测试器**：在添加任务时可一键拉取真实 Release 列表并实时高亮命中结果，杜绝规则写错！
- ⏱️ **自定义轮询调度**：每个任务支持独立配置检测周期（分钟间隔或自定义 Cron），支持随时手动一键检测。
- 🔍 **线上版本智能比对**：持久化本地已下载版本 Tag 与线上最新发布比对，自动过滤 Pre-release（可选），避免无意义重复下载。
- 📂 **各设备/多任务自定义目录**：
  - 支持全局默认存储目录，各任务可按需自定义专属保存路径。
  - 支持动态宏路径占位符：`{name}` (软件名)、`{tag}` (版本号)、`{date}` (下载日期)、`{repo_name}` 等。
- 💾 **智能本地已有文件识别与免下载省流**：
  - 添加任务或执行版本检测时，系统自动探测目标存储目录；若本地已存在同名且体积完全一致的安装包（并支持 SHA256 校验），**自动跳过网络下载直接同步版本，节省流量 0 KB 消耗**！
  - 在前端添加任务弹窗中点击「测试规则」，即可即时预览命中资产以及本地是否已存在该文件。
- 🚀 **国内网络加速**：
  - 内置 GitHub 镜像通道切换（如 `ghproxy.net`、`mirror.ghproxy.com`），解决国内服务器下载龟速或中断问题。
  - 支持配置 GitHub Personal Access Token，避免匿名 API 60次/小时的限流。
  - 支持配置本地 HTTP/SOCKS5 代理。
- 🛡️ **回车防误触与智能专属别名**：
  - 添加任务与系统设置弹窗内置输入框**防误触保护**，键盘回车键不再意外触发提交，保障填写从容安全；
  - **任务专属标识别名**在未手动填写时，系统默认自动智能取值为「**软件名称+{platform}**」（例如: `v2rayNG-Android`、`Clash-Windows-x64`），并在同仓库下自动处理重复递增，保证 100% 绝对唯一！
- 🌐 **后台自定义 Web 服务端口**：支持在系统设置面板中随时自定义监听端口号（默认 8088），杜绝与其他应用或 NAS 服务的端口占用冲突。
- 🔄 **监控任务批量导入与导出 (跨面板极速共享)**：
  - **一键导出**：支持一键导出全部任务配置为标准 JSON 配置文件，或直接一键复制 JSON 到剪贴板，方便备份与分发；
  - **智能导入**：支持上传 `.json` 配置文件或直接粘贴文本批量导入；提供「智能共存 (别名递增)」、「跳过重复」与「覆盖更新」三种冲突处理策略；
  - 导入完成后自动挂载进调度器并触发初始检测，轻松实现多台机器或多个面板间的任务极速同步。
- 📊 **多视图显示与自适应管理体系**：
  - **平铺网格视图 (`flat`)**：立体卡片直观浏览全部监控软件；
  - **仓库聚合视图 (`grouped`)**：多平台/多分支任务归集于同一仓库大卡片下，支持一键检测全分支；
  - **高密度列表视图 (`list`)**：紧凑表格呈现，适合管理数十上百个海量仓库；
  - **活动时间线视图 (`timeline`)**：实时时间轴串联任务检测、升级发现、传输开始与完成日志；
  - **仓库多资产详情抽屉**：点击卡片或详情按钮即时展现 Release 完整文件清单、架构、体积、匹配与本地存在状态；
  - **状态筛选与多维排序**：支持按「全部/有新版本/下载中/已是最新/失败」即时过滤，支持按时间、名称、状态、版本排序，`localStorage` 本地自动记忆切换模式。
- 📈 **全盘下载统计仪表盘**：
  - 顶栏「下载统计」独立模态面板，极速汇总**本周下载**、**本月下载**、**总下载量**、**下载成功率 (%)** 与累计网络流量；
  - 呈现**最常下载软件榜单 (Top 10)**，直观展示下载次数、占用空间与可视化进度条。
- ⚙️ **自动化后处理脚本**：支持下载完成后自动触发 Linux Shell 脚本（如解压 `tar -zxvf`、赋予执行权限 `chmod +x`、安装 `.deb/.rpm`、或重启服务）。
- 🐧 **Linux 原生守护进程**：提供 `install.sh`，一键配置 Systemd 开机自启服务，无缝集成到 Linux 系统环境。

---

## 🚀 快速上手 (Linux)

### 方式一：一键自动安装为 Systemd 系统服务 (最推荐)

在 Linux 终端中进入项目目录，运行一键安装脚本：

```bash
cd jiaoben
sudo bash scripts/install.sh
```

---

### 🔄 旧版本如何平滑升级到新版本？(无损保留历史任务与配置)

如果您之前已经安装过旧版本，想要升级到最新版本且**不丢失原有的任务和下载历史**：

1. 将最新的项目文件覆盖上传到 Linux 原目录（⚠️ **注意：不要删除原有的 `data` 文件夹**）；
2. 在终端进入项目目录，运行专属平滑升级脚本：
```bash
cd jiaoben
sudo bash scripts/update.sh
```
该脚本会自动：
- 停止旧服务；
- 自动为您的数据库做一份带时间戳的安全备份（保存在 `backup_xxxx/`）；
- 自动增量安装新依赖包；
- 重新拉起最新版本服务，原有任务和配置无缝直接继承！

脚本将自动完成：
1. 检查并安装 Python3 及虚拟环境；
2. 自动安装必要运行依赖；
3. 注册 Linux `systemd` 系统服务并开启**开机自动启动**；
4. 打印 Web 控制面板访问地址。

**常用管理命令：**
```bash
# 查看服务运行状态
sudo systemctl status gitrelease-watcher

# 实时查看检测与下载日志
sudo journalctl -u gitrelease-watcher -f

# 重启 / 停止服务
sudo systemctl restart gitrelease-watcher
sudo systemctl stop gitrelease-watcher
```

---

### 方式二：手动运行 (前台调试)

```bash
# 1. 创建并激活虚拟环境
python3 -m venv venv
source venv/bin/activate

# 2. 安装依赖
pip install -r requirements.txt

# 3. 启动面板
python run.py
```
启动后，在浏览器访问：`http://<Linux服务器IP>:8088`

---

### 方式三：Docker / Docker Compose 一键部署

适合在群晖 / 威联通 / 飞牛私有云 (FNOS) / Unraid / 极空间 / 云服务器等容器环境下运行：

```bash
# 1. 直接在项目根目录下启动容器
docker compose up -d

# 2. 查看容器运行日志
docker compose logs -f
```

容器内部端口为 `8088`，已预置持久化卷：
- `./data`：持久化任务数据与配置数据库；
- `/www/zfile/dow`：宿主机下载存储目录（可按需修改 `docker-compose.yml` 挂载点）。

---

## 💡 常见软件监控规则配置示例

| 软件名称 | GitHub 仓库 (`owner/repo`) | 包含规则 (Include) | 适用系统架构 |
| :--- | :--- | :--- | :--- |
| **Syncthing** | `syncthing/syncthing` | `linux-amd64, tar.gz` | Linux 64位 x86_64 |
| **Clash Verge Rev** | `clash-verge-rev/clash-verge-rev` | `amd64, deb` | Ubuntu / Debian |
| **Xray-core** | `XTLS/Xray-core` | `linux-64.zip` | Linux 64位 |
| **Frp** | `fatedier/frp` | `linux_amd64.tar.gz` | Linux 64位 |
| **Docker Compose** | `docker/compose` | `linux-x86_64` | Linux 64位 二进制 |
| **Ollama** | `ollama/ollama` | `linux-amd64.tgz` | Linux 64位 |

> 💡 **提示**：在添加任务弹窗中，可以直接点击常用预设标签（如 `windows, x64, exe`、`arm64, dmg` 等）一键填入，并可在设置中自由定制属于您的常用规则关键词库！

---

## 📂 自定义设备保存目录与宏变量

每个任务均可在当前设备上独立配置保存路径。支持使用以下动态宏变量：

- `{name}`：软件自定义名称（如 `Syncthing`）
- `{sub_name}`：任务专属标识别名（如 `Windows x64 便携版`、`Linux AMD64`）
- `{platform}`：系统平台（自动识别分类为 `Windows` / `Linux` / `macOS` / `Android`）
- `{arch}`：CPU 架构（自动识别分类为 `x64` / `arm64` / `armv7` 等）
- `{tag}`：版本号标签（如 `v1.27.0`）
- `{date}`：下载当天的日期（格式 `YYYY-MM-DD`）
- `{repo_owner}`：GitHub 仓库拥有者
- `{repo_name}`：GitHub 仓库项目名

**路径组合示例：**
- 按平台架构智能归档：`/www/zfile/dow/{platform}/{name}`
- 多分支专属路径：`/www/zfile/dow/{name}/{sub_name}`
- 统一版本归档：`/opt/downloads/{name}/{tag}`

---

## 🔧 下载完成自动化脚本示例 (后处理命令)

支持在安装包下载成功后，自动执行 Linux 命令。支持的占位符：
- `{filepath}`：已下载文件的完整绝对物理路径
- `{filename}`：文件名
- `{dir}`：目标存放文件夹
- `{tag}`：版本号

**实用示例：**

1. **自动解压 `.tar.gz` 到指定目录**：
   ```bash
   tar -zxvf {filepath} -C /usr/local/bin/
   ```
2. **下载二进制文件后自动赋予可执行权限**：
   ```bash
   chmod +x {filepath}
   ```
3. **Ubuntu/Debian 自动静默安装 `.deb` 包**：
   ```bash
   dpkg -i {filepath}
   ```
4. **下载完发送通知 (以 cURL 触发 Webhook 为例)**：
   ```bash
   curl -X POST -d "软件更新完成: {filename}" https://your-notify-url.com
   ```

---

## 🛠️ 项目技术栈

- **后端**：Python 3.8+、FastAPI、Uvicorn、APScheduler (定时调度)、HTTPX (异步流式下载与断点续传)
- **持久化**：SQLite (Python 原生内置，零部署单文件数据库)
- **前端**：原生现代化 HTML5 + 响应式现代深色 CSS + 异步 Fetch API + Lucide 矢量图标
- **部署**：Linux Systemd 守护进程、Shell 自动化脚本、Docker 容器
