import sqlite3
import os
import json
import uuid
import time
import shutil
import glob
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))

def get_db_path() -> str:
    return os.environ.get("GITRELEASE_DB_PATH") or os.path.join(DATA_DIR, "gitrelease_watcher.db")

DB_PATH = get_db_path()

_last_auto_backup_ts = 0.0

def get_persistent_backup_dirs() -> List[str]:
    """获取所有受保护的系统级与项目级持久备份目录列表"""
    dirs = []
    # 1. 本地项目内持久目录
    in_tree_dir = os.path.abspath(os.path.join(DATA_DIR, "backups"))
    dirs.append(in_tree_dir)

    # 2. 系统级跨目录持久存储 (防止整目录覆盖/解压升级/mv重命名导致丢失)
    if os.name == "nt":
        appdata = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA") or os.environ.get("USERPROFILE")
        if appdata:
            dirs.append(os.path.join(appdata, "gitrelease-watcher", "backups"))
        programdata = os.environ.get("ProgramData")
        if programdata:
            dirs.append(os.path.join(programdata, "gitrelease-watcher", "backups"))
    else:
        # Linux / Unix / macOS: 系统级备份目录 (常用于生产 systemd 守护运行环境)
        dirs.append("/var/backups/gitrelease-watcher")
        # 用户主目录备份配置
        home_config = os.path.expanduser("~/.config/gitrelease-watcher/backups")
        dirs.append(home_config)

    # 3. 如果环境变量特别指定了持久备份目录
    custom_dir = os.environ.get("GITRELEASE_BACKUP_DIR")
    if custom_dir:
        dirs.insert(0, os.path.abspath(custom_dir))

    return dirs

def ensure_persistent_auto_backup(force: bool = False):
    """
    自动持久化热备份机制:
    在任务增加、修改、删除或全局设置变更时，自动将当前有效的任务数据
    双写同步保存到系统持久目录及数据备份目录。
    【核心安全红线】绝不允许用空的数据库覆盖已存在的有效备份！
    """
    global _last_auto_backup_ts
    now_ts = time.time()
    if not force and (now_ts - _last_auto_backup_ts < 5.0):
        # 5秒内节流，防止高频操作导致重复快照
        return

    # 检查当前数据库是否有有效任务数据
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='tasks'")
        if not cur.fetchone()[0]:
            conn.close()
            return
        cur.execute("SELECT COUNT(*) FROM tasks")
        task_count = cur.fetchone()[0]
        conn.close()
    except Exception:
        return

    # 【核心安全防线】：空库绝不覆盖持久备份！
    if task_count == 0:
        return

    # 如果是测试环境数据库且未显式指定测试恢复，跳过自动备份以维持隔离
    cur_db = get_db_path()
    if ("test" in cur_db.lower() or os.environ.get("GITRELEASE_TEST_MODE") == "1") and os.environ.get("FORCE_TEST_RECOVER") != "1":
        return

    _last_auto_backup_ts = now_ts

    for b_dir in get_persistent_backup_dirs():
        try:
            os.makedirs(b_dir, exist_ok=True)
            # 1. 核心快照文件 (始终保持最新一份健康库快照)
            hot_snapshot = os.path.join(b_dir, "gitrelease_auto_snapshot.db")
            temp_snap = hot_snapshot + f".tmp_{os.getpid()}"
            if os.path.exists(temp_snap):
                try:
                    os.remove(temp_snap)
                except Exception:
                    pass

            src_conn = get_connection()
            try:
                clean_target = os.path.abspath(temp_snap).replace("\\", "/")
                src_conn.execute(f"VACUUM INTO '{clean_target}'")
                src_conn.close()
                if os.path.exists(temp_snap):
                    if os.path.exists(hot_snapshot):
                        try:
                            os.remove(hot_snapshot)
                        except Exception:
                            pass
                    shutil.move(temp_snap, hot_snapshot)
            except Exception:
                try:
                    src_conn.close()
                except Exception:
                    pass
                # 备用兼容方案: sqlite3.backup
                bck_conn = sqlite3.connect(hot_snapshot)
                src_conn = get_connection()
                with bck_conn:
                    src_conn.backup(bck_conn)
                bck_conn.close()
                src_conn.close()

            # 2. 每日/轮转版本快照 (保留最近 5 份历史快照)
            today_str = datetime.now().strftime("%Y%m%d")
            daily_file = os.path.join(b_dir, f"gitrelease_snapshot_{today_str}.db")
            if not os.path.exists(daily_file) and os.path.exists(hot_snapshot):
                shutil.copy2(hot_snapshot, daily_file)

            # 清理过期的轮转备份，仅保留最近 5 个
            history_snaps = sorted(glob.glob(os.path.join(b_dir, "gitrelease_snapshot_*.db")))
            if len(history_snaps) > 5:
                for old_snap in history_snaps[:-5]:
                    try:
                        os.remove(old_snap)
                    except Exception:
                        pass
        except Exception:
            continue

def check_and_auto_recover_tasks() -> bool:
    """
    版本升级灾难自愈保护引擎:
    在应用启动或数据库初始化时，如果检测到当前激活的数据库是空库 (tasks表记录数为0)，
    系统将自动扫描系统持久备份、项目数据备份及旧版本备份目录。
    一旦发现历史有任务数据的备份快照，立刻自动无缝回填恢复！
    彻底根治因‘覆盖解压新版本压缩包’、‘克隆覆盖’或‘重装’导致任务被清空的问题。
    """
    cur_db = get_db_path()
    # 如果是测试环境数据库且未显式要求测试自愈，跳过以维持测试独立性
    if ("test" in cur_db.lower() or os.environ.get("GITRELEASE_TEST_MODE") == "1") and os.environ.get("FORCE_TEST_RECOVER") != "1":
        return False

    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='tasks'")
        if not cur.fetchone()[0]:
            conn.close()
            return False
        cur.execute("SELECT COUNT(*) FROM tasks")
        current_task_count = cur.fetchone()[0]
        conn.close()
    except Exception:
        return False

    # 当前数据库中已有任务，无需恢复，但主动同步一次持久备份以防未来损坏
    if current_task_count > 0:
        ensure_persistent_auto_backup()
        return False

    # 收集可能存在历史有效任务的候选备份文件
    candidate_files = []
    search_dirs = get_persistent_backup_dirs()

    # 扩展搜索: 搜索项目同级或上级所有 backup_* 目录 (例如 scripts/update.sh 备份的目录)
    parent_dir = os.path.abspath(os.path.join(DATA_DIR, ".."))
    grandparent_dir = os.path.abspath(os.path.join(parent_dir, ".."))
    extra_patterns = [
        os.path.join(parent_dir, "backup_*", "data", "gitrelease_watcher.db"),
        os.path.join(parent_dir, "backup_*", "gitrelease_watcher.db"),
        os.path.join(grandparent_dir, "backup_*", "data", "gitrelease_watcher.db"),
        os.path.join(DATA_DIR, "gitrelease_pre_update.db"),
        os.path.join(DATA_DIR, "*.db.restore_prev"),
        os.path.join(DATA_DIR, "*.db.bak")
    ]
    for pattern in extra_patterns:
        for f in glob.glob(pattern):
            if os.path.isfile(f):
                candidate_files.append(f)

    for s_dir in search_dirs:
        if os.path.exists(s_dir):
            for root, _, files in os.walk(s_dir):
                for f in files:
                    if f.endswith(".db"):
                        full_p = os.path.join(root, f)
                        candidate_files.append(full_p)

    # 去重并按修改时间倒序 (优先使用最新的备份)
    seen = set()
    unique_candidates = []
    for cf in candidate_files:
        real_p = os.path.realpath(cf)
        if real_p not in seen and real_p != os.path.realpath(cur_db):
            seen.add(real_p)
            unique_candidates.append(real_p)

    unique_candidates.sort(key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0, reverse=True)

    # 遍历候选文件，寻找包含 tasks > 0 的有效备份
    for candidate in unique_candidates:
        try:
            chk_conn = sqlite3.connect(candidate, timeout=3.0)
            chk_cur = chk_conn.cursor()
            chk_cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='tasks'")
            if not chk_cur.fetchone()[0]:
                chk_conn.close()
                continue
            chk_cur.execute("SELECT COUNT(*) FROM tasks")
            cand_task_count = chk_cur.fetchone()[0]
            chk_conn.close()

            if cand_task_count > 0:
                print(f"\n==================================================================")
                print(f" [Database 灾难自愈引擎] [!] 检测到当前数据库为升级覆盖后的空白库 (任务数: 0)")
                print(f" [Database 灾难自愈引擎] 正在从系统持久备份恢复历史任务: {candidate}")
                print(f" [Database 灾难自愈引擎] 发现已保存监控任务数: {cand_task_count} 条")
                print(f"==================================================================")

                restore_database(candidate, skip_auto_recover=True)

                print(f" [Database 灾难自愈引擎] [OK] 历史任务与配置已全量无缝恢复！升级零丢失！")
                print(f"==================================================================\n")
                return True
        except Exception:
            continue

    return False

def get_connection():
    cur_db_path = get_db_path()
    target_dir = os.path.dirname(cur_db_path)
    if target_dir:
        os.makedirs(target_dir, exist_ok=True)
    conn = sqlite3.connect(cur_db_path, timeout=30.0)
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.row_factory = sqlite3.Row
    return conn

def init_db(skip_auto_recover: bool = False):
    conn = get_connection()
    conn.execute("PRAGMA journal_mode=WAL;")
    cursor = conn.cursor()

    # 1. 任务表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        sub_name TEXT DEFAULT '',
        repo TEXT NOT NULL,
        enabled INTEGER DEFAULT 1,
        check_interval INTEGER DEFAULT 60,
        cron_expr TEXT DEFAULT '',
        include_prerelease INTEGER DEFAULT 0,
        filter_mode TEXT DEFAULT 'keywords',
        asset_filter_include TEXT DEFAULT '',
        asset_filter_exclude TEXT DEFAULT 'sha256,asc,sig,txt,sbom',
        download_dir TEXT DEFAULT '',
        auto_download INTEGER DEFAULT 1,
        after_download_cmd TEXT DEFAULT '',
        local_version TEXT DEFAULT '',
        remote_version TEXT DEFAULT '',
        last_checked_at TEXT DEFAULT '',
        last_downloaded_at TEXT DEFAULT '',
        status TEXT DEFAULT 'idle',
        status_message TEXT DEFAULT '未执行检测',
        created_at TEXT DEFAULT '',
        release_notes TEXT DEFAULT '',
        webhook_secret TEXT DEFAULT '',
        auto_extract INTEGER DEFAULT 0,
        tags TEXT DEFAULT ''
    )
    ''')

    # 2. 下载历史表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id TEXT NOT NULL,
        task_name TEXT NOT NULL,
        tag_name TEXT NOT NULL,
        file_name TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        save_path TEXT NOT NULL,
        download_time TEXT NOT NULL,
        duration REAL DEFAULT 0,
        status TEXT DEFAULT 'success',
        error_msg TEXT DEFAULT '',
        release_notes TEXT DEFAULT '',
        checksum_status TEXT DEFAULT 'none'
    )
    ''')

    # 3. 全局设置表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    ''')

    # 4. 自动无缝结构迁移 (为现有库安全补充 sub_name, release_notes 与 checksum_status 字段)
    cursor.execute("PRAGMA table_info(tasks)")
    task_cols = [c["name"] for c in cursor.fetchall()]
    if "sub_name" not in task_cols:
        cursor.execute("ALTER TABLE tasks ADD COLUMN sub_name TEXT DEFAULT ''")
    if "release_notes" not in task_cols:
        cursor.execute("ALTER TABLE tasks ADD COLUMN release_notes TEXT DEFAULT ''")
    if "webhook_secret" not in task_cols:
        cursor.execute("ALTER TABLE tasks ADD COLUMN webhook_secret TEXT DEFAULT ''")
    if "auto_extract" not in task_cols:
        cursor.execute("ALTER TABLE tasks ADD COLUMN auto_extract INTEGER DEFAULT 0")
    if "tags" not in task_cols:
        cursor.execute("ALTER TABLE tasks ADD COLUMN tags TEXT DEFAULT ''")

    cursor.execute("PRAGMA table_info(history)")
    hist_cols = [c["name"] for c in cursor.fetchall()]
    if "release_notes" not in hist_cols:
        cursor.execute("ALTER TABLE history ADD COLUMN release_notes TEXT DEFAULT ''")
    if "checksum_status" not in hist_cols:
        cursor.execute("ALTER TABLE history ADD COLUMN checksum_status TEXT DEFAULT 'none'")

    # 初始化默认全局设置
    default_settings = {
        "panel_title": "Github定时下载器",
        "panel_subtitle": "GitHub 升级自动监测与多设备下载",
        "custom_download_dirs": "/www/zfile/dow/{platform}/{name}\n/www/zfile/dow/{name}/{platform}\n/www/zfile/dow/{name}",
        "device_name": "Linux-01",
        "github_token": "",
        "proxy_mode": "mirror",  # mirror(镜像前缀), http_proxy(HTTP/SOCKS代理), direct(直连)
        "mirror_prefix": "https://ghproxy.net/",
        "mirror_fallback_list": "https://ghproxy.net/\nhttps://mirror.ghproxy.com/\nhttps://gh.ddlc.top/",
        "http_proxy": "",
        "default_download_dir": "/www/zfile/dow",
        "max_concurrent_downloads": "3",
        "request_timeout": "60",
        "keep_latest_versions": "3",
        "min_disk_free_gb": "2",
        "notify_enabled": "1",
        "notify_events": "upgrade_found,download_success,download_failed,disk_warning",
        "telegram_enabled": "0",
        "telegram_bot_token": "",
        "telegram_chat_id": "",
        "telegram_api_url": "https://api.telegram.org",
        "bark_enabled": "0",
        "bark_server_url": "https://api.day.app",
        "bark_key": "",
        "webhook_enabled": "1",
        "webhook_token": "",
        "api_key_enabled": "0",
        "api_key": "",
        "checksum_strict": "0",  # 0: 校验不符仅记录警告; 1: 严格校验不符强制拦截并删除临时包
        "discord_enabled": "0",
        "discord_webhook": "",
        "pushplus_enabled": "0",
        "pushplus_token": "",
        "server_port": "8088",
        "custom_include_tags": "windows, x64, exe\nwindows, x64, zip\nmsi\narm64, dmg\nx64, dmg\napk\nlinux, amd64, tar.gz\nlinux, arm64, tar.gz\namd64, deb\nAppImage",
        "custom_exclude_tags": "sha256,asc,sig,txt,sbom\nsha256,sig,txt\ndebug,symbols,source\nmsi,rpm\nsha512,asc"
    }

    for k, v in default_settings.items():
        cursor.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))

    conn.commit()
    conn.close()

    # 触发版本升级灾难自愈检测 (若当前库为空白库，自动扫描并从持久备份恢复)
    if not skip_auto_recover:
        check_and_auto_recover_tasks()

# 数据库操作接口封装
def get_all_settings() -> Dict[str, str]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT key, value FROM settings")
    rows = cursor.fetchall()
    conn.close()
    return {row["key"]: row["value"] for row in rows}

def update_settings(settings_dict: Dict[str, Any]):
    conn = get_connection()
    cursor = conn.cursor()
    for k, v in settings_dict.items():
        cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (k, str(v)))
    conn.commit()
    conn.close()
    ensure_persistent_auto_backup(force=True)

def get_tasks() -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tasks ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_task(task_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def create_task(task_data: Dict[str, Any]) -> str:
    conn = get_connection()
    cursor = conn.cursor()
    task_id = str(uuid.uuid4())[:8]
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute('''
    INSERT INTO tasks (
        id, name, sub_name, repo, enabled, check_interval, cron_expr, include_prerelease,
        filter_mode, asset_filter_include, asset_filter_exclude, download_dir,
        auto_download, after_download_cmd, local_version, remote_version,
        last_checked_at, last_downloaded_at, status, status_message, created_at,
        release_notes, webhook_secret, auto_extract, tags
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        task_id,
        task_data.get("name", "未命名任务"),
        task_data.get("sub_name", "").strip(),
        task_data.get("repo", "").strip(),
        task_data.get("enabled", 1),
        task_data.get("check_interval", 60),
        task_data.get("cron_expr", ""),
        task_data.get("include_prerelease", 0),
        task_data.get("filter_mode", "keywords"),
        task_data.get("asset_filter_include", ""),
        task_data.get("asset_filter_exclude", "sha256,asc,sig,txt,sbom"),
        task_data.get("download_dir", "").strip(),
        task_data.get("auto_download", 1),
        task_data.get("after_download_cmd", "").strip(),
        task_data.get("local_version", ""),
        task_data.get("remote_version", ""),
        "",
        "",
        "idle",
        "等待首次检测",
        created_at,
        task_data.get("release_notes", ""),
        task_data.get("webhook_secret", ""),
        int(task_data.get("auto_extract", 0) or 0),
        str(task_data.get("tags", "")).strip()
    ))
    conn.commit()
    conn.close()
    ensure_persistent_auto_backup(force=True)
    return task_id

ALLOWED_TASK_FIELDS = {
    "name", "sub_name", "repo", "enabled", "check_interval", "cron_expr",
    "include_prerelease", "filter_mode", "asset_filter_include", "asset_filter_exclude",
    "download_dir", "auto_download", "after_download_cmd", "local_version",
    "remote_version", "last_checked_at", "last_downloaded_at", "status",
    "status_message", "release_notes", "webhook_secret", "auto_extract", "tags"
}

STRUCTURAL_TASK_FIELDS = {
    "name", "sub_name", "repo", "enabled", "check_interval", "cron_expr",
    "include_prerelease", "filter_mode", "asset_filter_include", "asset_filter_exclude",
    "download_dir", "auto_download", "after_download_cmd", "auto_extract", "tags", "webhook_secret"
}

def update_task(task_id: str, task_data: Dict[str, Any]):
    conn = get_connection()
    cursor = conn.cursor()
    
    fields = []
    values = []
    has_structural_change = False
    for k, v in task_data.items():
        if k != "id" and k in ALLOWED_TASK_FIELDS:
            fields.append(f"{k} = ?")
            values.append(v)
            if k in STRUCTURAL_TASK_FIELDS:
                has_structural_change = True
    
    if fields:
        values.append(task_id)
        sql = f"UPDATE tasks SET {', '.join(fields)} WHERE id = ?"
        cursor.execute(sql, tuple(values))
        conn.commit()
    conn.close()

    if has_structural_change:
        ensure_persistent_auto_backup()

def delete_task(task_id: str):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    cursor.execute("DELETE FROM history WHERE task_id = ?", (task_id,))
    conn.commit()
    conn.close()
    ensure_persistent_auto_backup(force=True)

def add_history_record(record: Dict[str, Any]):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO history (
        task_id, task_name, tag_name, file_name, file_size,
        save_path, download_time, duration, status, error_msg,
        release_notes, checksum_status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        record.get("task_id", ""),
        record.get("task_name", ""),
        record.get("tag_name", ""),
        record.get("file_name", ""),
        record.get("file_size", 0),
        record.get("save_path", ""),
        record.get("download_time", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        record.get("duration", 0),
        record.get("status", "success"),
        record.get("error_msg", ""),
        record.get("release_notes", ""),
        record.get("checksum_status", "none")
    ))
    conn.commit()
    conn.close()

def get_history(limit: int = 50) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM history ORDER BY download_time DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_history_item(history_id: int) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM history WHERE id = ?", (history_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def delete_history_item(history_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM history WHERE id = ?", (history_id,))
    conn.commit()
    conn.close()

def clear_history():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM history")
    conn.commit()
    conn.close()

def get_download_stats() -> Dict[str, Any]:
    conn = get_connection()
    cursor = conn.cursor()

    # 1. 累计总数与成功/失败
    cursor.execute("""
        SELECT 
            COUNT(*), 
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END), 
            SUM(CASE WHEN status != 'success' THEN 1 ELSE 0 END), 
            SUM(file_size) 
        FROM history
    """)
    row = cursor.fetchone()
    total = (row[0] or 0) if row else 0
    success = (row[1] or 0) if row else 0
    failed = (row[2] or 0) if row else 0
    total_bytes = (row[3] or 0) if row else 0

    success_rate = round((success / total * 100), 1) if total > 0 else 100.0

    # 2. 本周下载量 (从本周一 00:00:00 开始)
    now = datetime.now()
    week_start = (now - timedelta(days=now.weekday())).strftime("%Y-%m-%d 00:00:00")
    cursor.execute("SELECT COUNT(*) FROM history WHERE download_time >= ?", (week_start,))
    week_row = cursor.fetchone()
    week_count = (week_row[0] or 0) if week_row else 0

    # 3. 本月下载量 (从当月 1 日 00:00:00 开始)
    month_start = now.strftime("%Y-%m-01 00:00:00")
    cursor.execute("SELECT COUNT(*) FROM history WHERE download_time >= ?", (month_start,))
    month_row = cursor.fetchone()
    month_count = (month_row[0] or 0) if month_row else 0

    # 4. 最常下载软件排行 (Top 10)
    cursor.execute("""
        SELECT task_name, COUNT(*) as count, SUM(file_size) as total_size, MAX(download_time) as last_time
        FROM history
        WHERE task_name != ''
        GROUP BY task_name
        ORDER BY count DESC
        LIMIT 10
    """)
    top_rows = cursor.fetchall()
    top_downloaded = []
    for r in top_rows:
        top_downloaded.append({
            "name": r["task_name"],
            "count": r["count"],
            "total_size": r["total_size"] or 0,
            "last_time": r["last_time"] or ""
        })

    conn.close()
    return {
        "total_downloads": total,
        "success_downloads": success,
        "failed_downloads": failed,
        "success_rate": success_rate,
        "week_downloads": week_count,
        "month_downloads": month_count,
        "total_bytes": total_bytes,
        "top_downloaded": top_downloaded
    }

def backup_database(target_path: Optional[str] = None) -> str:
    """热备份 SQLite 数据库文件至指定路径或返回文件字节"""
    if not target_path:
        backup_dir = os.path.join(DATA_DIR, "backups")
        os.makedirs(backup_dir, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        target_path = os.path.join(backup_dir, f"gitrelease_watcher_{ts}.db")
    else:
        os.makedirs(os.path.dirname(os.path.abspath(target_path)), exist_ok=True)

    # 通过 SQLite VACUUM INTO 或安全连接导出快照
    src_conn = get_connection()
    try:
        # SQLite 3.27.0+ 支持 VACUUM INTO
        clean_target = os.path.abspath(target_path).replace("\\", "/")
        src_conn.execute(f"VACUUM INTO '{clean_target}'")
    except Exception:
        # 兼容备用方案：通过 sqlite3 备份 API
        bck_conn = sqlite3.connect(target_path)
        with bck_conn:
            src_conn.backup(bck_conn)
        bck_conn.close()
    finally:
        src_conn.close()

    # 顺便同步系统级持久备份
    ensure_persistent_auto_backup(force=True)
    return target_path

def restore_database(source_db_path: str, skip_auto_recover: bool = False) -> bool:
    """从备份 SQLite 数据库恢复并校验有效性"""
    if not os.path.exists(source_db_path):
        raise FileNotFoundError(f"备份数据库不存在: {source_db_path}")

    # 1. 验证目标文件是否为有效 SQLite 数据库
    chk_conn = sqlite3.connect(source_db_path)
    try:
        cur = chk_conn.cursor()
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cur.fetchall()]
        if "tasks" not in tables or "settings" not in tables:
            raise ValueError("提供的备份文件不包含有效的 tasks 或 settings 结构！")
    finally:
        chk_conn.close()

    # 2. 安全覆盖还原当前数据库
    dest_path = get_db_path()

    # 优先采用 SQLite backup API 安全跨连接同步覆盖还原当前数据库 (天然规避 Windows 文件锁与 WAL 脏读)
    backup_ok = False
    try:
        src_conn = sqlite3.connect(source_db_path)
        dest_conn = sqlite3.connect(dest_path)
        with dest_conn:
            src_conn.backup(dest_conn)
        dest_conn.close()
        src_conn.close()
        backup_ok = True
    except Exception:
        pass

    if not backup_ok:
        # 兼容降级方案: 文件物理替换
        temp_backup = dest_path + ".restore_prev"
        if os.path.exists(dest_path):
            try:
                shutil.copy2(dest_path, temp_backup)
            except Exception:
                pass

        try:
            wal_file = dest_path + "-wal"
            shm_file = dest_path + "-shm"
            for extra_f in (wal_file, shm_file):
                if os.path.exists(extra_f):
                    try:
                        os.remove(extra_f)
                    except Exception:
                        pass

            shutil.copy2(source_db_path, dest_path)
        except Exception as e:
            if os.path.exists(temp_backup):
                try:
                    shutil.copy2(temp_backup, dest_path)
                except Exception:
                    pass
            raise e

    # 验证还原后的数据库连接与完整性，避免递归
    init_db(skip_auto_recover=True)
    # 恢复成功后同步一份到持久化存储
    ensure_persistent_auto_backup(force=True)
    return True

