import os
import shutil
import asyncio
import time
import logging
import re
import hmac
from collections import deque
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks, Request, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from apscheduler.triggers.cron import CronTrigger

from backend.database import (
    init_db, get_tasks, get_task, create_task, update_task, delete_task,
    get_all_settings, update_settings, get_history, clear_history,
    get_history_item, delete_history_item, get_download_stats,
    backup_database, restore_database
)
from backend.scheduler import scheduler_instance
from backend.downloader import active_downloads, Downloader
from backend.github_client import GitHubClient
from backend.notifier import NotificationManager

app = FastAPI(title="GitRelease-Watcher", version="1.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def api_key_auth_middleware(request: Request, call_next):
    # 仅拦截 /api/ 开头的接口，静态资源与根路径放行
    if request.url.path.startswith("/api/"):
        # GitHub 官方 Webhook 与外部任务专属 Webhook 接口在此放行，由路由内部执行专属验签鉴权
        if request.url.path == "/api/webhook/github" or request.url.path.startswith("/api/webhook/trigger/"):
            return await call_next(request)

        settings = get_all_settings()
        if settings.get("api_key_enabled", "0") == "1":
            expected_key = settings.get("api_key", "").strip()
            if expected_key:
                provided_key = (
                    request.headers.get("X-API-Key")
                    or request.headers.get("x-api-key")
                    or request.query_params.get("api_key")
                    or ""
                ).strip()
                auth_header = request.headers.get("Authorization", "").strip()
                if not provided_key and auth_header.startswith("Bearer "):
                    provided_key = auth_header[7:].strip()

                # 采用 hmac.compare_digest 恒定时间比较，彻底杜绝侧信道时序攻击 (Timing Attack)
                if not hmac.compare_digest(provided_key, expected_key):
                    return JSONResponse(
                        status_code=401,
                        content={"status": "error", "message": "API Key 鉴权失败或未提供，拒绝访问"}
                    )
    return await call_next(request)

FRONTEND_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend"))

# 全局内存运行日志环形队列 (保留最近 1000 条)
system_logs = deque(maxlen=1000)

def log_event(level: str, module: str, message: str):
    now_str = time.strftime("%Y-%m-%d %H:%M:%S")
    system_logs.append({
        "id": int(time.time() * 1000),
        "time": now_str,
        "timestamp": now_str,
        "level": level.upper(),  # INFO, WARNING, ERROR, SUCCESS
        "module": module,
        "message": message
    })

class TaskModel(BaseModel):
    name: str
    sub_name: Optional[str] = ""
    repo: str
    enabled: Optional[int] = 1
    check_interval: Optional[int] = 60
    cron_expr: Optional[str] = ""
    include_prerelease: Optional[int] = 0
    filter_mode: Optional[str] = "keywords"
    asset_filter_include: Optional[str] = ""
    asset_filter_exclude: Optional[str] = "sha256,asc,sig,txt,sbom"
    download_dir: Optional[str] = ""
    auto_download: Optional[int] = 1
    after_download_cmd: Optional[str] = ""
    auto_extract: Optional[int] = 0
    tags: Optional[str] = ""

class TaskImportModel(BaseModel):
    tasks: List[Dict[str, Any]]
    conflict_mode: Optional[str] = "append" # append, skip, overwrite

class BatchTaskActionModel(BaseModel):
    task_ids: List[str]
    action: str  # check, enable, disable, delete, set_dir, force_download, download
    param: Optional[str] = ""
    download_dir: Optional[str] = ""

class FilterTestModel(BaseModel):
    repo: str
    include_prerelease: Optional[int] = 0
    filter_mode: Optional[str] = "keywords"
    asset_filter_include: Optional[str] = ""
    asset_filter_exclude: Optional[str] = "sha256,asc,sig,txt,sbom"
    download_dir: Optional[str] = ""
    task_name: Optional[str] = ""
    sub_name: Optional[str] = ""

class NotifyTestModel(BaseModel):
    channel: str # email, dingtalk, feishu, wechat, telegram, bark, discord, pushplus
    config: Dict[str, Any]

@app.on_event("startup")
async def startup_event():
    init_db()
    scheduler_instance.start()
    log_event("SUCCESS", "system", "GitRelease Watcher 后台核心调度引擎已成功启动")

@app.on_event("shutdown")
async def shutdown_event():
    scheduler_instance.stop()
    log_event("INFO", "system", "后台服务已安全退出")

# ----------------- 任务管理 API -----------------

@app.get("/api/tasks")
async def api_get_tasks():
    tasks = get_tasks()
    for task in tasks:
        tid = task["id"]
        if tid in active_downloads:
            task["active_download"] = active_downloads[tid]
        else:
            task["active_download"] = None
    return {"status": "ok", "data": tasks}

def clean_repo_string(repo: str) -> str:
    r = (repo or "").strip().strip("/")
    if "github.com/" in r:
        r = r.split("github.com/")[-1].strip("/")
    if r.endswith(".git"):
        r = r[:-4]
    parts = [p for p in r.split("/") if p]
    if len(parts) >= 2:
        r = f"{parts[0]}/{parts[1]}"
        if r.endswith(".git"):
            r = r[:-4]
    return r

def normalize_repo(repo: str) -> str:
    return clean_repo_string(repo).lower()

def normalize_filter_rule(mode: Optional[str], include_rule: Optional[str]) -> str:
    m = (mode or "keywords").strip().lower()
    rule = (include_rule or "").strip()
    if m == "keywords":
        parts = sorted([p.strip().lower() for p in rule.split(",") if p.strip()])
        return f"keywords:{','.join(parts)}"
    return f"regex:{rule.lower()}"

def validate_task_input(task_in: TaskModel) -> str:
    """对任务创建/更新的核心字段进行前置严格强校验，杜绝脏数据与非法Cron入库"""
    name = (task_in.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="软件名称不能为空")
    task_in.name = name

    raw_repo = (task_in.repo or "").strip()
    if not raw_repo:
        raise HTTPException(status_code=400, detail="GitHub 仓库地址不能为空")
    task_in.repo = clean_repo_string(raw_repo)
    clean_target_repo = normalize_repo(task_in.repo)
    if not re.match(r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$", clean_target_repo):
        raise HTTPException(
            status_code=400,
            detail=f"仓库格式无效: '{raw_repo}'，必须为标准的 'owner/repo' 格式 (例如 'syncthing/syncthing')"
        )

    if task_in.check_interval is not None and task_in.check_interval < 5:
        raise HTTPException(status_code=400, detail="检测轮询间隔不能低于 5 分钟")

    cron = (task_in.cron_expr or "").strip()
    if cron:
        try:
            CronTrigger.from_crontab(cron)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Cron 定时表达式语法错误: {e}")
        task_in.cron_expr = cron

    return clean_target_repo

@app.post("/api/tasks")
async def api_create_task(task_in: TaskModel, background_tasks: BackgroundTasks):
    clean_target_repo = validate_task_input(task_in)
    target_filter_sig = normalize_filter_rule(task_in.filter_mode, task_in.asset_filter_include)
    tasks = get_tasks()

    if not (task_in.sub_name or "").strip():
        # 用户未手动输入或未自定义修改，默认值为 智能识别标签 (如 Windows x64 便携版, Linux AMD64) 并保证同仓库下唯一
        detected = Downloader.detect_platform_and_arch(task_in.asset_filter_include)
        tag = detected.get("tag", "通用版")
        base_sub = tag if tag != "通用版" else f"{task_in.name}-通用版"

        candidate_sub = base_sub
        counter = 2
        while any(normalize_repo(t.get("repo", "")) == clean_target_repo and (t.get("sub_name") or "").strip().lower() == candidate_sub.lower() for t in tasks):
            candidate_sub = f"{base_sub}-{counter}"
            counter += 1
        task_in.sub_name = candidate_sub

    target_sub_name = task_in.sub_name.strip().lower()

    for t in tasks:
        if normalize_repo(t.get("repo", "")) == clean_target_repo:
            existing_sig = normalize_filter_rule(t.get("filter_mode"), t.get("asset_filter_include"))
            existing_sub_name = (t.get("sub_name") or "").strip().lower()

            # 标识别名唯一性检查（同仓库下必须唯一，不能重复）
            if target_sub_name and existing_sub_name and target_sub_name == existing_sub_name:
                raise HTTPException(
                    status_code=400,
                    detail=f"在仓库「{t.get('repo')}」下已存在标识别名为「{t.get('sub_name')}」的任务。该标识别名必须唯一，不能重复！"
                )

            # 资产过滤规则不能完全相同（避免重复下载相同文件）
            if existing_sig == target_filter_sig:
                raise HTTPException(
                    status_code=400,
                    detail=f"在仓库「{t.get('repo')}」下已存在资产过滤规则完全一致的任务「{t.get('name', '未命名')}」({t.get('sub_name', '')})。请区分包含规则或平台特征。"
                )

    task_data = task_in.dict()
    task_id = create_task(task_data)
    new_task = get_task(task_id)
    if new_task:
        scheduler_instance.add_or_update_job(new_task)
        # 添加任务后，立即在后台异步触发一次版本检测与本地已有文件识别 (免下载省流)
        background_tasks.add_task(scheduler_instance.execute_task_check, task_id, False)
    return {"status": "ok", "id": task_id, "message": "任务创建成功并已触发初始检测"}

@app.put("/api/tasks/{task_id}")
async def api_update_task(task_id: str, task_in: TaskModel):
    existing = get_task(task_id)
    if not existing:
        raise HTTPException(status_code=404, detail="任务不存在")

    clean_target_repo = validate_task_input(task_in)
    target_filter_sig = normalize_filter_rule(task_in.filter_mode, task_in.asset_filter_include)
    tasks = get_tasks()

    if not (task_in.sub_name or "").strip():
        detected = Downloader.detect_platform_and_arch(task_in.asset_filter_include)
        tag = detected.get("tag", "通用版")
        base_sub = tag if tag != "通用版" else f"{task_in.name}-通用版"

        candidate_sub = base_sub
        counter = 2
        while any(t.get("id") != task_id and normalize_repo(t.get("repo", "")) == clean_target_repo and (t.get("sub_name") or "").strip().lower() == candidate_sub.lower() for t in tasks):
            candidate_sub = f"{base_sub}-{counter}"
            counter += 1
        task_in.sub_name = candidate_sub

    target_sub_name = task_in.sub_name.strip().lower()

    for t in tasks:
        if t.get("id") != task_id and normalize_repo(t.get("repo", "")) == clean_target_repo:
            existing_sig = normalize_filter_rule(t.get("filter_mode"), t.get("asset_filter_include"))
            existing_sub_name = (t.get("sub_name") or "").strip().lower()

            # 标识别名唯一性检查
            if target_sub_name and existing_sub_name and target_sub_name == existing_sub_name:
                raise HTTPException(
                    status_code=400,
                    detail=f"在仓库「{t.get('repo')}」下已存在标识别名为「{t.get('sub_name')}」的任务。该标识别名必须唯一，不能重复！"
                )

            # 资产过滤规则检查
            if existing_sig == target_filter_sig:
                raise HTTPException(
                    status_code=400,
                    detail=f"在仓库「{t.get('repo')}」下已存在资产过滤规则完全一致的任务「{t.get('name', '未命名')}」({t.get('sub_name', '')})。请区分包含规则或平台特征。"
                )

    task_data = task_in.dict()
    update_task(task_id, task_data)
    updated = get_task(task_id)
    if updated:
        scheduler_instance.add_or_update_job(updated)
    return {"status": "ok", "message": "任务更新成功"}

@app.delete("/api/tasks/{task_id}")
async def api_delete_task(task_id: str):
    scheduler_instance.remove_job(task_id)
    active_downloads.pop(task_id, None)
    delete_task(task_id)
    return {"status": "ok", "message": "任务已删除"}

@app.post("/api/tasks/{task_id}/toggle")
async def api_toggle_task(task_id: str):
    task = get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    new_status = 0 if task.get("enabled") else 1
    update_task(task_id, {"enabled": new_status})
    updated = get_task(task_id)
    if updated:
        scheduler_instance.add_or_update_job(updated)
    return {"status": "ok", "enabled": new_status}

@app.post("/api/tasks/{task_id}/check")
async def api_check_task(task_id: str, background_tasks: BackgroundTasks):
    task = get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    if task_id in active_downloads:
        return {"status": "warning", "message": "该任务当前正在下载中，无需重复触发检测"}
    background_tasks.add_task(scheduler_instance.execute_task_check, task_id, False)
    return {"status": "ok", "message": "已触发即时版本检测"}

@app.post("/api/tasks/{task_id}/download")
async def api_force_download(task_id: str, background_tasks: BackgroundTasks):
    task = get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="任务不存在")
    background_tasks.add_task(scheduler_instance.execute_task_check, task_id, True)
    return {"status": "ok", "message": "已触发强制重新下载"}

# ----------------- 批量任务管理 API -----------------

@app.post("/api/tasks/batch")
async def api_batch_tasks(body: BatchTaskActionModel, background_tasks: BackgroundTasks):
    task_ids = body.task_ids
    action = body.action
    param = (body.download_dir or body.param or "").strip()

    if not task_ids:
        raise HTTPException(status_code=400, detail="未提供任何任务 ID")

    count = 0
    if action == "enable":
        for tid in task_ids:
            update_task(tid, {"enabled": 1})
            updated = get_task(tid)
            if updated:
                scheduler_instance.add_or_update_job(updated)
            count += 1
        log_event("SUCCESS", "batch", f"批量启用 {count} 个监控任务")
        return {"status": "ok", "message": f"成功批量启用 {count} 个任务"}

    elif action == "disable":
        for tid in task_ids:
            update_task(tid, {"enabled": 0})
            scheduler_instance.remove_job(tid)
            count += 1
        log_event("INFO", "batch", f"批量暂停 {count} 个监控任务")
        return {"status": "ok", "message": f"成功批量暂停 {count} 个任务"}

    elif action == "delete":
        for tid in task_ids:
            scheduler_instance.remove_job(tid)
            active_downloads.pop(tid, None)
            delete_task(tid)
            count += 1
        log_event("WARNING", "batch", f"批量删除 {count} 个监控任务")
        return {"status": "ok", "message": f"成功批量删除 {count} 个任务"}

    elif action == "set_dir":
        for tid in task_ids:
            update_task(tid, {"download_dir": param})
            count += 1
        log_event("SUCCESS", "batch", f"批量修改 {count} 个任务存储路径为: {param}")
        return {"status": "ok", "message": f"成功批量更新 {count} 个任务的存放目录"}

    elif action == "check":
        for tid in task_ids:
            if tid not in active_downloads:
                background_tasks.add_task(scheduler_instance.execute_task_check, tid, False)
                count += 1
        log_event("INFO", "batch", f"批量触发 {count} 个任务的即时版本检测")
        return {"status": "ok", "message": f"已后台触发 {count} 个任务联网检测"}

    elif action in ("force_download", "download"):
        for tid in task_ids:
            background_tasks.add_task(scheduler_instance.execute_task_check, tid, True)
            count += 1
        log_event("INFO", "batch", f"批量触发 {count} 个任务强制重新下载")
        return {"status": "ok", "message": f"已后台触发 {count} 个任务重新拉取下载"}

    else:
        raise HTTPException(status_code=400, detail=f"不支持的批量操作类型: {action}")

# ----------------- 系统运行实时日志 API -----------------

@app.get("/api/logs")
async def api_get_logs(limit: int = 200, level: Optional[str] = "all", search: Optional[str] = ""):
    safe_limit = max(1, min(int(limit), 1000))
    logs = list(system_logs)
    if level and level != "all":
        logs = [l for l in logs if l["level"].lower() == level.lower()]
    if search:
        s = search.lower().strip()
        logs = [l for l in logs if s in l["message"].lower() or s in l["module"].lower()]
    return {"status": "ok", "data": logs[-safe_limit:], "total": len(system_logs)}

@app.delete("/api/logs")
async def api_clear_logs():
    system_logs.clear()
    log_event("INFO", "system", "系统运行日志已被清空")
    return {"status": "ok", "message": "日志已清空"}

@app.post("/api/tasks/check_all")
async def api_check_all(background_tasks: BackgroundTasks):
    tasks = get_tasks()
    count = 0
    for task in tasks:
        if task.get("enabled"):
            background_tasks.add_task(scheduler_instance.execute_task_check, task["id"], False)
            count += 1
    return {"status": "ok", "message": f"已对 {count} 个启用任务派发检测任务"}

# ----------------- 任务清单批量导出与导入 API -----------------

@app.get("/api/tasks/export")
async def api_export_tasks(download: bool = False):
    tasks = get_tasks()
    clean_tasks = []
    export_fields = [
        "name", "sub_name", "repo", "enabled", "check_interval", "cron_expr",
        "include_prerelease", "filter_mode", "asset_filter_include", "asset_filter_exclude",
        "download_dir", "auto_download", "after_download_cmd", "auto_extract", "tags"
    ]
    for t in tasks:
        item = {}
        for f in export_fields:
            if f in t:
                item[f] = t[f]
        clean_tasks.append(item)

    export_data = {
        "version": "1.0",
        "generator": "GitRelease-Watcher",
        "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "count": len(clean_tasks),
        "tasks": clean_tasks
    }

    if download:
        filename = f"gitrelease_tasks_{time.strftime('%Y%m%d_%H%M%S')}.json"
        return JSONResponse(
            content=export_data,
            headers={
                "Content-Disposition": f"attachment; filename={filename}"
            }
        )
    return {"status": "ok", "data": export_data}

@app.post("/api/tasks/import")
async def api_import_tasks(import_in: TaskImportModel, background_tasks: BackgroundTasks):
    tasks_to_import = import_in.tasks
    conflict_mode = (import_in.conflict_mode or "append").strip().lower()
    
    if not tasks_to_import or not isinstance(tasks_to_import, list):
        raise HTTPException(status_code=400, detail="导入的任务列表为空或格式无效")

    existing_tasks = get_tasks()
    added_count = 0
    updated_count = 0
    skipped_count = 0
    errors = []

    for idx, item in enumerate(tasks_to_import):
        name = str(item.get("name", "")).strip()
        repo = str(item.get("repo", "")).strip()
        if not name or not repo:
            errors.append(f"第 {idx+1} 项缺少软件名称或仓库地址，已跳过")
            skipped_count += 1
            continue

        clean_repo = normalize_repo(repo)
        raw_sub_name = str(item.get("sub_name", "")).strip()
        include_rule = str(item.get("asset_filter_include", "")).strip()

        # 默认别名推导 (软件名+{platform})
        if not raw_sub_name:
            detected = Downloader.detect_platform_and_arch(include_rule)
            plat = detected.get("platform", "Other")
            arch = detected.get("arch", "common")
            plat_str = f"{plat} {arch}" if arch and arch != "common" and plat not in ("Other", "Common") else (plat if plat not in ("Other", "Common") else "通用版")
            raw_sub_name = f"{name}-{plat_str}"

        # 检查是否已存在冲突任务 (同一 repo 下相同 sub_name)
        matched_existing = None
        for et in existing_tasks:
            if normalize_repo(et.get("repo", "")) == clean_repo and (et.get("sub_name") or "").strip().lower() == raw_sub_name.lower():
                matched_existing = et
                break

        if matched_existing:
            if conflict_mode == "skip":
                skipped_count += 1
                continue
            elif conflict_mode == "overwrite":
                task_data = {
                    "name": name,
                    "sub_name": raw_sub_name,
                    "repo": repo,
                    "enabled": int(item.get("enabled", 1)),
                    "check_interval": int(item.get("check_interval", 60)),
                    "cron_expr": str(item.get("cron_expr", "")),
                    "include_prerelease": int(item.get("include_prerelease", 0)),
                    "filter_mode": str(item.get("filter_mode", "keywords")),
                    "asset_filter_include": include_rule,
                    "asset_filter_exclude": str(item.get("asset_filter_exclude", "sha256,asc,sig,txt,sbom")),
                    "download_dir": str(item.get("download_dir", "")),
                    "auto_download": int(item.get("auto_download", 1)),
                    "after_download_cmd": str(item.get("after_download_cmd", "")),
                    "auto_extract": int(item.get("auto_extract", 0)),
                    "tags": str(item.get("tags", ""))
                }
                update_task(matched_existing["id"], task_data)
                upd = get_task(matched_existing["id"])
                if upd:
                    scheduler_instance.add_or_update_job(upd)
                updated_count += 1
                continue
            else: # append: 自动重命名递增后缀保证唯一共存
                candidate_sub = raw_sub_name
                counter = 2
                while any(normalize_repo(et.get("repo", "")) == clean_repo and (et.get("sub_name") or "").strip().lower() == candidate_sub.lower() for et in existing_tasks):
                    candidate_sub = f"{raw_sub_name}-{counter}"
                    counter += 1
                raw_sub_name = candidate_sub

        # 创建新任务
        new_task_data = {
            "name": name,
            "sub_name": raw_sub_name,
            "repo": repo,
            "enabled": int(item.get("enabled", 1)),
            "check_interval": int(item.get("check_interval", 60)),
            "cron_expr": str(item.get("cron_expr", "")),
            "include_prerelease": int(item.get("include_prerelease", 0)),
            "filter_mode": str(item.get("filter_mode", "keywords")),
            "asset_filter_include": include_rule,
            "asset_filter_exclude": str(item.get("asset_filter_exclude", "sha256,asc,sig,txt,sbom")),
            "download_dir": str(item.get("download_dir", "")),
            "auto_download": int(item.get("auto_download", 1)),
            "after_download_cmd": str(item.get("after_download_cmd", "")),
            "auto_extract": int(item.get("auto_extract", 0)),
            "tags": str(item.get("tags", ""))
        }
        new_id = create_task(new_task_data)
        new_t = get_task(new_id)
        if new_t:
            existing_tasks.append(new_t)
            scheduler_instance.add_or_update_job(new_t)
            background_tasks.add_task(scheduler_instance.execute_task_check, new_id, False)
        added_count += 1

    return {
        "status": "ok",
        "message": f"成功导入任务: 新增 {added_count} 个，更新 {updated_count} 个，跳过 {skipped_count} 个",
        "added": added_count,
        "updated": updated_count,
        "skipped": skipped_count,
        "errors": errors
    }

# ----------------- GitHub Webhook 反向推送 API -----------------

@app.post("/api/webhook/github")
async def api_github_webhook(request: Request, background_tasks: BackgroundTasks):
    """
    接收来自 GitHub 官方 Webhook 的事件推送 (如 release published)
    实现 0 秒即时感知发布并自动触发下载，无需等待周期轮询
    """
    settings = get_all_settings()
    if settings.get("webhook_enabled", "1") != "1":
        return JSONResponse(status_code=403, content={"status": "error", "message": "WebHook 接收功能已被管理员关闭"})

    configured_token = settings.get("webhook_token", "").strip()
    auth_header = request.headers.get("X-Hub-Token", "") or request.headers.get("X-GitRelease-Token", "")
    token_param = request.query_params.get("token", "")
    if configured_token:
        if auth_header != configured_token and token_param != configured_token:
            return JSONResponse(status_code=401, content={"status": "error", "message": "WebHook Token 鉴权失败，请检查传入 Token"})

    try:
        payload = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"status": "error", "message": "无效的 JSON 数据体"})

    repo_full_name = payload.get("repository", {}).get("full_name", "")
    if not repo_full_name:
        return {"status": "ignored", "message": "未在请求中解析到 repository.full_name"}

    norm_target = normalize_repo(repo_full_name)
    tasks = get_tasks()
    matched_tasks = [t for t in tasks if normalize_repo(t.get("repo", "")) == norm_target and t.get("enabled", 1)]

    if not matched_tasks:
        return {"status": "ok", "message": f"已收到推送，但未匹配到本地已启用的仓库任务: {repo_full_name}"}

    for t in matched_tasks:
        background_tasks.add_task(scheduler_instance.execute_task_check, t["id"], False)

    return {
        "status": "ok",
        "message": f"成功命中 {len(matched_tasks)} 个本地监控任务，已触发 0 秒即时下载",
        "matched_tasks": [t["name"] for t in matched_tasks]
    }

@app.post("/api/webhook/trigger/{task_id}")
async def api_webhook_trigger_task(task_id: str, background_tasks: BackgroundTasks, request: Request):
    """
    外部自动化 / CI-CD 专用触发接口，支持外部系统触发指定任务立即执行检查更新
    支持使用任务专属 webhook_secret 或全局 API Key 进行安全校验
    """
    task = get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="指定的监控任务不存在")

    settings = get_all_settings()
    task_secret = (task.get("webhook_secret") or "").strip()
    api_key_enabled = settings.get("api_key_enabled", "0") == "1"
    global_api_key = settings.get("api_key", "").strip()

    provided_token = (
        request.headers.get("X-Webhook-Secret")
        or request.headers.get("X-Hub-Token")
        or request.headers.get("X-GitRelease-Token")
        or request.headers.get("X-API-Key")
        or request.headers.get("x-api-key")
        or request.query_params.get("token")
        or request.query_params.get("api_key")
        or ""
    ).strip()
    auth_header = request.headers.get("Authorization", "").strip()
    if not provided_token and auth_header.startswith("Bearer "):
        provided_token = auth_header[7:].strip()

    if task_secret:
        if not hmac.compare_digest(provided_token, task_secret):
            return JSONResponse(status_code=401, content={"status": "error", "message": "任务专属 Webhook Secret 鉴权失败"})
    elif api_key_enabled and global_api_key:
        if not hmac.compare_digest(provided_token, global_api_key):
            return JSONResponse(status_code=401, content={"status": "error", "message": "系统全局 API Key 鉴权失败"})

    background_tasks.add_task(scheduler_instance.execute_task_check, task_id, False)
    log_event("INFO", "webhook", f"外部 Webhook 成功触发任务 [{task.get('name')}] 即时检测")
    return {
        "status": "ok",
        "message": f"任务 [{task.get('name')}] 即时检测已触发",
        "task_id": task_id
    }

# ----------------- 规则测试 API -----------------

@app.post("/api/test_filter")
async def api_test_filter(test_in: FilterTestModel):
    settings = get_all_settings()
    token = settings.get("github_token", "")
    http_proxy = settings.get("http_proxy", "") if settings.get("proxy_mode") == "http_proxy" else ""
    default_dir = settings.get("default_download_dir", "/www/zfile/dow")

    gh_client = GitHubClient(token=token, proxy_url=http_proxy)
    try:
        release = await gh_client.get_latest_release(test_in.repo, bool(test_in.include_prerelease))
        assets = release.get("assets", [])
        matched = gh_client.match_assets(
            assets=assets,
            filter_mode=test_in.filter_mode or "keywords",
            include_rule=test_in.asset_filter_include or "",
            exclude_rule=test_in.asset_filter_exclude or ""
        )
        tag = release.get("tag_name", "")
        fake_task = {
            "name": test_in.task_name or "app",
            "sub_name": test_in.sub_name or "",
            "repo": test_in.repo
        }

        matched_assets_data = []
        for a in matched:
            fn = a["name"]
            expected_sz = int(a.get("size", 0))
            target_dir = Downloader.resolve_target_dir(
                test_in.download_dir or "",
                default_dir,
                fake_task,
                tag,
                file_name=fn
            )
            local_path = os.path.join(target_dir, fn)
            local_exists = os.path.exists(local_path)
            local_sz = os.path.getsize(local_path) if local_exists else 0
            size_matches = bool(local_exists and expected_sz > 0 and local_sz == expected_sz)

            matched_assets_data.append({
                "name": fn,
                "size": expected_sz,
                "download_url": a["browser_download_url"],
                "target_dir": target_dir,
                "local_path": local_path,
                "local_exists": local_exists,
                "local_size": local_sz,
                "local_size_matches": size_matches
            })

        return {
            "status": "ok",
            "tag_name": tag,
            "release_name": release.get("name"),
            "published_at": release.get("published_at"),
            "total_assets_count": len(assets),
            "matched_count": len(matched),
            "matched_assets": matched_assets_data,
            "all_assets": [
                {"name": a["name"], "size": a["size"]}
                for a in assets
            ]
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

# ----------------- 通知测试 API -----------------

@app.post("/api/notify/test")
async def api_test_notify(test_data: NotifyTestModel):
    channel = test_data.channel
    cfg = test_data.config
    device = cfg.get("device_name", "Linux-01")
    notifier = NotificationManager(cfg)

    test_title = f"[{device}] GitRelease Watcher 通知测试"
    test_content = f"恭喜！您在设备 [{device}] 上配置的通知服务已正常连通！\n发送渠道: {channel}\n测试时间: {time.strftime('%Y-%m-%d %H:%M:%S')}"

    try:
        if channel == "email":
            ok = await notifier.send_email(test_title, test_content)
            if not ok:
                raise RuntimeError("邮件发送失败，请检查 SMTP 服务器、端口、发件人及授权码配置")
        elif channel == "dingtalk":
            ok = await notifier.send_dingtalk(test_title, test_content)
            if not ok:
                raise RuntimeError("钉钉推送失败，请检查 Webhook 机器人地址或安全设置")
        elif channel == "feishu":
            ok = await notifier.send_feishu(test_title, test_content)
            if not ok:
                raise RuntimeError("飞书推送失败，请检查 Webhook 机器人地址或自定义关键字")
        elif channel == "wechat":
            ok = await notifier.send_wechat(test_title, test_content)
            if not ok:
                raise RuntimeError("企业微信推送失败，请检查 Webhook 机器人地址")
        elif channel == "telegram":
            ok = await notifier.send_telegram(test_title, test_content, check_enabled=False)
            if not ok:
                raise RuntimeError("Telegram 推送失败，请检查 Bot Token 与 Chat ID 是否已填写且格式正确")
        elif channel == "bark":
            ok = await notifier.send_bark(test_title, test_content, check_enabled=False)
            if not ok:
                raise RuntimeError("Bark 推送失败，请检查专属 Device Key 是否已填写")
        elif channel == "discord":
            ok = await notifier.send_discord(test_title, test_content, check_enabled=False)
            if not ok:
                raise RuntimeError("Discord 推送失败，请检查 Webhook URL 是否已正确填写")
        elif channel == "pushplus":
            ok = await notifier.send_pushplus(test_title, test_content, check_enabled=False)
            if not ok:
                raise RuntimeError("PushPlus 推送失败，请检查 Token 是否已正确填写")
        else:
            raise ValueError(f"未知通知渠道: {channel}")

        return {"status": "ok", "message": f"{channel} 测试通知发送成功，请查收！"}
    except Exception as e:
        return {"status": "error", "message": f"发送失败: {str(e)}"}

# ----------------- 全局设置 API -----------------

@app.get("/api/settings")
async def api_get_settings():
    return {"status": "ok", "data": get_all_settings()}

@app.post("/api/settings")
async def api_update_settings(settings: Dict[str, Any]):
    update_settings(settings)
    return {"status": "ok", "message": "配置更新成功"}

# ----------------- 数据库备份与恢复 API -----------------

@app.get("/api/database/backup")
async def api_backup_database():
    """导出当前系统完整的 SQLite 数据库快照"""
    import tempfile
    from starlette.background import BackgroundTask
    temp_dir = tempfile.gettempdir()
    backup_filename = f"gitrelease_backup_{time.strftime('%Y%m%d_%H%M%S')}.db"
    backup_path = os.path.join(temp_dir, backup_filename)
    saved_path = backup_database(backup_path)
    if not saved_path or not os.path.exists(backup_path):
        raise HTTPException(status_code=500, detail="数据库快照备份失败，请检查存储权限")
    return FileResponse(
        path=backup_path,
        filename=backup_filename,
        media_type="application/octet-stream",
        background=BackgroundTask(os.remove, backup_path)
    )

@app.post("/api/database/restore")
async def api_restore_database(file: UploadFile = File(...)):
    """上传 SQLite 数据库快照并进行安全恢复验证与热重载"""
    if not file.filename or not file.filename.endswith(".db"):
        raise HTTPException(status_code=400, detail="上传文件必须是 .db 格式的 SQLite 数据库备份")
    safe_name = os.path.basename(file.filename.replace("\\", "/"))
    if not safe_name.endswith(".db"):
        raise HTTPException(status_code=400, detail="无效的数据库备份文件名")
    import tempfile
    temp_dir = tempfile.gettempdir()
    temp_path = os.path.join(temp_dir, f"restore_{int(time.time())}_{safe_name}")
    with open(temp_path, "wb") as f:
        content = await file.read()
        f.write(content)

    try:
        success = restore_database(temp_path)
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass

    if not success:
        raise HTTPException(status_code=400, detail="数据库恢复失败，文件可能已损坏或非有效的 GitRelease 备份文件")

    # 重新载入调度任务以与新数据库保持同步
    scheduler_instance.reload_all_tasks()
    log_event("SUCCESS", "system", f"数据库已通过快照 [{safe_name}] 成功还原，所有调度任务已同步重置")
    return {"status": "ok", "message": "数据库已成功还原，所有调度任务已同步就绪"}

# ----------------- 下载历史、统计与本地离线文件管理 API -----------------

@app.get("/api/stats")
async def api_get_download_stats():
    stats = get_download_stats()
    return {"status": "ok", "data": stats}

@app.get("/api/history")
async def api_get_history(limit: int = 150):
    safe_limit = max(1, min(int(limit), 1000))
    records = get_history(safe_limit)
    for r in records:
        save_path = r.get("save_path", "")
        r["file_exists"] = bool(save_path and os.path.isfile(save_path))
    return {"status": "ok", "data": records}

@app.get("/api/history/{history_id}/download")
async def api_download_history_file(history_id: int):
    item = get_history_item(history_id)
    if not item:
        raise HTTPException(status_code=404, detail="下载历史记录不存在")
    file_path = item.get("save_path", "")
    if not file_path or not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail="本地安装包文件不存在，可能已被历史轮换清理或移走")
    filename = item.get("file_name") or os.path.basename(file_path)
    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/octet-stream"
    )

@app.delete("/api/history/{history_id}")
async def api_delete_history_item(history_id: int, delete_file: bool = False):
    item = get_history_item(history_id)
    if not item:
        raise HTTPException(status_code=404, detail="历史记录不存在")
    if delete_file:
        file_path = item.get("save_path", "")
        if file_path and os.path.isfile(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"删除物理文件失败: {e}")
    delete_history_item(history_id)
    return {"status": "ok", "message": "记录及物理文件已处理"}

@app.delete("/api/history")
async def api_clear_history(delete_files: bool = False):
    if delete_files:
        records = get_history(500)
        for r in records:
            p = r.get("save_path", "")
            if p and os.path.isfile(p):
                try:
                    os.remove(p)
                except Exception:
                    pass
    clear_history()
    return {"status": "ok", "message": "历史记录已清空"}

def calc_disk_usage(raw_path: str) -> Dict[str, Any]:
    """多级智能寻址与容错的磁盘容量计算"""
    clean_p = (raw_path or "").strip()
    if "{" in clean_p:
        clean_p = clean_p.split("{")[0].rstrip("/\\")

    curr = os.path.abspath(os.path.expanduser(clean_p)) if clean_p else os.path.abspath(".")
    while curr and not os.path.exists(curr):
        parent = os.path.dirname(curr)
        if parent == curr:
            break
        curr = parent

    candidate_paths = [curr, os.path.abspath("."), os.path.abspath(os.sep)]
    for p in candidate_paths:
        if not p or not os.path.exists(p):
            continue
        try:
            total, used, free = shutil.disk_usage(p)
            pct = round((used / total) * 100, 1) if total > 0 else 0.0
            return {
                "total_gb": round(total / (1024**3), 2),
                "free_gb": round(free / (1024**3), 2),
                "used_gb": round(used / (1024**3), 2),
                "percent": pct,
                "path": p
            }
        except Exception:
            continue

    return {
        "total_gb": 0.0,
        "free_gb": 0.0,
        "used_gb": 0.0,
        "percent": 0.0,
        "path": "unknown"
    }

@app.get("/api/system_info")
async def api_get_system_info():
    settings = get_all_settings()
    default_dir = settings.get("default_download_dir", "/www/zfile/dow")
    disk_info = calc_disk_usage(default_dir)

    return {
        "status": "ok",
        "device_name": settings.get("device_name", "Linux-01"),
        "panel_title": settings.get("panel_title", "Github定时下载器"),
        "panel_subtitle": settings.get("panel_subtitle", "GitHub 升级自动监测与多设备下载"),
        "custom_download_dirs": settings.get("custom_download_dirs", ""),
        "custom_include_tags": settings.get("custom_include_tags", ""),
        "custom_exclude_tags": settings.get("custom_exclude_tags", ""),
        "default_dir": default_dir,
        "disk": disk_info,
        "active_downloads_count": len(active_downloads)
    }

# ----------------- 静态前端托管 -----------------

if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

@app.get("/")
async def serve_index():
    index_file = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_file):
        return FileResponse(index_file)
    return JSONResponse({"message": "GitRelease-Watcher 服务已就绪，前端静态文件准备中..."})
