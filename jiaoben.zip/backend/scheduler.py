import os
import asyncio
import time
from typing import Dict, Any, Optional
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger

from backend.database import get_tasks, get_task, update_task, get_all_settings
from backend.github_client import GitHubClient
from backend.downloader import Downloader, active_downloads
from backend.notifier import NotificationManager

class TaskScheduler:
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.is_running = False
        self.job_prefix = "task_job_"
        self._download_semaphore: Optional[asyncio.Semaphore] = None
        self._retry_counts: Dict[str, int] = {}  # task_id -> 当前重试次数 (最多3次)

    def get_download_semaphore(self) -> asyncio.Semaphore:
        settings = get_all_settings()
        limit = int(settings.get("max_concurrent_downloads", "3") or "3")
        if limit <= 0:
            limit = 3
        if self._download_semaphore is None or getattr(self, "_last_limit", None) != limit:
            self._download_semaphore = asyncio.Semaphore(limit)
            self._last_limit = limit
        return self._download_semaphore

    def start(self):
        if not self.is_running:
            self.scheduler.start()
            self.is_running = True
            self.reload_all_tasks()

    def stop(self):
        if self.is_running:
            self.scheduler.shutdown(wait=False)
            self.is_running = False

    def reload_all_tasks(self):
        self.scheduler.remove_all_jobs()
        tasks = get_tasks()
        for task in tasks:
            if task.get("enabled"):
                self.add_or_update_job(task)

    def add_or_update_job(self, task: Dict[str, Any]):
        job_id = f"{self.job_prefix}{task['id']}"
        if self.scheduler.get_job(job_id):
            self.scheduler.remove_job(job_id)

        if not task.get("enabled"):
            return

        interval_minutes = task.get("check_interval", 60)
        cron_expr = task.get("cron_expr", "").strip()

        if cron_expr:
            try:
                trigger = CronTrigger.from_crontab(cron_expr)
                self.scheduler.add_job(
                    self.execute_task_check,
                    trigger=trigger,
                    id=job_id,
                    args=[task["id"], False],
                    replace_existing=True
                )
                return
            except Exception as e:
                print(f"[Scheduler] Cron 语法解析异常 ({cron_expr}): {e}，回退为间隔分钟调度")

        interval_minutes = max(5, int(interval_minutes)) if interval_minutes else 60
        trigger = IntervalTrigger(minutes=interval_minutes)
        self.scheduler.add_job(
            self.execute_task_check,
            trigger=trigger,
            id=job_id,
            args=[task["id"], False],
            replace_existing=True
        )

    def remove_job(self, task_id: str):
        job_id = f"{self.job_prefix}{task_id}"
        if self.scheduler.get_job(job_id):
            self.scheduler.remove_job(job_id)

    async def execute_task_check(self, task_id: str, force_download: bool = False):
        task = get_task(task_id)
        if not task:
            return

        # 防重入保护：若该任务当前正处于实际下载传输中，避免并发重复检测或覆盖状态
        if task_id in active_downloads and not force_download:
            print(f"[Scheduler] 任务 {task_id} 正在下载传输中，跳过重复检测")
            return

        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        update_task(task_id, {
            "status": "checking",
            "status_message": "正在连接 GitHub 校验最新版本...",
            "last_checked_at": now_str
        })

        settings = get_all_settings()
        token = settings.get("github_token", "")
        proxy_mode = settings.get("proxy_mode", "mirror")
        mirror_prefix = settings.get("mirror_prefix", "https://ghproxy.net/")
        http_proxy = settings.get("http_proxy", "")
        default_dir = settings.get("default_download_dir", "/www/zfile/dow")

        gh_client = GitHubClient(
            token=token,
            proxy_url=http_proxy if (proxy_mode == "http_proxy" and http_proxy) else ""
        )
        notifier = NotificationManager(settings)

        try:
            # 1. 获取最新 Release
            release = await gh_client.get_latest_release(
                repo=task["repo"],
                include_prerelease=bool(task.get("include_prerelease", 0))
            )
            remote_tag = release.get("tag_name", "")
            assets = release.get("assets", [])
            release_notes = release.get("body", "").strip()

            # 2. 版本比对
            need_upgrade = gh_client.check_version_upgrade(task.get("local_version", ""), remote_tag)
            
            update_task(task_id, {
                "remote_version": remote_tag,
                "release_notes": release_notes,
                "last_checked_at": now_str
            })

            if not need_upgrade and not force_download:
                update_task(task_id, {
                    "status": "idle",
                    "status_message": f"已是最新版本 ({remote_tag})"
                })
                return

            # 3. 筛选资产文件
            matched_assets = gh_client.match_assets(
                assets=assets,
                filter_mode=task.get("filter_mode", "keywords"),
                include_rule=task.get("asset_filter_include", ""),
                exclude_rule=task.get("asset_filter_exclude", "sha256,asc,sig,txt,sbom")
            )

            if not matched_assets:
                update_task(task_id, {
                    "status": "warning",
                    "status_message": f"检测到新版 {remote_tag}，但未筛选到匹配架构的安装包 (共 {len(assets)} 个文件)"
                })
                return

            target_asset = matched_assets[0]

            downloader = Downloader(
                proxy_mode=proxy_mode,
                mirror_prefix=mirror_prefix,
                mirror_fallback_list=settings.get("mirror_fallback_list", ""),
                http_proxy=http_proxy
            )

            # 4. 判断是否自动下载（若处于手动模式，但本地已有同名同体积文件则自动免下载同步）
            if not task.get("auto_download", 1) and not force_download:
                target_dir = downloader.resolve_target_dir(
                    task.get("download_dir", ""),
                    default_dir,
                    task,
                    remote_tag,
                    file_name=target_asset["name"]
                )
                local_fpath = os.path.join(target_dir, target_asset["name"])
                if os.path.exists(local_fpath) and target_asset.get("size") and os.path.getsize(local_fpath) == target_asset["size"]:
                    # 本地已存在该文件，直接执行免下载同步，无需让用户手动再点一次下载
                    await downloader.download_file(
                        task=task,
                        asset=target_asset,
                        tag=remote_tag,
                        default_download_dir=default_dir,
                        all_assets=assets,
                        release_notes=release_notes,
                        force_download=False
                    )
                    return

                update_task(task_id, {
                    "status": "pending_download",
                    "status_message": f"发现新版本 {remote_tag} ({target_asset['name']})，等待手动下载"
                })
                # 触发新版本发现通知
                notes_snippet = f"\n\n### 📝 更新日志摘要:\n{release_notes[:300]}..." if release_notes else ""
                asyncio.create_task(notifier.send_notification(
                    event_type="upgrade_found",
                    title=f"发现软件升级: {task['name']} {remote_tag}",
                    content=f"检测到 GitHub 线上发布了新版本 `{remote_tag}`，目标安装包: `{target_asset['name']}`。\n当前处于手动模式，请前往面板确认下载。{notes_snippet}",
                    task_info={
                        "name": task["name"],
                        "repo": task["repo"],
                        "version": remote_tag
                    }
                ))
                return

            # 5. 触发下载流程 (通过信号量管控最大并发数，避免多任务同时打满带宽或磁盘)
            sem = self.get_download_semaphore()
            async with sem:
                download_count = 0
                for target_asset in matched_assets:
                    # 防御性校验：避免多资源下载期间任务被删除或配置被修改
                    current_task = get_task(task_id)
                    if not current_task:
                        print(f"[Scheduler] 任务 {task_id} 在下载过程中被移除，终止后续资源拉取")
                        break

                    update_task(task_id, {
                        "status": "downloading",
                        "status_message": f"正在下载 ({download_count+1}/{len(matched_assets)}) {remote_tag} ({target_asset['name']})..."
                    })

                    await downloader.download_file(
                        task=current_task,
                        asset=target_asset,
                        tag=remote_tag,
                        default_download_dir=default_dir,
                        all_assets=assets,
                        release_notes=release_notes,
                        force_download=force_download
                    )
                    download_count += 1

            # 任务成功完成，重置指数退避重试计数器
            if task_id in self._retry_counts:
                self._retry_counts[task_id] = 0

        except Exception as e:
            err_msg = str(e)
            current_retry = self._retry_counts.get(task_id, 0)
            max_retries = 3

            # 若为网络抖动/限流/连接错误，执行指数退避重试 (1分钟 -> 3分钟 -> 5分钟)
            if current_retry < max_retries and any(k in err_msg.lower() for k in ["timeout", "connection", "rate limit", "502", "503", "504", "reset", "abort"]):
                self._retry_counts[task_id] = current_retry + 1
                backoff_delay = [60, 180, 300][current_retry]
                update_task(task_id, {
                    "status": "warning",
                    "status_message": f"网络波动 ({err_msg[:40]}...)，触发智能退避第 {self._retry_counts[task_id]}/{max_retries} 次重试 (将在 {backoff_delay}秒后重试)"
                })
                # 安排异步延迟重试
                async def _delayed_retry():
                    await asyncio.sleep(backoff_delay)
                    await self.execute_task_check(task_id, force_download=force_download)
                asyncio.create_task(_delayed_retry())
            else:
                self._retry_counts[task_id] = 0
                update_task(task_id, {
                    "status": "error",
                    "status_message": f"检测/下载失败: {err_msg}"
                })

# 全局单例调度器
scheduler_instance = TaskScheduler()
