import os
import time
import asyncio
import subprocess
import glob
import urllib.request
from typing import Dict, Any, Optional, Callable, List
from backend.database import add_history_record, update_task, get_all_settings
from backend.notifier import NotificationManager

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

# 全局内存字典记录进行中的下载状态
active_downloads: Dict[str, Dict[str, Any]] = {}

class Downloader:
    def __init__(self, 
                 proxy_mode: str = "mirror", 
                 mirror_prefix: str = "https://ghproxy.net/", 
                 mirror_fallback_list: str = "",
                 http_proxy: str = "",
                 timeout: float = 300.0):
        self.proxy_mode = proxy_mode
        self.mirror_prefix = mirror_prefix.strip() if mirror_prefix else ""
        if self.mirror_prefix and not self.mirror_prefix.endswith("/"):
            self.mirror_prefix += "/"
        self.mirror_fallback_list = mirror_fallback_list.strip() if mirror_fallback_list else ""
        self.http_proxy = http_proxy.strip()
        self.timeout = timeout

    def resolve_download_url(self, original_url: str) -> str:
        if self.proxy_mode == "mirror" and self.mirror_prefix:
            clean_url = original_url.strip()
            return f"{self.mirror_prefix}{clean_url}"
        return original_url

    def get_mirror_urls(self, original_url: str, fallback_setting: str = "") -> List[str]:
        """获取候选下载镜像源列表，按优先级排序，支持首选与多镜像轮询及直连兜底"""
        if self.proxy_mode != "mirror":
            return [original_url]
        clean_url = original_url.strip()
        candidates = []
        if self.mirror_prefix:
            prefix = self.mirror_prefix if self.mirror_prefix.endswith("/") else self.mirror_prefix + "/"
            candidates.append(f"{prefix}{clean_url}")
        target_fallback = fallback_setting if fallback_setting else self.mirror_fallback_list
        if target_fallback:
            for line in target_fallback.splitlines():
                m = line.strip()
                if not m:
                    continue
                if not m.endswith("/"):
                    m += "/"
                cand = f"{m}{clean_url}"
                if cand not in candidates:
                    candidates.append(cand)
        # 常见高可用加速源兜底池
        defaults = ["https://ghproxy.net/", "https://mirror.ghproxy.com/", "https://gh.ddlc.top/"]
        for d in defaults:
            cand = f"{d}{clean_url}"
            if cand not in candidates:
                candidates.append(cand)
        # 最终直连兜底
        if clean_url not in candidates:
            candidates.append(clean_url)
        return candidates

    @staticmethod
    def auto_extract_archive(file_path: str, extract_dir: str) -> Dict[str, Any]:
        """安全自动解压 .zip, .tar.gz, .tgz, .tar.xz, .tar.bz2 等归档文件并赋予执行权限"""
        import zipfile
        import tarfile
        res = {"success": False, "extracted_files": [], "error": ""}
        if not os.path.isfile(file_path):
            res["error"] = "文件不存在"
            return res

        lower = file_path.lower()
        real_extract_dir = os.path.realpath(os.path.abspath(extract_dir))
        try:
            os.makedirs(real_extract_dir, exist_ok=True)
            extracted = []
            if lower.endswith(".zip"):
                with zipfile.ZipFile(file_path, 'r') as zf:
                    for member in zf.infolist():
                        if member.is_dir() or ".." in member.filename:
                            continue
                        target = os.path.realpath(os.path.abspath(os.path.join(real_extract_dir, member.filename)))
                        if not target.startswith(real_extract_dir + os.sep) and target != real_extract_dir:
                            continue
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(member) as source, open(target, "wb") as dest:
                            dest.write(source.read())
                        extracted.append(target)
            elif lower.endswith((".tar.gz", ".tgz", ".tar.xz", ".tar.bz2", ".tar")):
                with tarfile.open(file_path, 'r:*') as tf:
                    for member in tf.getmembers():
                        if member.isdir() or ".." in member.name:
                            continue
                        target = os.path.realpath(os.path.abspath(os.path.join(real_extract_dir, member.name)))
                        if not target.startswith(real_extract_dir + os.sep) and target != real_extract_dir:
                            continue
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        tf.extract(member, path=real_extract_dir)
                        extracted.append(target)
            else:
                res["error"] = "暂不支持的压缩文件格式"
                return res

            # 在 Linux / POSIX 环境下自动赋予执行权限 chmod +x
            if os.name != "nt":
                doc_exts = (".txt", ".md", ".json", ".yaml", ".yml", ".html", ".xml", ".css", ".png", ".jpg", ".svg", ".nfo")
                for f in extracted:
                    if os.path.isfile(f) and not f.lower().endswith(doc_exts):
                        try:
                            st = os.stat(f)
                            os.chmod(f, st.st_mode | 0o111)
                        except Exception:
                            pass

            res["success"] = True
            res["extracted_files"] = extracted
            return res
        except Exception as e:
            res["error"] = str(e)
            return res

    @staticmethod
    def check_disk_space(target_dir: str, min_free_gb: float = 2.0) -> tuple:
        """检查目标存储目录所在分区的磁盘可用剩余空间 (GB)，并与安全警戒阈值对比"""
        try:
            os.makedirs(target_dir, exist_ok=True)
            import shutil
            _, _, free_bytes = shutil.disk_usage(os.path.abspath(target_dir))
            free_gb = free_bytes / (1024 ** 3)
            return (free_gb >= min_free_gb, free_gb)
        except Exception as e:
            print(f"[Downloader] 检查磁盘空间异常: {e}")
            return (True, 999.0)

    @staticmethod
    def detect_platform_and_arch(file_name: str) -> Dict[str, str]:
        """根据安装包文件名智能识别操作系统平台与CPU架构"""
        fn_lower = file_name.lower()
        
        # 识别平台 (支持完整文件名以及纯规则关键词如 apk, exe, dmg 等)
        if fn_lower.endswith(".apk") or "apk" in fn_lower or "android" in fn_lower:
            platform = "Android"
        elif any(k in fn_lower for k in [".exe", "exe", ".msi", "msi", "windows", "win64", "win32", "win-x64", "win-arm64"]):
            platform = "Windows"
        elif any(k in fn_lower for k in [".dmg", "dmg", ".pkg", "pkg", "darwin", "macos", "osx", "mac-x64", "mac-arm64"]):
            platform = "macOS"
        elif any(k in fn_lower for k in [".deb", "deb", ".rpm", "rpm", ".appimage", "appimage", "linux"]):
            platform = "Linux"
        elif fn_lower.endswith(".zip") and ("win" in fn_lower or "windows" in fn_lower):
            platform = "Windows"
        elif fn_lower.endswith((".tar.gz", ".tgz")) and ("darwin" in fn_lower or "mac" in fn_lower):
            platform = "macOS"
        else:
            platform = "Other"

        # 识别架构
        if any(k in fn_lower for k in ["arm64", "aarch64", "armv8", "m1", "m2", "m3"]):
            arch = "arm64"
        elif any(k in fn_lower for k in ["x86_64", "amd64", "win64", "x64"]):
            arch = "x64"
        elif any(k in fn_lower for k in ["armv7", "armhf", "armeabi", "arm"]):
            arch = "armv7"
        elif any(k in fn_lower for k in ["i386", "i686", "x86", "win32"]):
            arch = "x86"
        elif "universal" in fn_lower:
            arch = "universal"
        else:
            arch = "common"

        # 识别形态 (便携版 / 安装版)
        form = ""
        if any(k in fn_lower for k in ["portable", "standalone", "便携"]):
            form = "便携版"
        elif any(k in fn_lower for k in ["setup", "installer", "install", "安装", ".msi", "msi"]):
            form = "安装版"
        elif ".appimage" in fn_lower or "appimage" in fn_lower:
            form = "AppImage"
        elif ".deb" in fn_lower:
            form = "Deb"
        elif ".rpm" in fn_lower:
            form = "RPM"
        elif platform == "Windows" and (".zip" in fn_lower or "zip" in fn_lower or ".7z" in fn_lower or "7z" in fn_lower):
            form = "便携版"

        # 智能推荐别名标签
        if platform == "Android":
            tag = "Android 通用版" if arch == "universal" else (f"Android {arch.upper()}" if arch != "common" else "Android")
        elif platform == "Windows":
            parts = ["Windows"]
            if arch and arch != "common":
                parts.append("x64" if arch == "x64" else arch.upper())
            if form:
                parts.append(form)
            tag = " ".join(parts)
        elif platform == "Linux":
            parts = ["Linux"]
            if arch and arch != "common":
                parts.append("AMD64" if arch == "x64" else arch.upper())
            if form and form not in ("Deb", "RPM"):
                parts.append(form)
            tag = " ".join(parts)
        elif platform == "macOS":
            if arch == "arm64":
                tag = "macOS ARM64"
            elif arch == "x64":
                tag = "macOS Intel (x64)"
            else:
                tag = "macOS"
        else:
            tag = "通用版"

        return {"platform": platform, "os": platform, "arch": arch, "form": form, "tag": tag}

    @classmethod
    def resolve_target_dir(cls, raw_dir: str, default_dir: str, task: Dict[str, Any], tag: str, file_name: str = "") -> str:
        path_template = raw_dir.strip() if raw_dir.strip() else default_dir.strip()
        if not path_template:
            path_template = "/www/zfile/dow"

        repo_parts = task.get("repo", "").split("/")
        repo_owner = repo_parts[0] if len(repo_parts) > 0 else "unknown"
        repo_name = repo_parts[1] if len(repo_parts) > 1 else "unknown"
        date_str = time.strftime("%Y-%m-%d")

        meta = cls.detect_platform_and_arch(file_name) if file_name else {"platform": "Common", "os": "Common", "arch": "Common"}

        resolved = path_template.replace("{tag}", tag)\
                                .replace("{name}", task.get("name", "app"))\
                                .replace("{sub_name}", task.get("sub_name", ""))\
                                .replace("{repo_owner}", repo_owner)\
                                .replace("{repo_name}", repo_name)\
                                .replace("{date}", date_str)\
                                .replace("{platform}", meta["platform"])\
                                .replace("{os}", meta["os"])\
                                .replace("{arch}", meta["arch"])

        resolved_abs = os.path.abspath(os.path.expanduser(resolved))
        os.makedirs(resolved_abs, exist_ok=True)
        return resolved_abs

    @classmethod
    async def verify_checksum(cls, file_path: str, file_name: str, all_assets: Optional[List[Dict[str, Any]]], resolve_url_fn) -> str:
        """自动在 Release 资源列表中寻找 SHA256 校验和文件并比对"""
        if not all_assets or not os.path.exists(file_path):
            return "none"

        try:
            import hashlib
            fn_lower = file_name.lower()
            target_chk = None
            for a in all_assets:
                an_lower = a.get("name", "").lower()
                if an_lower in [f"{fn_lower}.sha256", f"{fn_lower}.sha256sum", f"{fn_lower}.sha"]:
                    target_chk = a
                    break
                elif an_lower in [
                    "sha256sums.txt", "sha256sums", "checksums.txt", "checksums",
                    "sha256sum.txt", "sha256sum", "sha256.txt", "hashes.txt",
                    "checksums.sha256", "sha256.checksum"
                ]:
                    target_chk = a

            if not target_chk:
                return "none"

            chk_url = resolve_url_fn(target_chk["browser_download_url"])
            chk_text = ""
            if HAS_HTTPX:
                async with httpx.AsyncClient(timeout=15.0, follow_redirects=True) as client:
                    resp = await client.get(chk_url)
                    if resp.status_code == 200:
                        chk_text = resp.text
            else:
                req = urllib.request.Request(chk_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=15.0) as resp:
                    chk_text = resp.read().decode('utf-8', errors='ignore')

            if not chk_text:
                return "none"

            # 计算本地文件的 SHA256
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(65536), b""):
                    sha256_hash.update(byte_block)
            local_hash = sha256_hash.hexdigest().lower()

            if local_hash in chk_text.lower():
                print(f"[Downloader] 文件 SHA256 完整性校验成功: {file_name}")
                return "verified"
            else:
                print(f"[Downloader] 警告: 文件 SHA256 校验不匹配: {file_name}")
                return "mismatch"
        except Exception as e:
            print(f"[Downloader] 校验和自动验证异常: {e}")
            return "none"

    async def download_file(self, 
                            task: Dict[str, Any], 
                            asset: Dict[str, Any], 
                            tag: str, 
                            default_download_dir: str,
                            all_assets: Optional[List[Dict[str, Any]]] = None,
                            release_notes: str = "",
                            on_progress: Optional[Callable[[Dict[str, Any]], None]] = None,
                            force_download: bool = False) -> str:
        task_id = task["id"]
        task_name = task.get("name", "app")
        raw_url = asset["browser_download_url"]
        # 安全加固：严格剥离任何路径前缀，防范 Path Traversal 路径穿越攻击
        raw_name = asset.get("name", "release_asset").replace("\\", "/")
        file_name = os.path.basename(raw_name)
        if not file_name:
            file_name = "unnamed_asset"
        final_url = self.resolve_download_url(raw_url)

        target_dir = self.resolve_target_dir(
            task.get("download_dir", ""), 
            default_download_dir, 
            task, 
            tag,
            file_name=file_name
        )
        final_file_path = os.path.join(target_dir, file_name)
        temp_file_path = final_file_path + ".tmp.part"

        start_time = time.time()
        last_calc_time = start_time
        bytes_since_last = 0
        settings = get_all_settings()
        if not self.mirror_fallback_list and settings.get("mirror_fallback_list"):
            self.mirror_fallback_list = settings.get("mirror_fallback_list").strip()
        notifier = NotificationManager(settings)

        # 磁盘空间安全阈值熔断保护
        min_free_gb = float(settings.get("min_disk_free_gb", "2") or "2")
        try:
            is_safe, free_gb = Downloader.check_disk_space(target_dir, min_free_gb)
            if not is_safe:
                warn_msg = f"存储空间不足 (剩余 {free_gb:.2f} GB < 警戒值 {min_free_gb:.1f} GB)，已安全熔断终止下载"
                print(f"[Downloader] 熔断告警: {warn_msg}")
                update_task(task_id, {
                    "status": "error",
                    "status_message": warn_msg
                })
                asyncio.create_task(notifier.send_notification(
                    event_type="disk_warning",
                    title=f"磁盘空间不足告警: {task_name}",
                    content=f"存储目录 `{target_dir}` 剩余可用空间仅剩 **{free_gb:.2f} GB**，低于安全警戒线 **{min_free_gb} GB**。\n系统已主动熔断挂起下载，请清理磁盘空间。",
                    task_info={"name": task_name, "repo": task.get("repo", ""), "version": tag, "file_path": final_file_path}
                ))
                raise RuntimeError(warn_msg)
        except RuntimeError:
            raise
        except Exception as e:
            print(f"[Downloader] 检查磁盘空间忽略非致命异常: {e}")

        expected_size = int(asset.get("size", 0))

        # 智能省流与防重复下载检测：
        # 若非强制重新下载，且本地目标目录已存在同名文件且文件大小与线上资产完全吻合
        if not force_download and os.path.exists(final_file_path):
            existing_final_size = os.path.getsize(final_file_path)
            if expected_size > 0 and existing_final_size == expected_size:
                print(f"[Downloader] 命中本地同名同体积安装包: {final_file_path} ({existing_final_size} 字节)，跳过网络下载以节省流量")
                
                # 尝试执行 SHA256 完整性校验（若 Release 中有校验文件）
                checksum_res = await self.verify_checksum(final_file_path, file_name, all_assets, self.resolve_download_url)
                if checksum_res == "mismatch":
                    print(f"[Downloader] 本地文件存在但 SHA256 校验失败，转为重新从网络下载: {file_name}")
                else:
                    # 校验通过或无校验文件：认定为完全一致的已有文件
                    active_downloads[task_id] = {
                        "task_id": task_id,
                        "task_name": task_name,
                        "file_name": file_name,
                        "total_bytes": expected_size,
                        "downloaded_bytes": expected_size,
                        "progress": 100,
                        "speed": "本地已存在 (免下载省流)",
                        "status": "success",
                        "start_time": start_time
                    }
                    if on_progress:
                        on_progress(active_downloads[task_id])

                    # 记录同步历史
                    add_history_record({
                        "task_id": task_id,
                        "task_name": task_name,
                        "tag_name": tag,
                        "file_name": file_name,
                        "file_size": existing_final_size,
                        "save_path": final_file_path,
                        "duration": 0.0,
                        "status": "success",
                        "error_msg": "",
                        "release_notes": f"[本地已存在同名文件，已免下载同步以节省流量]\n" + release_notes,
                        "checksum_status": checksum_res
                    })

                    status_msg = f"本地已存在相同完整安装包 ({file_name})，已自动同步版本并跳过下载 (免流量)"
                    if checksum_res == "verified":
                        status_msg += " [SHA256校验通过]"

                    # 自动解压处理 (若配置开启 auto_extract)
                    if int(task.get("auto_extract", 0) or 0) == 1:
                        ext_res = self.auto_extract_archive(final_file_path, target_dir)
                        if ext_res.get("success"):
                            status_msg += f" [已解压 {len(ext_res.get('extracted_files', []))} 个文件]"
                        elif ext_res.get("error"):
                            status_msg += f" [解压提示: {ext_res['error']}]"

                    update_task(task_id, {
                        "local_version": tag,
                        "remote_version": tag,
                        "release_notes": release_notes,
                        "last_downloaded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "status": "idle",
                        "status_message": status_msg
                    })

                    # 执行自定义命令 (若有)
                    after_cmd = task.get("after_download_cmd", "").strip()
                    if after_cmd:
                        self.execute_after_cmd(after_cmd, final_file_path, target_dir, tag, task=task)

                    # 自动清理历史老旧版本 (Retention Policy)
                    keep_count = int(settings.get("keep_latest_versions", "1"))
                    if keep_count > 0:
                        self.cleanup_old_versions(target_dir, file_name, keep_count)

                    return final_file_path

        existing_size = os.path.getsize(temp_file_path) if os.path.exists(temp_file_path) else 0
        is_resuming = (existing_size > 0 and (not expected_size or existing_size < expected_size))

        active_downloads[task_id] = {
            "task_id": task_id,
            "task_name": task_name,
            "file_name": file_name,
            "total_bytes": expected_size,
            "downloaded_bytes": existing_size if is_resuming else 0,
            "progress": int(existing_size / expected_size * 100) if (expected_size and is_resuming) else 0,
            "speed": "断点续传连接中..." if is_resuming else "0 KB/s",
            "status": "downloading",
            "start_time": start_time
        }

        try:
            candidate_urls = self.get_mirror_urls(raw_url, settings.get("mirror_fallback_list", ""))
            download_succeeded = False
            last_download_error = None

            for url_idx, candidate_url in enumerate(candidate_urls):
                try:
                    if HAS_HTTPX:
                        proxy_val = self.http_proxy if (self.proxy_mode == "http_proxy" and self.http_proxy) else None
                        headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
                        if is_resuming:
                            headers["Range"] = f"bytes={existing_size}-"
    
                        client_kwargs = {
                            "timeout": self.timeout,
                            "follow_redirects": True,
                            "headers": headers
                        }
                        if proxy_val:
                            try:
                                client = httpx.AsyncClient(proxy=proxy_val, **client_kwargs)
                            except TypeError:
                                client = httpx.AsyncClient(proxies=proxy_val, **client_kwargs)
                        else:
                            client = httpx.AsyncClient(**client_kwargs)
    
                        async with client:
                            async with client.stream("GET", candidate_url) as resp:
                                resp.raise_for_status()
                                
                                if resp.status_code == 206:
                                    # 服务端接受 Range，断点续传
                                    total_size = existing_size + int(resp.headers.get("content-length", 0))
                                    downloaded = existing_size
                                    open_mode = "ab"
                                else:
                                    # 服务端不支持断点或从头下载
                                    total_size = int(resp.headers.get("content-length", expected_size))
                                    downloaded = 0
                                    open_mode = "wb"
    
                                active_downloads[task_id]["total_bytes"] = total_size
    
                                with open(temp_file_path, open_mode) as f:
                                    async for chunk in resp.aiter_bytes(chunk_size=65536):
                                        f.write(chunk)
                                        downloaded += len(chunk)
                                        bytes_since_last += len(chunk)
    
                                        now = time.time()
                                        if now - last_calc_time >= 0.5:
                                            elapsed = now - last_calc_time
                                            speed_bps = bytes_since_last / elapsed if elapsed > 0 else 0
                                            speed_str = f"{speed_bps / (1024 * 1024):.2f} MB/s" if speed_bps > 1024*1024 else f"{speed_bps / 1024:.1f} KB/s"
                                            percent = int(downloaded / total_size * 100) if total_size > 0 else 0
                                            active_downloads[task_id]["downloaded_bytes"] = downloaded
                                            active_downloads[task_id]["progress"] = percent
                                            active_downloads[task_id]["speed"] = speed_str
                                            last_calc_time = now
                                            bytes_since_last = 0
                                            if on_progress:
                                                on_progress(active_downloads[task_id])
                    else:
                        req_headers = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
                        if is_resuming:
                            req_headers["Range"] = f"bytes={existing_size}-"
    
                        req = urllib.request.Request(candidate_url, headers=req_headers)
                        opener = urllib.request.build_opener()
                        if self.proxy_mode == "http_proxy" and self.http_proxy:
                            opener.add_handler(urllib.request.ProxyHandler({'http': self.http_proxy, 'https': self.http_proxy}))
                        
                        with opener.open(req, timeout=self.timeout) as resp:
                            resp_code = getattr(resp, 'status', 200)
                            if resp_code == 206:
                                total_size = existing_size + int(resp.headers.get("Content-Length", 0))
                                downloaded = existing_size
                                open_mode = "ab"
                            else:
                                total_size = int(resp.headers.get("Content-Length", expected_size))
                                downloaded = 0
                                open_mode = "wb"
    
                            active_downloads[task_id]["total_bytes"] = total_size
    
                            with open(temp_file_path, open_mode) as f:
                                while True:
                                    chunk = resp.read(65536)
                                    if not chunk:
                                        break
                                    f.write(chunk)
                                    downloaded += len(chunk)
                                    bytes_since_last += len(chunk)
    
                                    now = time.time()
                                    if now - last_calc_time >= 0.5:
                                        elapsed = now - last_calc_time
                                        speed_bps = bytes_since_last / elapsed if elapsed > 0 else 0
                                        speed_str = f"{speed_bps / (1024 * 1024):.2f} MB/s" if speed_bps > 1024*1024 else f"{speed_bps / 1024:.1f} KB/s"
                                        percent = int(downloaded / total_size * 100) if total_size > 0 else 0
                                        active_downloads[task_id]["downloaded_bytes"] = downloaded
                                        active_downloads[task_id]["progress"] = percent
                                        active_downloads[task_id]["speed"] = speed_str
                                        last_calc_time = now
                                        bytes_since_last = 0
                                        if on_progress:
                                            on_progress(active_downloads[task_id])
    
                    download_succeeded = True
                    break
                except Exception as dl_err:
                    last_download_error = dl_err
                    if url_idx + 1 < len(candidate_urls):
                        print(f"[Downloader] 镜像源 [{candidate_url[:40]}...] 下载中断: {dl_err}，尝试切换下一备用源...")
                        if os.path.exists(temp_file_path):
                            try:
                                os.remove(temp_file_path)
                            except Exception:
                                pass
                        existing_size = 0
                        is_resuming = False
                        continue
                    else:
                        raise last_download_error

            if not download_succeeded and last_download_error:
                raise last_download_error
    
            # 原子化替换临时文件为目标文件，避免文件竞争或Windows锁死
            os.replace(temp_file_path, final_file_path)
    
            # 自动执行 SHA256 完整性校验
            checksum_res = await self.verify_checksum(final_file_path, file_name, all_assets, self.resolve_download_url)
    
            duration = round(time.time() - start_time, 2)
            active_downloads[task_id]["status"] = "success"
            active_downloads[task_id]["progress"] = 100
            active_downloads[task_id]["speed"] = "完成"

            # 严格哈希校验策略：如果开启严格模式且校验不匹配，立刻安全销毁并拦截
            checksum_strict = str(settings.get("checksum_strict", "0")) == "1"
            if checksum_strict and checksum_res == "mismatch":
                if os.path.exists(final_file_path):
                    try:
                        os.remove(final_file_path)
                    except Exception:
                        pass
                active_downloads[task_id]["status"] = "error"
                active_downloads[task_id]["speed"] = "SHA256不符"
                add_history_record({
                    "task_id": task_id,
                    "task_name": task_name,
                    "tag_name": tag,
                    "file_name": file_name,
                    "file_size": downloaded,
                    "save_path": final_file_path,
                    "duration": duration,
                    "status": "failed",
                    "error_msg": "SHA256哈希校验不匹配，已触发安全防御强制拦截并清除临时包",
                    "release_notes": release_notes,
                    "checksum_status": "mismatch"
                })
                raise RuntimeError(f"文件 {file_name} 的 SHA256 校验和与 Release 官方声明不符！严格模式下已终止更新并删除下载包。")
    
            add_history_record({
                "task_id": task_id,
                "task_name": task_name,
                "tag_name": tag,
                "file_name": file_name,
                "file_size": downloaded,
                "save_path": final_file_path,
                "duration": duration,
                "status": "success",
                "error_msg": "",
                "release_notes": release_notes,
                "checksum_status": checksum_res
            })
    
            status_msg = f"成功下载版本 {tag} ({file_name})"
            if checksum_res == "verified":
                status_msg += " [SHA256校验通过]"
            elif checksum_res == "mismatch":
                status_msg += " [SHA256校验不匹配]"
    
            # 自动解压处理 (若配置开启 auto_extract)
            if int(task.get("auto_extract", 0) or 0) == 1:
                ext_res = self.auto_extract_archive(final_file_path, target_dir)
                if ext_res.get("success"):
                    extracted_count = len(ext_res.get("extracted_files", []))
                    status_msg += f" [已自动解压 {extracted_count} 个文件]"
                elif ext_res.get("error"):
                    status_msg += f" [解压提示: {ext_res['error']}]"
    
            update_task(task_id, {
                "local_version": tag,
                "remote_version": tag,
                "release_notes": release_notes,
                "last_downloaded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "idle",
                "status_message": status_msg
            })
    
            # 执行自定义命令
            after_cmd = task.get("after_download_cmd", "").strip()
            if after_cmd:
                self.execute_after_cmd(after_cmd, final_file_path, target_dir, tag, task=task)
    
            # 自动清理历史老旧版本文件 (Retention Policy)
            keep_count = int(settings.get("keep_latest_versions", "1"))
            if keep_count > 0:
                self.cleanup_old_versions(target_dir, file_name, keep_count)

            # 触发下载成功通知
            chk_tip = "已通过 SHA256 完整性校验" if checksum_res == "verified" else ""
            notes_snippet = f"\n\n### 📝 更新日志摘要:\n{release_notes[:300]}..." if release_notes else ""

            asyncio.create_task(notifier.send_notification(
                event_type="download_success",
                title=f"软件升级完成: {task_name} {tag}",
                content=f"安装包已成功下载并同步至本地。\n文件大小: {(downloaded/1024/1024):.2f} MB，耗时: {duration} 秒。{chk_tip}{notes_snippet}",
                task_info={
                    "name": task_name,
                    "repo": task.get("repo", ""),
                    "version": tag,
                    "file_path": final_file_path
                }
            ))

            return final_file_path

        except Exception as e:
            err_msg = str(e)
            # 智能断点续传保护：
            # 仅在致命错误（如 404/410/416等不可恢复错误）或文件已超出预期大小损坏时清理 .tmp.part
            # 常规网络连接重置、超时、代理中断时保留临时文件，下次执行时可无缝 Range 续传！
            is_fatal = any(k in err_msg for k in ["404", "Not Found", "410", "416", "Range Not Satisfiable"])
            current_tmp_sz = os.path.getsize(temp_file_path) if os.path.exists(temp_file_path) else 0
            is_corrupt = bool(expected_size > 0 and current_tmp_sz > expected_size)

            if (is_fatal or is_corrupt) and os.path.exists(temp_file_path):
                try:
                    os.remove(temp_file_path)
                except Exception:
                    pass

            active_downloads[task_id]["status"] = "failed"
            active_downloads[task_id]["speed"] = "失败"

            add_history_record({
                "task_id": task_id,
                "task_name": task_name,
                "tag_name": tag,
                "file_name": file_name,
                "file_size": 0,
                "save_path": final_file_path,
                "duration": round(time.time() - start_time, 2),
                "status": "failed",
                "error_msg": err_msg
            })

            update_task(task_id, {
                "status": "error",
                "status_message": f"下载失败: {err_msg}"
            })

            # 触发下载失败告警通知
            asyncio.create_task(notifier.send_notification(
                event_type="download_failed",
                title=f"软件下载失败告警: {task_name} {tag}",
                content=f"在下载安装包 `{file_name}` 时发生异常，请检查网络或配置。\n错误原因: {err_msg}",
                task_info={
                    "name": task_name,
                    "repo": task.get("repo", ""),
                    "version": tag,
                    "file_path": final_file_path
                }
            ))
            raise

        finally:
            asyncio.create_task(self._cleanup_download_info(task_id, start_time))

    async def _cleanup_download_info(self, task_id: str, download_start_time: float):
        await asyncio.sleep(8)
        if task_id in active_downloads:
            # 仅当任务时间戳一致时才清理，避免误删后续并发或连续下载的进度
            if active_downloads[task_id].get("start_time") == download_start_time:
                del active_downloads[task_id]

    @staticmethod
    def execute_after_cmd(cmd_template: str, file_path: str, target_dir: str, tag: str, task: Optional[Dict[str, Any]] = None) -> bool:
        if not cmd_template or not str(cmd_template).strip():
            return True
        filename = os.path.basename(file_path)
        software_name = (task.get("name", "") if task else "") or os.path.splitext(filename)[0]
        sub_name = (task.get("sub_name", "") if task else "")
        task_id = (task.get("id", "") if task else "")
        repo_name = (task.get("repo", "") if task else "")
        # 兼容跨平台(Windows 与 Linux/POSIX)命令参数安全转义
        if os.name == "nt":
            quoted_filepath = f'"{file_path}"'
            quoted_filename = f'"{filename}"'
            quoted_dir = f'"{target_dir}"'
            quoted_tag = f'"{tag}"'
            quoted_name = f'"{software_name}"'
            quoted_sub_name = f'"{sub_name}"'
            quoted_task_id = f'"{task_id}"'
            quoted_repo = f'"{repo_name}"'
        else:
            import shlex
            quoted_filepath = shlex.quote(file_path)
            quoted_filename = shlex.quote(filename)
            quoted_dir = shlex.quote(target_dir)
            quoted_tag = shlex.quote(tag)
            quoted_name = shlex.quote(software_name)
            quoted_sub_name = shlex.quote(sub_name)
            quoted_task_id = shlex.quote(task_id)
            quoted_repo = shlex.quote(repo_name)

        cmd = cmd_template.replace("{filepath}", quoted_filepath)\
                          .replace("{filename}", quoted_filename)\
                          .replace("{dir}", quoted_dir)\
                          .replace("{tag}", quoted_tag)\
                          .replace("{name}", quoted_name)\
                          .replace("{sub_name}", quoted_sub_name)\
                          .replace("{task_id}", quoted_task_id)\
                          .replace("{version}", quoted_tag)\
                          .replace("{repo}", quoted_repo)

        # 注入标准环境变量供脚本直接读取 (全面支持老版及规范版 RELEASE_* 环境变量)
        env = os.environ.copy()
        env["FILE_PATH"] = file_path
        env["RELEASE_FILEPATH"] = file_path
        env["FILE_NAME"] = filename
        env["RELEASE_FILENAME"] = filename
        env["SAVE_DIR"] = target_dir
        env["RELEASE_DIR"] = target_dir
        env["RELEASE_EXTRACTED_DIR"] = target_dir
        env["TAG"] = tag
        env["VERSION"] = tag
        env["RELEASE_VER"] = tag
        env["SOFTWARE_NAME"] = software_name
        env["APP_NAME"] = software_name
        env["SUB_NAME"] = sub_name
        env["RELEASE_SUB_NAME"] = sub_name
        env["TASK_ID"] = task_id
        env["REPO"] = repo_name
        env["APP_REPO"] = repo_name

        try:
            subprocess.Popen(cmd, shell=True, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except Exception as e:
            print(f"[Downloader] 执行自定义命令异常: {e}")
            return False

    @staticmethod
    def cleanup_old_versions(target_dir: str, current_file: Any = "", keep_count: int = 1):
        """保留最近 keep_count 个版本，自动清理属于该软件的历史旧版本包"""
        try:
            if isinstance(current_file, int):
                keep_count = current_file
                current_file = ""
            if not os.path.isdir(target_dir):
                return
            # 提取当前包特征前缀 (例如 v2rayN-windows-64-desktop.zip -> 提取 v2rayN)
            cur_base = os.path.basename(str(current_file)) if current_file else ""
            prefix = cur_base.split("-")[0].split("_")[0].lower() if cur_base else ""
            cur_meta = Downloader.detect_platform_and_arch(cur_base) if cur_base else None

            all_matched_files = []
            for f in os.listdir(target_dir):
                full_p = os.path.join(target_dir, f)
                if not os.path.isfile(full_p) or f.endswith(".tmp") or f.startswith("."):
                    continue
                # 精准归属：前缀相同，且若能识别平台则保证平台一致，杜绝同软件跨平台包误删
                if prefix:
                    if prefix not in f.lower():
                        continue
                    if cur_meta and cur_meta.get("platform") != "Other":
                        f_meta = Downloader.detect_platform_and_arch(f)
                        if f_meta.get("platform") != "Other" and f_meta.get("platform") != cur_meta.get("platform"):
                            continue
                    all_matched_files.append(full_p)
                else:
                    all_matched_files.append(full_p)

            cur_path = os.path.join(target_dir, cur_base) if cur_base else ""
            cur_mtime = os.path.getmtime(cur_path) if cur_path and os.path.exists(cur_path) else None

            if len(all_matched_files) > keep_count:
                all_matched_files.sort(key=lambda x: os.path.getmtime(x))
                candidate_removals = all_matched_files[:len(all_matched_files) - keep_count]
                for old_file in candidate_removals:
                    # 绝对保护：无论文件修改时间如何，坚决不得删除刚刚成功下载的目标文件本身！
                    if cur_base and os.path.basename(old_file) == cur_base:
                        continue
                    # 若指定了当前正在下载的文件，保护与其处于同批次产生但不同名的其他新文件（修改时间在 5 分钟内）
                    if cur_mtime is not None:
                        file_mtime = os.path.getmtime(old_file)
                        if os.path.basename(old_file) != cur_base and abs(cur_mtime - file_mtime) < 300:
                            continue
                    try:
                        os.remove(old_file)
                        print(f"[Downloader] 自动清理历史老版本安装包: {old_file}")
                    except Exception:
                        pass
        except Exception as e:
            print(f"[Downloader] 旧版本清理异常: {e}")
