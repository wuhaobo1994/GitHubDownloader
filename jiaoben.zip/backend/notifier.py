import smtplib
import hmac
import hashlib
import base64
import time
import asyncio
import urllib.parse
import json
import urllib.request
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from typing import Dict, Any, List, Optional

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

class NotificationManager:
    def __init__(self, settings: Dict[str, str]):
        self.settings = settings

    def is_event_enabled(self, event_type: str) -> bool:
        """检查指定事件类型是否启用了通知: upgrade_found, download_success, download_failed"""
        if str(self.settings.get("notify_enabled", "0")) != "1":
            return False
        enabled_events = self.settings.get("notify_events", "upgrade_found,download_success,download_failed")
        return event_type in [e.strip() for e in enabled_events.split(",")]

    async def send_notification(self, 
                                event_type: str, 
                                title: str, 
                                content: str, 
                                task_info: Optional[Dict[str, Any]] = None):
        """统一发送多渠道通知"""
        if not self.is_event_enabled(event_type):
            return

        device_name = self.settings.get("device_name", "Linux-01")
        full_title = f"[{device_name}] {title}"
        
        # 组装富文本/Markdown消息正文
        markdown_body = f"### {full_title}\n\n{content}\n\n"
        if task_info:
            markdown_body += f"> **设备节点**: {device_name}\n\n"
            markdown_body += f"> **软件名称**: {task_info.get('name', '')}\n\n"
            markdown_body += f"> **GitHub仓库**: {task_info.get('repo', '')}\n\n"
            if task_info.get('version'):
                markdown_body += f"> **最新版本**: {task_info.get('version')}\n\n"
            if task_info.get('file_path'):
                markdown_body += f"> **保存路径**: `{task_info.get('file_path')}`\n\n"
        markdown_body += f"> **通知时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}\n"

        # 并发并行派发到各个已配置的渠道，单渠道异常不阻断其他渠道
        channel_tasks = [
            self.send_email(full_title, markdown_body),
            self.send_dingtalk(full_title, markdown_body),
            self.send_feishu(full_title, markdown_body),
            self.send_wechat(full_title, markdown_body),
            self.send_telegram(full_title, markdown_body),
            self.send_bark(full_title, markdown_body),
            self.send_discord(full_title, markdown_body),
            self.send_pushplus(full_title, markdown_body)
        ]
        await asyncio.gather(*channel_tasks, return_exceptions=True)

    # ---------------- 1. 邮件通知 (SMTP) ----------------

    async def send_email(self, subject: str, body_text: str) -> bool:
        host = self.settings.get("smtp_host", "").strip()
        port = int(self.settings.get("smtp_port", "465")) if self.settings.get("smtp_port") else 465
        user = self.settings.get("smtp_user", "").strip()
        pwd = self.settings.get("smtp_pass", "").strip()
        sender = self.settings.get("smtp_from", "").strip() or user
        receivers_str = self.settings.get("smtp_to", "").strip()
        is_ssl = str(self.settings.get("smtp_ssl", "1")) == "1"

        if not host or not user or not pwd or not receivers_str:
            return False

        receivers = [r.strip() for r in receivers_str.split(",") if r.strip()]
        if not receivers:
            return False

        try:
            # 邮件内容构建
            msg = MIMEMultipart()
            msg["From"] = Header(f"GitRelease Watcher <{sender}>", "utf-8")
            msg["To"] = Header(", ".join(receivers), "utf-8")
            msg["Subject"] = Header(subject, "utf-8")

            # 转换为简洁易读的 HTML 邮件正文
            html_content = f"""
            <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
                <div style="background: #2563eb; color: #ffffff; padding: 16px 20px;">
                    <h2 style="margin: 0; font-size: 18px;">{subject}</h2>
                </div>
                <div style="padding: 20px; color: #334155; line-height: 1.6; white-space: pre-wrap;">
{body_text}
                </div>
                <div style="background: #f8fafc; padding: 12px 20px; font-size: 12px; color: #94a3b8; border-top: 1px solid #e2e8f0;">
                    此邮件由 Linux 本地 GitRelease Watcher 自动推送
                </div>
            </div>
            """
            msg.attach(MIMEText(html_content, "html", "utf-8"))
            msg_str = msg.as_string()

            # 将同步阻塞的 SMTP 网络交互移入后台线程池执行，彻底解除主事件循环冻结隐患
            def _sync_send():
                if is_ssl or port == 465:
                    server = smtplib.SMTP_SSL(host, port, timeout=15)
                else:
                    server = smtplib.SMTP(host, port, timeout=15)
                    server.starttls()

                server.login(user, pwd)
                server.sendmail(sender, receivers, msg_str)
                server.quit()
                return True

            await asyncio.to_thread(_sync_send)
            return True
        except Exception as e:
            print(f"[Notifier] 邮件推送失败: {e}")
            raise e

    # ---------------- 2. 钉钉机器人通知 ----------------

    async def send_dingtalk(self, title: str, markdown_content: str) -> bool:
        webhook = self.settings.get("dingtalk_webhook", "").strip()
        secret = self.settings.get("dingtalk_secret", "").strip()
        if not webhook:
            return False

        target_url = webhook
        if secret:
            timestamp = str(round(time.time() * 1000))
            secret_enc = secret.encode("utf-8")
            string_to_sign = f"{timestamp}\n{secret}".encode("utf-8")
            hmac_code = hmac.new(secret_enc, string_to_sign, digestmod=hashlib.sha256).digest()
            sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
            sep = "&" if "?" in webhook else "?"
            target_url = f"{webhook}{sep}timestamp={timestamp}&sign={sign}"

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "title": title,
                "text": f"## {title}\n\n{markdown_content}"
            }
        }
        return await self._http_post_json(target_url, payload)

    # ---------------- 3. 飞书自定义机器人通知 ----------------

    async def send_feishu(self, title: str, markdown_content: str) -> bool:
        webhook = self.settings.get("feishu_webhook", "").strip()
        secret = self.settings.get("feishu_secret", "").strip()
        if not webhook:
            return False

        payload: Dict[str, Any] = {
            "msg_type": "interactive",
            "card": {
                "header": {
                    "title": {"tag": "plain_text", "content": title},
                    "template": "blue"
                },
                "elements": [
                    {
                        "tag": "markdown",
                        "content": markdown_content
                    }
                ]
            }
        }

        # 飞书签名校验
        if secret:
            timestamp = str(int(time.time()))
            string_to_sign = f"{timestamp}\n{secret}"
            hmac_code = hmac.new(string_to_sign.encode("utf-8"), digestmod=hashlib.sha256).digest()
            sign = base64.b64encode(hmac_code).decode("utf-8")
            payload["timestamp"] = timestamp
            payload["sign"] = sign

        return await self._http_post_json(webhook, payload)

    # ---------------- 4. 企业微信机器人通知 ----------------

    async def send_wechat(self, title: str, markdown_content: str) -> bool:
        webhook = self.settings.get("wechat_webhook", "").strip()
        if not webhook:
            return False

        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": f"### {title}\n\n{markdown_content}"
            }
        }
        return await self._http_post_json(webhook, payload)

    # ---------------- 5. Telegram Bot 通知 ----------------

    async def send_telegram(self, title: str, markdown_content: str, check_enabled: bool = True) -> bool:
        if check_enabled and str(self.settings.get("telegram_enabled", "0")) != "1":
            return False
        bot_token = self.settings.get("telegram_bot_token", "").strip()
        chat_id = self.settings.get("telegram_chat_id", "").strip()
        api_url = (self.settings.get("telegram_api_url", "").strip() or "https://api.telegram.org").rstrip("/")
        if not bot_token or not chat_id:
            return False

        url = f"{api_url}/bot{bot_token}/sendMessage"
        # 净化 markdown 以免 telegram 解析失败
        clean_text = f"*{title}*\n\n" + markdown_content.replace("### ", "").replace("**", "*")
        payload = {
            "chat_id": chat_id,
            "text": clean_text[:4000],
            "parse_mode": "Markdown"
        }
        return await self._http_post_json(url, payload)

    # ---------------- 6. Bark (iOS) 通知 ----------------

    async def send_bark(self, title: str, markdown_content: str, check_enabled: bool = True) -> bool:
        if check_enabled and str(self.settings.get("bark_enabled", "0")) != "1":
            return False
        server = (self.settings.get("bark_server_url", "").strip() or "https://api.day.app").rstrip("/")
        key = self.settings.get("bark_key", "").strip()
        if not key:
            return False

        url = f"{server}/push"
        clean_body = markdown_content.replace("#", "").replace("*", "").replace("`", "").strip()
        payload = {
            "title": title,
            "body": clean_body[:2000],
            "device_key": key,
            "group": "GitReleaseWatcher"
        }
        return await self._http_post_json(url, payload)

    # ---------------- 7. Discord Webhook 通知 ----------------

    async def send_discord(self, title: str, markdown_content: str, check_enabled: bool = True) -> bool:
        if check_enabled and str(self.settings.get("discord_enabled", "0")) != "1":
            return False
        webhook = self.settings.get("discord_webhook", "").strip()
        if not webhook:
            return False

        clean_text = markdown_content.replace("### ", "**").replace("`", "`")
        payload = {
            "content": f"**{title}**\n\n{clean_text[:1900]}"
        }
        return await self._http_post_json(webhook, payload)

    # ---------------- 8. PushPlus (微信轻量推送) ----------------

    async def send_pushplus(self, title: str, markdown_content: str, check_enabled: bool = True) -> bool:
        if check_enabled and str(self.settings.get("pushplus_enabled", "0")) != "1":
            return False
        token = self.settings.get("pushplus_token", "").strip()
        if not token:
            return False

        url = "https://www.pushplus.plus/send"
        payload = {
            "token": token,
            "title": title[:100],
            "content": markdown_content[:15000],
            "template": "markdown"
        }
        return await self._http_post_json(url, payload)

    # ---------------- 底层 HTTP POST 封装 ----------------

    async def _http_post_json(self, url: str, data: Dict[str, Any]) -> bool:
        try:
            body_bytes = json.dumps(data).encode("utf-8")
            req_headers = {
                "Content-Type": "application/json; charset=utf-8",
                "User-Agent": "GitRelease-Watcher/1.0"
            }
            if HAS_HTTPX:
                async with httpx.AsyncClient(timeout=15.0, headers=req_headers) as client:
                    resp = await client.post(url, json=data)
                    return 200 <= resp.status_code < 300
            else:
                def _do_urlopen():
                    req = urllib.request.Request(
                        url, 
                        data=body_bytes, 
                        headers=req_headers
                    )
                    with urllib.request.urlopen(req, timeout=15) as resp:
                        return 200 <= resp.status < 300
                return await asyncio.to_thread(_do_urlopen)
        except Exception as e:
            print(f"[Notifier] Webhook 发送失败 ({url[:30]}...): {e}")
            raise e
