import re
import json
import urllib.request
import urllib.error
from typing import List, Dict, Any, Optional

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False

class GitHubClient:
    def __init__(self, token: str = "", proxy_url: str = "", timeout: float = 30.0):
        self.token = token.strip()
        self.proxy_url = proxy_url.strip()
        self.timeout = timeout

    def _get_headers(self) -> Dict[str, str]:
        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "GitRelease-Watcher/1.0"
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def get_latest_release(self, repo: str, include_prerelease: bool = False) -> Dict[str, Any]:
        """
        获取指定仓库最新 Release
        兼容支持 httpx 异步库与 Python 原生 urllib 标准库
        """
        clean_repo = repo.strip().strip("/")
        if "github.com/" in clean_repo:
            clean_repo = clean_repo.split("github.com/")[-1].strip("/")
        if clean_repo.endswith(".git"):
            clean_repo = clean_repo[:-4]
        # 智能提取前两段作为 owner/repo (应对用户粘贴 releases/tag/tree 等页面 URL)
        parts = [p for p in clean_repo.split("/") if p]
        if len(parts) >= 2:
            clean_repo = f"{parts[0]}/{parts[1]}"
            if clean_repo.endswith(".git"):
                clean_repo = clean_repo[:-4]

        if not re.match(r"^[a-zA-Z0-9_.-]+/[a-zA-Z0-9_.-]+$", clean_repo):
            raise ValueError(f"仓库格式无效: '{repo}'，必须为标准 'owner/repo' 格式 (例如 'syncthing/syncthing')")

        if HAS_HTTPX:
            return await self._get_with_httpx(clean_repo, include_prerelease)
        else:
            import asyncio
            return await asyncio.to_thread(self._get_with_urllib, clean_repo, include_prerelease)

    def _create_httpx_client(self):
        if not HAS_HTTPX:
            return None
        client_kwargs = {
            "headers": self._get_headers(),
            "timeout": self.timeout,
            "follow_redirects": True
        }
        if self.proxy_url:
            try:
                # httpx >= 0.26.0 使用 proxy 参数
                return httpx.AsyncClient(proxy=self.proxy_url, **client_kwargs)
            except TypeError:
                # httpx < 0.26.0 使用 proxies 参数
                return httpx.AsyncClient(proxies=self.proxy_url, **client_kwargs)
        return httpx.AsyncClient(**client_kwargs)

    async def _get_with_httpx(self, clean_repo: str, include_prerelease: bool) -> Dict[str, Any]:
        async with self._create_httpx_client() as client:
            if not include_prerelease:
                url = f"https://api.github.com/repos/{clean_repo}/releases/latest"
                resp = await client.get(url)
                if resp.status_code == 200:
                    return resp.json()
                elif resp.status_code == 403:
                    try:
                        msg = resp.json().get('message', '')
                    except Exception:
                        msg = resp.text[:100]
                    raise PermissionError(f"GitHub API 限流: {msg}. 请在设置中配置 GitHub Token。")

            url = f"https://api.github.com/repos/{clean_repo}/releases"
            resp = await client.get(url, params={"per_page": 10})
            if resp.status_code == 403:
                try:
                    msg = resp.json().get('message', '')
                except Exception:
                    msg = resp.text[:100]
                raise PermissionError(f"GitHub API 限流: {msg}. 请在设置中配置 GitHub Token。")
            resp.raise_for_status()
            releases = resp.json()
            return self._select_release(releases, clean_repo, include_prerelease)

    def _get_with_urllib(self, clean_repo: str, include_prerelease: bool) -> Dict[str, Any]:
        headers = self._get_headers()
        opener = urllib.request.build_opener()
        if self.proxy_url:
            opener.add_handler(urllib.request.ProxyHandler({'http': self.proxy_url, 'https': self.proxy_url}))

        if not include_prerelease:
            url = f"https://api.github.com/repos/{clean_repo}/releases/latest"
            req = urllib.request.Request(url, headers=headers)
            try:
                with opener.open(req, timeout=self.timeout) as resp:
                    if resp.status == 200:
                        return json.loads(resp.read().decode('utf-8'))
            except urllib.error.HTTPError as e:
                if e.code == 403:
                    raise PermissionError("GitHub API 限频受限(403)，请配置 Token")
            except Exception:
                pass

        url = f"https://api.github.com/repos/{clean_repo}/releases?per_page=10"
        req = urllib.request.Request(url, headers=headers)
        try:
            with opener.open(req, timeout=self.timeout) as resp:
                releases = json.loads(resp.read().decode('utf-8'))
                return self._select_release(releases, clean_repo, include_prerelease)
        except urllib.error.HTTPError as e:
            if e.code == 403:
                raise PermissionError("GitHub API 限频受限(403)，建议在面板设置中配置 GitHub Token")
            raise

    @staticmethod
    def _select_release(releases: List[Dict[str, Any]], clean_repo: str, include_prerelease: bool) -> Dict[str, Any]:
        if not releases:
            raise ValueError(f"仓库 '{clean_repo}' 没有任何 Release")
        for r in releases:
            if r.get("draft"):
                continue
            if not include_prerelease and r.get("prerelease"):
                continue
            return r
        raise ValueError(f"仓库 '{clean_repo}' 未找到符合条件的 Release")

    @staticmethod
    def match_assets(assets: List[Dict[str, Any]], 
                     filter_mode: str, 
                     include_rule: str, 
                     exclude_rule: str) -> List[Dict[str, Any]]:
        matched = []
        exclude_tokens = [t.strip().lower() for t in exclude_rule.split(",") if t.strip()]

        for asset in assets:
            name = asset.get("name", "")
            name_lower = name.lower()

            # 排除规则
            excluded = False
            for exc in exclude_tokens:
                if exc in name_lower:
                    excluded = True
                    break
            if excluded:
                continue

            # 包含规则
            if filter_mode == "regex":
                if not include_rule.strip():
                    matched.append(asset)
                else:
                    try:
                        if re.search(include_rule.strip(), name, re.IGNORECASE):
                            matched.append(asset)
                    except re.error as e:
                        raise ValueError(f"正则表达式语法错误: {e}")
            else:
                include_tokens = [t.strip().lower() for t in include_rule.split(",") if t.strip()]
                if not include_tokens:
                    matched.append(asset)
                else:
                    all_present = all(tok in name_lower for tok in include_tokens)
                    if all_present:
                        matched.append(asset)

        return matched

    @staticmethod
    def check_version_upgrade(local_ver: str, remote_ver: str) -> bool:
        clean_local = (local_ver or "").strip().lstrip("vV")
        clean_remote = (remote_ver or "").strip().lstrip("vV")
        if not clean_local:
            return True
        return clean_local != clean_remote
