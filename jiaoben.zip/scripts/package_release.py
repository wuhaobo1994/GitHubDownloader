#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GitRelease Watcher - 官方版本打包发布脚本
功能: 打包生成标准发布文件 (.zip 和 .tar.gz)
安全保证:
1. 绝对不打包 data/*.db 数据库文件 (严禁携带空白数据库覆盖用户生产数据)
2. 保留 data/.gitkeep 确保解压后目录结构完整
3. 严格排除 venv、__pycache__、backup_*、临时测试文件
"""

import os
import sys
import zipfile
import tarfile
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

EXCLUDE_DIRS = {
    "dist", "venv", ".venv", "__pycache__", ".git", ".idea", ".vscode", "node_modules", "test_downloads"
}

EXCLUDE_EXTENSIONS = {
    ".pyc", ".pyo", ".pyd", ".db", ".db-wal", ".db-shm", ".restore_prev", ".bak", ".tmp"
}

def should_exclude(rel_path: str) -> bool:
    parts = rel_path.replace("\\", "/").strip("/").split("/")
    # 排除指定目录
    for p in parts:
        if p in EXCLUDE_DIRS or p.startswith("backup_"):
            return True
    
    # 核心安全规则: 允许 data/.gitkeep，但严禁任何 data/*.db
    if parts[0] == "data":
        if len(parts) > 1 and parts[1] != ".gitkeep":
            return True

    filename = parts[-1]
    _, ext = os.path.splitext(filename)
    if ext.lower() in EXCLUDE_EXTENSIONS:
        return True

    if filename.startswith(".pytest_cache"):
        return True

    return False

def package():
    dist_dir = os.path.join(BASE_DIR, "dist")
    os.makedirs(dist_dir, exist_ok=True)
    version = "2.1.0"
    ts = datetime.now().strftime("%Y%m%d")
    base_name = f"GitReleaseWatcher-v{version}_{ts}"

    zip_path = os.path.join(dist_dir, f"{base_name}.zip")
    tar_path = os.path.join(dist_dir, f"{base_name}.tar.gz")

    print(f"==================================================")
    print(f" 开始打包 GitRelease Watcher 发布程序包: {base_name}")
    print(f" 目标输出目录: {dist_dir}")
    print(f"==================================================")

    # 1. 创建 ZIP
    count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            dirs[:] = [d for d in dirs if not should_exclude(os.path.relpath(os.path.join(root, d), BASE_DIR))]
            for file in files:
                full_p = os.path.join(root, file)
                rel_p = os.path.relpath(full_p, BASE_DIR)
                if not should_exclude(rel_p):
                    zf.write(full_p, rel_p)
                    count += 1
    print(f"[OK] ZIP package created: {zip_path} ({count} files)")

    # 2. 创建 TAR.GZ
    with tarfile.open(tar_path, "w:gz") as tf:
        for root, dirs, files in os.walk(BASE_DIR):
            dirs[:] = [d for d in dirs if not should_exclude(os.path.relpath(os.path.join(root, d), BASE_DIR))]
            for file in files:
                full_p = os.path.join(root, file)
                rel_p = os.path.relpath(full_p, BASE_DIR)
                if not should_exclude(rel_p):
                    tf.add(full_p, arcname=rel_p)
    print(f"[OK] TAR.GZ package created: {tar_path}")

    # 验证生成的压缩包内是否包含任何 .db 文件 (安全双重校验)
    with zipfile.ZipFile(zip_path, "r") as zf:
        db_files = [f for f in zf.namelist() if f.endswith(".db")]
        if db_files:
            raise RuntimeError(f"Security check failed! Release package contained .db file: {db_files}")
        has_gitkeep = any(f == "data/.gitkeep" or f.endswith("/.gitkeep") for f in zf.namelist())
        if not has_gitkeep:
            raise RuntimeError(f"Security check failed! Missing data/.gitkeep placeholder")

    print(f"\n==================================================")
    print(f" [PASS] 100% Verified! Release package contains NO .db files! Zero data loss guaranteed!")
    print(f"==================================================")

if __name__ == "__main__":
    package()
