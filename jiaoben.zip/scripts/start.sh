#!/usr/bin/env bash
# 前台调试启动脚本
PROJECT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$PROJECT_DIR"

if [ -f "$PROJECT_DIR/venv/bin/python" ]; then
  PYTHON_BIN="$PROJECT_DIR/venv/bin/python"
else
  PYTHON_BIN="python3"
fi

echo "正在启动 GitRelease Watcher..."
$PYTHON_BIN run.py
