#!/usr/bin/env bash
# GitRelease Watcher 卸载服务脚本
set -e

if [ "$EUID" -ne 0 ]; then
  echo "请使用 sudo 运行此脚本"
  exit 1
fi

SERVICE_NAME="gitrelease-watcher"
echo "正在停止并清理 $SERVICE_NAME 服务..."

systemctl stop $SERVICE_NAME || true
systemctl disable $SERVICE_NAME || true
rm -f /etc/systemd/system/${SERVICE_NAME}.service
systemctl daemon-reload

echo "Systemd 服务已成功卸载。项目数据文件仍保留在本地。"
