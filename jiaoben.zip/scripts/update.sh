#!/usr/bin/env bash
# ==============================================================================
# GitRelease Watcher - 零丢数据平滑升级脚本 (历史任务与计划 100% 受保护)
# ==============================================================================

set -e

if [ "$EUID" -ne 0 ]; then
  echo -e "\033[31m[错误] 请使用 sudo 或 root 用户运行此升级脚本！\033[0m"
  exit 1
fi

PROJECT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
SERVICE_NAME="gitrelease-watcher"
DATA_DIR="$PROJECT_DIR/data"
DB_FILE="$DATA_DIR/gitrelease_watcher.db"
SYSTEM_BACKUP_DIR="/var/backups/gitrelease-watcher"
BACKUP_DIR="$PROJECT_DIR/backup_$(date +%Y%m%d_%H%M%S)"
RELEASE_ARCHIVE="$1"

echo -e "\033[36m=====================================================\033[0m"
echo -e "\033[32m 开始执行 GitRelease Watcher 零丢数据平滑升级流程...\033[0m"
echo -e "\033[36m 项目根目录: $PROJECT_DIR\033[0m"
echo -e "\033[36m=====================================================\033[0m"

# 1. 临时停止正在运行的旧版本服务
if systemctl is-active --quiet "$SERVICE_NAME"; then
  echo -e "\033[33m1. 正在安全停止旧版本服务进程...\033[0m"
  systemctl stop "$SERVICE_NAME"
fi

# 2. 灾备多重备份机制 (备份到项目级、系统级 /var/backups/ 及临时快照)
mkdir -p "$SYSTEM_BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

PRE_UPGRADE_BACKUP=""
if [ -f "$DB_FILE" ]; then
  echo -e "\033[33m2. 正在对现有监控任务数据库进行多层灾备保护备份...\033[0m"
  # 项目级备份
  cp -r "$DATA_DIR" "$BACKUP_DIR/"
  # 系统级持久灾难备份 (防止误删整项目目录)
  cp "$DB_FILE" "$SYSTEM_BACKUP_DIR/gitrelease_auto_snapshot.db"
  # 升级前快速快照
  cp "$DB_FILE" "$DATA_DIR/gitrelease_pre_update.db"
  PRE_UPGRADE_BACKUP="$DATA_DIR/gitrelease_pre_update.db"
  echo -e "\033[32m   ✔ 数据库已安全同步至系统保护目录: $SYSTEM_BACKUP_DIR\033[0m"
  echo -e "\033[32m   ✔ 数据库已打包归档至: $BACKUP_DIR\033[0m"
fi

# 3. 如果指定了新版本更新包 (zip / tar.gz)，进行无害化解压 (严禁覆盖 data/ 目录)
if [ -n "$RELEASE_ARCHIVE" ] && [ -f "$RELEASE_ARCHIVE" ]; then
  echo -e "\033[33m3. 正在解压新版本安装包: $RELEASE_ARCHIVE (严格排除 data 目录防覆盖)...\033[0m"
  if [[ "$RELEASE_ARCHIVE" == *.zip ]]; then
    unzip -o "$RELEASE_ARCHIVE" -d "$PROJECT_DIR" -x "data/*" "backup_*" 2>/dev/null || unzip -o "$RELEASE_ARCHIVE" -d "$PROJECT_DIR"
  elif [[ "$RELEASE_ARCHIVE" == *.tar.gz ]] || [[ "$RELEASE_ARCHIVE" == *.tgz ]]; then
    tar -zxvf "$RELEASE_ARCHIVE" -C "$PROJECT_DIR" --exclude="data/*" --exclude="backup_*" 2>/dev/null || tar -zxvf "$RELEASE_ARCHIVE" -C "$PROJECT_DIR"
  fi
  echo -e "\033[32m   ✔ 新版本核心文件解压完成，data 目录得到严格物理隔离保护！\033[0m"
fi

# 4. 自愈校验：如果用户在运行此脚本前手动解压了空白 db 文件覆盖了原库，自动触发回填恢复
RECOVER_TRIGGERED=0
if [ -f "$PRE_UPGRADE_BACKUP" ]; then
  # 验证当前 DB 是否损坏或被清空
  CURRENT_TASK_COUNT=$(python3 -c "import sqlite3; c=sqlite3.connect('$DB_FILE'); cur=c.cursor(); cur.execute('SELECT count(*) FROM sqlite_master WHERE type=\'table\' AND name=\'tasks\''); has_t=cur.fetchone()[0]; cnt=0; (has_t and cur.execute('SELECT count(*) FROM tasks') and (cnt:=cur.fetchone()[0])); print(cnt); c.close()" 2>/dev/null || echo "0")
  BACKUP_TASK_COUNT=$(python3 -c "import sqlite3; c=sqlite3.connect('$PRE_UPGRADE_BACKUP'); cur=c.cursor(); cur.execute('SELECT count(*) FROM sqlite_master WHERE type=\'table\' AND name=\'tasks\''); has_t=cur.fetchone()[0]; cnt=0; (has_t and cur.execute('SELECT count(*) FROM tasks') and (cnt:=cur.fetchone()[0])); print(cnt); c.close()" 2>/dev/null || echo "0")

  if [ "$CURRENT_TASK_COUNT" -eq 0 ] && [ "$BACKUP_TASK_COUNT" -gt 0 ]; then
    echo -e "\033[35m   [灾备自愈] 检测到新版覆盖导致的数据库空白异常，正在从升级前备份自动回填 $BACKUP_TASK_COUNT 个任务...\033[0m"
    cp "$PRE_UPGRADE_BACKUP" "$DB_FILE"
    RECOVER_TRIGGERED=1
    echo -e "\033[32m   ✔ 历史监控任务及计划已全量无缝恢复！\033[0m"
  fi
fi

# 5. 检查并更新 Python 虚拟环境依赖
VENV_DIR="$PROJECT_DIR/venv"
if [ ! -d "$VENV_DIR" ]; then
  echo -e "\033[33m5. 未找到现有虚拟环境，正在创建...\033[0m"
  python3 -m venv "$VENV_DIR" || python3 -m virtualenv "$VENV_DIR"
fi

echo -e "\033[33m5. 正在检查并增量更新依赖包...\033[0m"
"$VENV_DIR/bin/pip" install -r "$PROJECT_DIR/requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple || "$VENV_DIR/bin/pip" install -r "$PROJECT_DIR/requirements.txt"

# 6. 确保下载目录与权限正常
mkdir -p /www/zfile/dow || true
chmod -R 755 /www/zfile/dow 2>/dev/null || true
mkdir -p "$DATA_DIR"
chmod -R 755 "$DATA_DIR" 2>/dev/null || true

# 7. 重启服务
echo -e "\033[33m6. 正在启动新版本服务...\033[0m"
systemctl daemon-reload
systemctl restart "$SERVICE_NAME"
systemctl enable "$SERVICE_NAME"

LOCAL_IP=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7}' || hostname -I | awk '{print $1}' || echo "127.0.0.1")

echo -e "\033[32m=====================================================\033[0m"
echo -e "\033[32m  🎉 GitRelease Watcher 平滑升级完成！服务已就绪！\033[0m"
if [ "$RECOVER_TRIGGERED" -eq 1 ]; then
  echo -e "\033[35m  ★ 触发灾备自愈：已成功找回并恢复所有历史任务与计划！\033[0m"
else
  echo -e "\033[36m  ★ 历史监控任务及定时计划已完整保留，无需重新配置！\033[0m"
fi
echo -e "\033[33m  👉 面板地址: http://${LOCAL_IP}:8088\033[0m"
echo -e "\033[32m=====================================================\033[0m"
