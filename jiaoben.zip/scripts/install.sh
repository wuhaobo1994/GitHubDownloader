#!/usr/bin/env bash
# ==============================================================================
# GitRelease Watcher - Linux 一键安装与系统守护进程配置脚本
# 适用平台: Ubuntu / Debian / CentOS / Rocky / AlmaLinux / Arch 等
# ==============================================================================

set -e

# 确保以 root 权限运行
if [ "$EUID" -ne 0 ]; then
  echo -e "\033[31m[错误] 请使用 sudo 或 root 用户运行本安装脚本！\033[0m"
  exit 1
fi

PROJECT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
SERVICE_NAME="gitrelease-watcher"
PORT=8088

echo -e "\033[36m=====================================================\033[0m"
echo -e "\033[32m 开始安装部署 GitRelease Watcher 监控面板服务...\033[0m"
echo -e "\033[36m 项目目录: $PROJECT_DIR\033[0m"
echo -e "\033[36m 服务端口: $PORT\033[0m"
echo -e "\033[36m=====================================================\033[0m"

# 1. 检查 Python 3
if ! command -v python3 &> /dev/null; then
  echo -e "\033[33m未检测到 Python 3，正在尝试自动安装...\033[0m"
  if command -v apt-get &> /dev/null; then
    apt-get update && apt-get install -y python3 python3-pip python3-venv
  elif command -v yum &> /dev/null; then
    yum install -y python3 python3-pip
  elif command -v dnf &> /dev/null; then
    dnf install -y python3 python3-pip
  else
    echo -e "\033[31m无法自动安装 Python 3，请先手动安装 python3 和 pip 后重试。\033[0m"
    exit 1
  fi
fi

# 确保安装 python3-venv (Ubuntu/Debian 常见分离包)
if command -v apt-get &> /dev/null; then
  dpkg -s python3-venv &> /dev/null || apt-get install -y python3-venv || true
fi

# 2. 创建 Python 独立隔离虚拟环境
VENV_DIR="$PROJECT_DIR/venv"
if [ ! -d "$VENV_DIR" ]; then
  echo -e "\033[33m正在创建 Python 虚拟运行环境...\033[0m"
  python3 -m venv "$VENV_DIR" || python3 -m virtualenv "$VENV_DIR"
fi

# 3. 安装依赖包
echo -e "\033[33m正在安装项目核心依赖 (FastAPI, APScheduler, httpx 等)...\033[0m"
"$VENV_DIR/bin/pip" install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple || "$VENV_DIR/bin/pip" install --upgrade pip
"$VENV_DIR/bin/pip" install -r "$PROJECT_DIR/requirements.txt" -i https://pypi.tuna.tsinghua.edu.cn/simple || "$VENV_DIR/bin/pip" install -r "$PROJECT_DIR/requirements.txt"

# 4. 创建默认存储目录与数据目录并配置权限
mkdir -p /www/zfile/dow || true
chmod -R 755 /www/zfile/dow 2>/dev/null || true
mkdir -p "$PROJECT_DIR/data" || true
chmod -R 755 "$PROJECT_DIR/data" 2>/dev/null || true

# 检查是否存在历史数据或系统持久备份 (保证重装或升级不丢失数据)
SYSTEM_BACKUP="/var/backups/gitrelease-watcher/gitrelease_auto_snapshot.db"
LOCAL_DB="$PROJECT_DIR/data/gitrelease_watcher.db"
if [ -f "$LOCAL_DB" ]; then
  echo -e "\033[32m✔ 检测到现有任务数据库，您的历史任务与配置已直接继承，绝不清除！\033[0m"
elif [ -f "$SYSTEM_BACKUP" ]; then
  echo -e "\033[32m✔ 检测到系统级持久备份，正在自动恢复历史任务与计划...\033[0m"
  cp "$SYSTEM_BACKUP" "$LOCAL_DB"
fi

# 4. 创建 Systemd 服务配置
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
echo -e "\033[33m正在注册 Systemd 系统开机自启服务 (${SERVICE_FILE})...\033[0m"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=GitRelease Watcher - GitHub Release Auto Monitor & Downloader
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$PROJECT_DIR
Environment=PORT=$PORT
Environment=HOST=0.0.0.0
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV_DIR/bin/python run.py
Restart=always
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

# 5. 重新加载并启动服务
systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"

# 6. 获取本机 IP
LOCAL_IP=$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7}' || hostname -I | awk '{print $1}' || echo "127.0.0.1")

echo -e "\033[32m=====================================================\033[0m"
echo -e "\033[32m  🎉 GitRelease Watcher 安装成功并已启动！\033[0m"
echo -e "\033[36m  Web 控制面板访问地址:\033[0m"
echo -e "\033[33m  👉 http://${LOCAL_IP}:${PORT}\033[0m"
echo -e "\033[33m  👉 http://localhost:${PORT}\033[0m"
echo -e "\033[32m=====================================================\033[0m"
echo -e "常用管理命令:"
echo -e "  查看运行状态: systemctl status $SERVICE_NAME"
echo -e "  查看实时日志: journalctl -u $SERVICE_NAME -f"
echo -e "  重启服务:     systemctl restart $SERVICE_NAME"
echo -e "  停止服务:     systemctl stop $SERVICE_NAME"
echo -e "\033[32m=====================================================\033[0m"
